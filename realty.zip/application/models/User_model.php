<?php

class User_model extends CI_model{

	public function get_agents(){
		$this->db->where([
			        'role'      =>'1'
			]);
		$this->db->order_by('id','DESC');
		$query = $this->db->get('users');
		return $query->result();
	}

	public function insert_roles($data){
		$this->db->insert('users',$data);
		return $this->db->insert_id();
	}

    public function remove_agent(){
        $agid = $this->input->post('agid');
        $this->db->where('id',$agid);
        $query = $this->db->delete('users');
        return $query;
	}

    public function update_agent($data){
        $agid = $this->input->post('agid');
        $this->db->where('id',$agid);
		$query = $this->db->update('users',$data);
		return $query;
	}
	
	public function get_property_details(){
	    $query= $this->db->get('properties');
	    return $query->result();
	}
	
	public function get_gallery_images($id){
	    $this->db->where('property_id',$id);
	    $query= $this->db->get('gallery');
	    return $query->result();
	}
	
	public function get_property($id){
	    $this->db->where('id',$id);
	    $query= $this->db->get('properties');
	    return $query->result(); 
	}
	
	public function get_blog_details(){
	    $this->db->order_by('created_date', "desc");
        $query= $this->db->get('blogs');
	    return $query->result();
	}
	
	public function get_blog($id){
        $this->db->where('blog_id',$id);
	    $query= $this->db->get('blogs');
	    return $query->result(); 
	}
	
	public function get_blog_list($id){
	    $this->db->order_by('created_date', "desc");
        $this->db->where('blog_id != ',$id);    
        $query= $this->db->get('blogs');
	    return $query->result();
	}
	/*joins Example*/
	/*$this->db->select('*');
$this->db->from('blogs');
$this->db->join('comments', 'comments.id = blogs.id');
$query = $this->db->get();*/
}

?>