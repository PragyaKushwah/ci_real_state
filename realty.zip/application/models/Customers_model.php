<?php

class Customers_model extends CI_model{

	public function insert_customer($data){
	    $this->db->insert('customers',$data);
	    return $this->db->insert_id();
	}
	public function update_customer($data){
	    $customer_id = $this->input->post('customer_id');
	    $this->db->where('id',8);
	    $this->db->update('customers',$data);
	    return $this->db->insert_id();
	}

	public function verify_customer(){
	    $user_name = $this->input->post('username');
	    $password = $this->input->post('password');
	    $where = "(name = '$user_name' OR email = '$user_name') AND password = '$password'";
	    $this->db->select('*');
	    $this->db->from('customers');
	    $this->db->where($where);
	    $result = $this->db->get();
	    if($result->num_rows()>0){
            $row = $result->result();
            $customer = array('cid' => $row[0]->id, 'name' => $row[0]->name, 'mobile' => $row[0]->mobile, 'email' => $row[0]->email);
            return $customer;
        }else{
            return FALSE;
        }
	}
	
	public function insert_view_contact(){
	    date_default_timezone_set("Asia/Kolkata");
        $current_time =  date('Y-m-d H:i:s');
	    $data = array(
	                'customer_id'           => $this->input->post('customer_id'),
	                'property_id'              => $this->input->post('property_id'),
	                'enquiry_date'            => $current_time
	        );
        $query = $this->db->insert('view_contact',$data);
        return $this->db->insert_id();
	}
	
	public function get_view_contact_list(){
	    $cid = $_SESSION['customer_id'];
	    $this->db->select('*');
	    $this->db->from('view_contact');
	    $this->db->where('customer_id',$cid);
	    $query = $this->db->get();
	    return $query->result();
	}
    
    public function get_customer_agent_contacts(){
        $this->db->select('view_contact.*, customers.name as cname, customers.mobile as cmobile, properties.name as pname, users.name as aname, users.contact as acontact');
        $this->db->join('customers','customers.id = view_contact.customer_id','left');
        $this->db->join('properties','properties.id = view_contact.property_id','left');
        $this->db->join('users','users.id = properties.agent','left');
        $this->db->from('view_contact');
        $this->db->order_by('view_contact.enquiry_date','DESC');
        $query = $this->db->get();
        return $query->result();
    }
    
    public function get_property_data($pid){
        $this->db->select('properties.*, users.name as agent_name, users.email as agent_email, users.viewable_contact as agent_contact');
        $this->db->from('properties');
        $this->db->join('users','users.id = properties.agent','left');
        $this->db->where('properties.id',$pid);
        $query = $this->db->get();
        return $query->result();
    }
    
    // // 	---------------------pragya------------------------
    
    public function insert_wishlist(){
        $current_time =  date('Y-m-d H:i:s');
	    $data = array(
	                'customer_id'           => $this->session->userdata('customer_id'),
	                'property_id'              => $this->input->post('property_id'),
	                'created_at'            => $current_time
	        );
        $query = $this->db->insert('wishlist',$data);
        return $this->db->insert_id();
	}
	
// 	public function get_wishlist(){
// 	    $data = array(
// 	                'customer_id'           => $this->input->post('customer_id'),
// 	                'property_id'              => $this->input->post('property_id'),
// 	        );
// 	    $this->db->select('*');
// 	    $this->db->from('wishlist');
// 	   // $this->db->where($data);
// 	    $result = $this->db->get();
// 	   // $result = $query->num_rows();
// 	    return $result;
// 	}
	
	public function get_wishlist($pid, $cid){
	    $data = array(
	                'customer_id'           => $cid,
	                'property_id'              => $pid
	        );
	    $this->db->select('*');
        $this->db->from('wishlist');
        $this->db->where($data);
        $query = $this->db->get();
        return $query->result();
	}
	public function get_wishlist_customer($customer_id){
	    $data = array(
	                'customer_id'           => $customer_id,
	        );
	  
        $this->db->select("wishlist.*, properties.*, properties.id AS id, properties.status AS status, properties.name AS property_name, properties.agent AS agent, city.name AS location_name, properties.area, properties.property_type, size_parameters.type AS size_param, properties.size, properties.location,  properties.area, properties.property_category,  properties.address, properties.min_price, properties.max_price, property_purpose.name AS property_purpose_name, properties.featured, furnish_status.name AS fur_status, properties.amenities, properties.hall, properties.balcony, properties.kitchen, properties.bathrooms, properties.floors, properties.boundary_wall, properties.facingside_roadwidth, properties.floor_allowed,  properties.open_side_no, properties.bedrooms, users.name AS agent_name, repo.id AS repository_id, media.name AS media_name");
		$this->db->from('wishlist');
		$this->db->join('properties', 'properties.id = wishlist.property_id', 'left');
		$this->db->join('furnish_status', 'furnish_status.id = properties.furnish_status', 'left');
		$this->db->join('locations as city', 'city.id = properties.location');
		$this->db->join('size_parameters', 'size_parameters.id = properties.size_param', 'left');
		$this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose');
		$this->db->join('users', 'users.id = properties.agent');
		$this->db->join('repository as repo', 'repo.type_id = properties.id');
	    $this->db->join('media', 'repo.id = media.repository_id', 'left');
	    $this->db->where($data);
	    $this->db->group_by('properties.id');
        $query = $this->db->get();
        return $query->result();
	}
	
	public function customer_wishlist($cid){
	    $data = array(
	                'customer_id' => $cid
	        );
	    $this->db->select('*');
        $this->db->from('wishlist');
        $this->db->where($data);
        $query = $this->db->get();
        return $query->result();
	}
	
	public function delete_wishlist(){
	    $data = array(
	                'customer_id'           => $this->session->userdata('customer_id'),
	                'property_id'              => $this->input->post('property_id'),
	        );
	    $this->db->where($data);
	    $result = $this->db->delete('wishlist');
	    return $result;
	}
	
	public function get_customer_details($cid){
	    $data = array(
	                'id' => $cid
	        );
	    $this->db->select('*');
        $this->db->from('customers');
        $this->db->where($data);
        $query = $this->db->get();
        return $query->result();
	}

}

?>