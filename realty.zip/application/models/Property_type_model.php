<?php

class Property_type_model extends CI_model{

	public function get_property_type(){
		$query = $this->db->get('property_type');
		return $query->result();
	}

	public function insert_property_type($data){
		$this->db->insert('property_type',$data);
	}

}

?>