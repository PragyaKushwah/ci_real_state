<?php

class Featured_model extends CI_model{

	public function feature($data){
		$this->db->set('featured', 1);
        $this->db->where('id', $data[0]);
        if($this->db->update($data[1])){
            echo 'success!';
        }
        
	}
	public function unfeature($data){
		$this->db->set('featured', 0);
        $this->db->where('id', $data[0]);
        if($this->db->update($data[1])){
            echo 'success!';
        }
	}
}

?>