<?php

class Admin_model extends CI_model{
	
	public function get_details(){
		$query = $this->db->get('users');
		return $query->result();
	}
	
	/*functionality for Gallery Start here*/
	
	
	   /* get the records from gallery db*/
    public function get_gallery_details(){
        $query=$this->db->get('gallery');
        return $query->result();
    }
    public function get_gallery_details2($property_id){
       $this->db->where('property_id',$property_id); 
       $query=$this->db->get('gallery');
         return $query->result();
    }
      /* get details of gallery selected*/
    public function get_gallery_details1($id){
        $this->db->where('id',$id);
        $query=$this->db->get('gallery');
         return $query->result();
    }
    
      /* update the values of gallery*/
    public function update_gallery_record($data1,$sid){
          $this->db->set($data1);
         $this->db->where('id',$sid);
         $query=$this->db->update('gallery');
		    if($query){
		    	return true;
		    }
		    else
		    {
	          return false;
		    }
    }
       /* add records to gallery db*/
     public function save_gallery_record($data1){
        $query=$this->db->insert('gallery',$data1);
        return $this->db->insert_id();
    }
      /* delete records from gallery db*/
    public function delete_gallery_record($id){
         $this->db->where('id',$id);
	   	$query=$this->db->delete('gallery');
	   	if($query){
	   		return true;
	   	}
	   	else
	   	{
	       return false;
	   	}
    }
/*functionality for Gallery Ends here*/

/*functionality for Properties Start here*/
    
    
     /* get the records from properties db*/
    public function get_property_details(){
        $query=$this->db->get('properties');
        return $query->result(); 
    }
    
    public function get_properties_details1($id){
        $this->db->where('id',$id);
       $query=$this->db->get('properties');
        return $query->result();  
    }
    
    public function save_property_record($data1){
        $query=$this->db->insert('properties',$data1);
        return $this->db->insert_id();  
    }
    public function update_properties_record($data1,$sid){
         $this->db->set($data1);
         $this->db->where('id',$sid);
         $query=$this->db->update('properties');
		    if($query){
		    	return true;
		    }
		    else
		    {
	          return false;
		    }
    }
    public function delete_properties_record($id){
      $this->db->where('id',$id);
	   	$query=$this->db->delete('properties');
	   	if($query){
	   		return true;
	   	}
	   	else
	   	{
	       return false;
	   	}  
    }
    
    
 /*functionality for Properties Ends here*/   
  /*blog functionalities start here*/
   	public function get_blog_details(){
   	    $query = $this->db->get('blogs');
   	    return $query->result();
   	}
   	
   	public function updateblog_details($id){
   	    $this->db->where('blog_id',$id);
    	$query=$this->db->get('blogs');
    	return $query->result();  
   	}
   	public function update_blog_record($data,$uid){
   	   $this->db->where('blog_id',$uid);
  	$query=$this->db->update('blogs',$data);
  	 if($query){
		    	return true;
		    }
		    else
		    {
	          return false;
		    }    
   	}
   	public function save_blog_record($data){
   	    $query=$this->db->insert('blogs',$data);
        return $this->db->insert_id(); 
   	}
   	public function delete_blog_record($id){
   	  $this->db->where('blog_id',$id);
	   	$query=$this->db->delete('blogs');
	   	if($query){
	   		return true;
	   	}
	   	else
	   	{
	       return false;
	   	}    
   	}
   	/*blog functionalities ends here*/ 
   	
     /*contact functionalities start here*/
   	public function get_contact_details(){
   	    $query = $this->db->get('contact');
   	    return $query->result();
   	}
   	
   	public function updatecontact_details($id){
   	    $this->db->where('id',$id);
    	$query=$this->db->get('contact');
    	return $query->result();  
   	}
   	public function update_contact_record($data,$uid){
   	   $this->db->where('id',$uid);
  	$query=$this->db->update('contact',$data);
  	 if($query){
		    	return true;
		    }
		    else
		    {
	          return false;
		    }    
   	}
   	public function save_contact_record($data){
   	    $query=$this->db->insert('contact',$data);
        return $this->db->insert_id(); 
   	}
   	public function delete_contact_record($id){
   	  $this->db->where('id',$id);
	   	$query=$this->db->delete('contact');
	   	if($query){
	   		return true;
	   	}
	   	else
	   	{
	       return false;
	   	}    
   	}
   	/*contact functionalities ends here*/ 	
   	
   	
    
}




?>