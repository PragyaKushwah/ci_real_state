<?php

class Builder_model extends CI_model{

	public function get_builders(){
		$query = $this->db->get('builder');
		return $query->result();
	}
	
	public function get_featured_builders(){
	    
	    $this->db->select('builder.*, count(*) AS property_count');
	    
	    $this->db->from('builder');
	    
	    $this->db->join('properties', 'properties.builder = builder.id');
	    
	    $this->db->group_by('builder.id');
	    
	    $this->db->order_by('property_count', 'DESC');
	    
	    $this->db->limit(3);
	    
	    $query = $this->db->get();
	    
	    return $query->result();
	    
	}
	
	public function get_featured_builders_city($city_id){
	    
	    $this->db->select('builder.*, count(*) AS property_count');
	    
	    $this->db->from('builder');
	    
	    $this->db->join('properties', 'properties.builder = builder.id');
	    
	    $this->db->where('properties.location',$city_id);
	    
	    $this->db->group_by('builder.id');
	    
	    $this->db->order_by('property_count', 'DESC');
	    
	    $this->db->limit(3);
	    
	    $query = $this->db->get();
	    
	    return $query->result();
	    
	}
	
	public function insert_builders($data){
		$this->db->insert('builder',$data);
	}
	

}

?>