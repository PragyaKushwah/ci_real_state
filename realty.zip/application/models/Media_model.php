<?php

class Media_model extends CI_model{

	public function insert_into_repository($repository_data){
		$this->db->insert('repository',$repository_data);
		
		$repo_id = $id = $this->db->insert_id();
		return $repo_id;
	}
	
	public function insert_media($data){
	    $result = $this->db->insert('media', $data);
	    return $result;
	}
	
	public function get_reposotory_id($repository_data){
	    
	    $this->db->where(['type'=> $repository_data['type'], 'type_id' => $repository_data['type_id']]);
	    
	    $query = $this->db->get('repository');
	    
	    return $query->row()->id;
	    
        // $res = $query->row();
        // return $res->id;

	}
	
	// Get all media for a specific property.
	public function get_property_media($property_id){
	    
	    $this->db->select("properties.id as prop_id, media.id as media_id, media.name AS media_name, repo.id as repo_id, repo.type as repo_type");
	    
	    $this->db->from('properties');
	    
	    $where = "properties.id = $property_id AND (properties.status = 1 OR properties.status = 0)";
	    $this->db->where($where);
	    
	    $this->db->join('repository as repo', 'repo.type_id = properties.id');
	    
	    $this->db->join('media', 'repo.id = media.repository_id');
	    
	    $this->db->order_by('media.id', 'DESC');
	    
	    $query = $this->db->get();
	    
	    return $query->result();
	}
	
	// To get a single media for every property. (TEST FUNCTION)
	public function get_single_media(){
	    
	    $this->db->select("media.name AS media_name");
	    
	    $this->db->from('properties');
	    
	    $this->db->join('repository as repo', 'repo.type_id = properties.id');
	    
	    $this->db->join('media', 'repo.id = media.repository_id', 'left');
	    
	    $where = "properties.status = 1 OR properties.status = 0";
	    $this->db->where($where);
	    
	    $this->db->group_by('properties.id');
	    
	    $query = $this->db->get();
	    
	    return $query->result();
	}

    public function remove_media(){
        
        $media_id = $this->input->post('mediaid');
        $this->db->where('id', $media_id);
        $query = $this->db->delete('media');
        return $query;
        
    }
    public function select_property_media($repo_id){
        
        $this->db->select("*");
	    $this->db->from('media');
	    $this->db->where('repository_id',$repo_id);
	    $query = $this->db->get();
	    return $query->result();
    }
    public function add_image_caption($data){
        $status = TRUE;
        foreach($data as $id=>$cptn){
            $caption = array(
                            'caption' => $cptn
                        );
    	    $this->db->where('id',$id);
    		$result = $this->db->update('media',$caption);
    		if($result){ }
    		else{ $status = FALSE; }
        }
		return $status;
	}
    
    
}

?>