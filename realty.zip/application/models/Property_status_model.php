<?php

class Property_status_model extends CI_model{

	public function get_property_status(){
		$query = $this->db->get('property_status');
		return $query->result();
	}

}

?>