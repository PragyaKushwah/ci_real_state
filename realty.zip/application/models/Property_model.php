<?php

class Property_model extends CI_model{

    
    public function get_property_by_id($pid){
        $this->db->select('*');
        $this->db->from('properties');
        $this->db->where('id',$pid);
        $query = $this->db->get();
        return $query->result();
    }
    
	public function insert_property($data){
		$this->db->insert('properties',$data);
		$insert_id = $this->db->insert_id();
		if($this->db->affected_rows() > 0){
    		$rep_data = array(
    		        'type' => 'PROPERTY',
    		        'type_id' => $insert_id
    		    );
    		$this->db->insert('repository',$rep_data);
    		if($this->db->affected_rows() > 0){
    		    
    		}
    		else{
    		    echo 'Repository Insert Error!';
    		    $this->db->error();
    		}
		}
		else{
		    echo 'Property Insert Error!';
		    $this->db->error();
		}
	}
	
	public function update_property($data){
	    $pid = $this->input->post('pid');
	    $this->db->where('id',$pid);
		$result = $this->db->update('properties',$data);
		return $result;
	}
	
	public function remove_property_agent(){
	    $pid = $this->input->post('prid');
	    $this->db->where('id',$pid);
		$result = $this->db->delete('properties');
		return $result;
	}
	
	public function remove_property_admin(){
	    $pid = $this->input->post('prid');
	    $this->db->where('id',$pid);
		$result = $this->db->delete('properties');
		return $result;
	}
	
	public function remove_property(){
	    $pid = $this->input->post('prid');
	    $data = array(
	            'status'    => 3                                        // STATUS 3 IMPLIES PROPERTY REJECTED
	        );
	    $this->db->where('id',$pid);
		$result = $this->db->update('properties',$data);
		return $result;
	}
	
	public function accept_property(){
	    $pid = $this->input->post('pid');
	    $data = array(
	            'status'    => 1                                       // STATUS 1 IMPLIES PROPERTY ACCEPTED AND ACTIVE
	        );
	    $this->db->where('id',$pid);
	    $query = $this->db->update('properties',$data);
	    return $query;
	}
	
	public function reject_property(){
	    $pid = $this->input->post('pid');
	    $data = array(
	            'status'    => 3                                       // STATUS 3 IMPLIES PROPERTY REJECTED
	        );
	    $this->db->where('id',$pid);
	    $query = $this->db->update('properties',$data);
	    return $query;
	}

	public function get_city_properties($city_id){
	    
		$this->db->where(['location'=>$city_id, 'status'=>1]);

		$this->db->select('properties.*, properties.id as property_id, properties.name, location, furnish_status.name AS fur_status, min_price, max_price, builder, builder.name as builder_name, address, property_purpose, property_purpose.name as property_purpose_name, area, bedrooms, bathrooms, size,hall, repository.id AS repository_id, media.name as media_name, users.viewable_contact as agent_contact, users.email as agent_mail, users.name as agent_name');
		
		$this->db->from('properties');
		
		$this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose');
		
		$this->db->join('furnish_status', 'furnish_status.id = properties.furnish_status', 'left');
		
		$this->db->join('builder', 'builder.id = properties.builder');
		
		$this->db->join('users', 'users.id = properties.agent','left');
		
		$this->db->join('repository', 'repository.type_id = properties.id');
	    
	    $this->db->join('media', 'repository.id = media.repository_id', 'left');
	    
	    $this->db->group_by('properties.id');
	    
		$query = $this->db->get();
		
		return $query->result();
	}
	
	public function get_all_global_properties(){
	    
	    $this->db->where(['status'=>1]);
	   // 	$this->db->select("properties.id AS id, properties.status AS status, properties.name AS property_name, properties.agent AS agent, city.name AS location_name, properties.area, properties.property_type, size_parameters.type AS size_param, properties.size, properties.location,  properties.area, properties.property_category,  properties.address, properties.min_price, properties.max_price, property_purpose.name AS property_purpose_name, properties.featured, furnish_status.name AS fur_status, properties.amenities, properties.hall, properties.balcony, properties.kitchen, properties.bathrooms, properties.floors, properties.boundary_wall, properties.facingside_roadwidth, properties.floor_allowed,  properties.open_side_no, properties.bedrooms, users.name AS agent_name, repo.id AS repository_id, media.name AS media_name");
	    $this->db->select('properties.*, properties.id as property_id, properties.agent, properties.name, builder.name as builder_name, location, min_price, max_price, builder, address, property_purpose, property_purpose.name as property_purpose_name, area, bedrooms, bathrooms, size,hall, repository.id AS repository_id, media.name as media_name, furnish_status.name AS fur_status, users.viewable_contact as agent_contact, users.email as agent_mail, users.name as agent_name');
		
		$this->db->from('properties');
		
		$this->db->order_by('properties.created_at DESC', 'properties.min_price DESC');
		
		$this->db->join('furnish_status', 'furnish_status.id = properties.furnish_status', 'left');
		
		$this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose');
		
		$this->db->join('builder', 'builder.id = properties.builder');
		
		$this->db->join('repository', 'repository.type_id = properties.id');
	    
	    $this->db->join('media', 'repository.id = media.repository_id', 'left');
	    
	    $this->db->join('users', 'users.id = properties.agent', 'left');
	    
	    $this->db->group_by('properties.id');
	    
		$query = $this->db->get();
		
		return $query->result();
	}
	
	public function get_city_areas($city_id){
	    
	    $this->db->select("locations.name as area_name, count(*) as area_count, locations.id as area_id");
	    
	    $this->db->from('properties');
	    
	    $this->db->where(['properties.location'=>$city_id, 'properties.status'=>1]);
	    
	    $this->db->join('locations', 'locations.id = properties.area');
	    
	    $this->db->group_by('locations.id');
	    
	    $this->db->order_by('area_count', 'DESC');
	    $query = $this->db->get();
	    
	    return $query->result();
	    
	}
	
	public function get_properties_admin(){
		
// 		//$this->db->select("properties.id AS id, properties.name AS property_name, city.name AS location_name, properties.area, area.name AS area_name, properties.area, properties.min_price, properties.max_price, property_purpose.name AS property_purpose_name, properties.featured, users.name AS agent_name, repo.id AS repository_id, media.name AS media_name");
// 		$this->db->select("properties.id AS id, properties.status AS status, properties.name AS property_name, city.name AS location_name, properties.area AS area, properties.location, properties.min_price, properties.max_price, property_purpose.name AS property_purpose_name, properties.featured, users.name AS agent_name, repo.id AS repository_id, media.name AS media_name");
		
// 		$this->db->from('properties');
		
// 		$this->db->join('locations as city', 'city.id = properties.location');
		
// 		//$this->db->join('locations as area', 'area.id = properties.area');
		
// 		$this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose');
		
// 		$this->db->join('users', 'users.id = properties.agent');
		
// 		$this->db->join('repository as repo', 'repo.type_id = properties.id');
	    
// 	    $this->db->join('media', 'repo.id = media.repository_id', 'left');
	    
// 	    $where = "properties.status = 1 OR properties.status = 0";
// 	    $this->db->where($where);
	    
// 	    $this->db->group_by('properties.id');
		
// // 		$query = $this->db->select('id,name, location, min_price,max_price,property_purpose,area,repository_id, agent,featured')->get('properties');
		
// 		$query = $this->db->get();
		
// 		return $query->result();
		
		$this->db->select("properties.id AS id, properties.status AS status, properties.name AS property_name, properties.agent AS agent, city.name AS location_name, properties.area, properties.property_type, size_parameters.type AS size_param, properties.size, properties.location,  properties.area, properties.property_category,  properties.address, properties.min_price, properties.max_price, property_purpose.name AS property_purpose_name, properties.featured, furnish_status.name AS fur_status, properties.amenities, properties.hall, properties.balcony, properties.kitchen, properties.bathrooms, properties.floors, properties.boundary_wall, properties.facingside_roadwidth, properties.floor_allowed,  properties.open_side_no, properties.bedrooms, users.name AS agent_name, repo.id AS repository_id, media.name AS media_name");
		$this->db->from('properties');
		$this->db->join('furnish_status', 'furnish_status.id = properties.furnish_status', 'left');
		$this->db->join('locations as city', 'city.id = properties.location');
		$this->db->join('size_parameters', 'size_parameters.id = properties.size_param', 'left');
		$this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose');
		$this->db->join('users', 'users.id = properties.agent');
		$this->db->join('repository as repo', 'repo.type_id = properties.id');
	    $this->db->join('media', 'repo.id = media.repository_id', 'left');
	   // $this->db->where('properties.agent',$_SESSION['agent_id']);
	   // $where = "properties.status = 1 OR properties.status = 0";
	   // $this->db->where($where);
	    $this->db->group_by('properties.id');
        $query = $this->db->get();
		return $query->result();
	}
	
	public function get_unapproved_properties_admin(){
		
		//$this->db->select("properties.id AS id, properties.name AS property_name, city.name AS location_name, properties.area, area.name AS area_name, properties.area, properties.min_price, properties.max_price, property_purpose.name AS property_purpose_name, properties.featured, users.name AS agent_name, repo.id AS repository_id, media.name AS media_name");
		$this->db->select("properties.id AS id, properties.name AS property_name, city.name AS location_name, properties.area, properties.location, properties.min_price, properties.max_price, property_purpose.name AS property_purpose_name, properties.featured, users.name AS agent_name, users.viewable_contact AS agent_contact, repo.id AS repository_id, media.name AS media_name");
		
		$this->db->from('properties');
		
		$this->db->join('locations as city', 'city.id = properties.location');
		
		//$this->db->join('locations as area', 'area.id = properties.area');
		
		$this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose');
		
		$this->db->join('users', 'users.id = properties.agent');
		
		$this->db->join('repository as repo', 'repo.type_id = properties.id');
	    
	    $this->db->join('media', 'repo.id = media.repository_id', 'left');
	    
	    $this->db->where('properties.status', 2 );
	    
	    $this->db->group_by('properties.id');
		
// 		$query = $this->db->select('id,name, location, min_price,max_price,property_purpose,area,repository_id, agent,featured')->get('properties');
		
		$query = $this->db->get();
		
		return $query->result();
	}
	
	public function update_property_area($data){
	    $this->db->set('area', $data[0]);
	    $this->db->where('id', $data[1]);
	    $this->db->update('properties');
	}
    
    public function get_featured_cities(){
	    $this->db->select('properties.id AS property_id, locations.id AS city_id, locations.name AS city_name, count(*) as city_count');
	    
	    $this->db->from('properties');
	    
	    $this->db->where(['properties.featured'=>1, 'locations.featured'=>1, 'properties.status'=>1]);
	    
	    $this->db->join('locations', 'locations.id = properties.location');
	    
	    $this->db->group_by('locations.id');
	    
	    $query = $this->db->get();
        
        return $query->result();   
	}
	
	public function get_featured_city_properties(){
	    
	    $this->db->select('properties.*, locations.id AS city_id, locations.name as city_name,furnish_status.name AS fur_status, property_purpose.name as property_purpose_name, repo.id AS repository_id, media.name AS media_name, builder.name as builder_name, users.viewable_contact as agent_contact, users.email as agent_mail, users.name as agent_name');
        
        $this->db->from('properties');
        
        $this->db->where(['properties.featured'=>1, 'locations.featured'=>1, 'properties.status'=>1]);
        
        $this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose');
        
        $this->db->join('furnish_status', 'furnish_status.id = properties.furnish_status', 'left');
        
        $this->db->join('locations', 'locations.id = properties.location');
        
        $this->db->join('builder', 'builder.id = properties.builder');
        
        $this->db->join('users', 'users.id = properties.agent','left');
        
        $this->db->join('repository as repo', 'repo.type_id = properties.id');
	    
	    $this->db->join('media', 'repo.id = media.repository_id', 'left');
	    
	    $this->db->limit(8);
	    
	    $this->db->group_by('properties.id');
	    
	    
        $query = $this->db->get();
        
        return $query->result();
	    
	}
	
    public function get_featured_areas($city_id){
        
        $this->db->select('properties.id AS property_id, locations.id AS area_id, locations.name AS area_name');
        
        $this->db->from('properties');
        
        $this->db->where(['properties.location'=>$city_id, 'properties.featured'=>1, 'locations.featured'=>1, 'properties.status'=>1]);
        
        $this->db->join('locations', 'locations.id = properties.area');
        
        $this->db->group_by('locations.id');
        $query = $this->db->get();
        
        return $query->result();
        
    }
    
    public function get_featured_area_property($city_id){
        
        $this->db->select('properties.*, properties.id AS property_id, properties.name, furnish_status.name AS fur_status, locations.id AS area_id,min_price,max_price,builder, builder.name as builder_name,address,property_purpose,area,bedrooms,bathrooms,size,hall, properties.name AS property_name, locations.name AS area_name, address, property_purpose, property_purpose.name AS property_purpose_name, min_price, max_price, repo.id AS repository_id, media.name AS media_name, users.viewable_contact as agent_contact, users.email as agent_mail, users.name as agent_name');
        
        $this->db->from('properties');
        
        $this->db->where(['properties.location'=>$city_id, 'properties.featured'=>1, 'locations.featured'=>1, 'properties.status'=>1]);
        
        $this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose');
        
        $this->db->join('locations', 'locations.id = properties.area');
        
        $this->db->join('furnish_status', 'furnish_status.id = properties.furnish_status', 'left');
        
        $this->db->join('builder', 'builder.id = properties.builder');
        
        $this->db->join('users', 'users.id = properties.agent','left');
        
        $this->db->join('repository as repo', 'repo.type_id = properties.id');
	    
	    $this->db->join('media', 'repo.id = media.repository_id', 'left');
	    
	    $this->db->group_by('properties.id');
	    
        $query = $this->db->get();
        
        return $query->result();
        
    }
    
    // Search for properties according to the data.
    public function property_search($data){
        
        // PRICE BASED SEARCHING
        // if($this->input->post('min_price') != NULL && $this->input->post('max_price') != NULL){
        //     $where2 = "`properties.min_price` >= ".$this->input->post('min_price')." OR (`properties.min_price` <= ".$this->input->post('min_price')." AND `properties.max_price` >= ".$this->input->post('min_price').")
        //                 AND (`properties.max_price` <= ".$this->input->post('max_price')." OR `properties.max_price` >= ".$this->input->post('max_price')." AND `properties.min_price` <= ".$this->input->post('max_price').")";
        // }
        // AMENITIES BASED SEARCHING
        if($this->input->post('amenities') != NULL){
            $where = "";
            foreach($this->input->post('amenities') as $index => $value){
                if($index == 0){
                    $where .= "`properties.amenities` LIKE '%".$value."%'";
                }else{
                    $where .= " OR `properties.amenities` LIKE '%".$value."%'";
                }
            }
        }
        
        $this->db->select('properties.*, locations.name AS area_name, property_purpose.name AS property_purpose_name,furnish_status.name AS fur_status, repo.id AS repository_id, media.name AS media_name, builder.name as builder_name');
        
        $this->db->from('properties');
        
        $this->db->where($data);
        // if($this->input->post('min_price') != NULL && $this->input->post('max_price') != NULL){
        //     $this->db->where($where2);
        // }
        if($this->input->post('amenities') != NULL){
            $this->db->where($where);
        }
        
        //$this->db->where(['properties.location'=>3, 'properties.status'=>1]);
        
        $this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose');
        
        $this->db->join('locations', 'locations.id = properties.area');
        
        $this->db->join('builder', 'builder.id = properties.builder');
        
        $this->db->join('furnish_status', 'furnish_status.id = properties.furnish_status', 'left');
        
        $this->db->join('repository as repo', 'repo.type_id = properties.id');
	    
	    $this->db->join('media', 'repo.id = media.repository_id', 'left');
	    
	    $this->db->group_by('properties.id');
	    
        $query = $this->db->get();
        
        // echo $this->db->last_query();
        return $query->result();
    }
    
    // Get Details of a specific property.
    
    public function get_property_details($property_id){

        $this->db->select('properties.*, properties.id AS property_id, locations.id AS area_id, description, furnish_status.name AS fur_status, users.name as agent_name, users.viewable_contact as agent_contact, users.name as agent_name, users.email as agent_email, min_price, max_price, builder, address, property_type.name as property_type_name, property_type, area,bedrooms,bathrooms,size,hall, properties.name AS property_name, locations.name AS area_name, address, property_purpose, property_purpose.name AS property_purpose_name, min_price, max_price');
         
        $this->db->where(['properties.id'=>$property_id, 'properties.status'=>1]);
        
        $this->db->from('properties');
        
        $this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose','left');
        
        $this->db->join('property_type', 'property_type.id = properties.property_type','left');
        
        $this->db->join('furnish_status', 'furnish_status.id = properties.furnish_status', 'left');
        
        $this->db->join('locations', 'locations.id = properties.area','left');
        
        $this->db->join('builder', 'builder.id = properties.builder','left');
        
        $this->db->join('users', 'users.id = properties.agent','left');
        
        
        $query = $this->db->get();
    //   var_dump($query->row());
        return $query->row();
    }
    
    public function get_all_property(){
        
        $this->db->select('*');
        $this->db->from('properties');
        $query = $this->db->get();
        return $query->result();
        
    }
    
    
    
    /***************************************************************************/
	/***************************************************************************/
	/************************ Agent Specific Methods /**************************/
	/***************************************************************************/
	/***************************************************************************/
    
    public function get_properties_agent(){
		
		$this->db->select("properties.id AS id, properties.status AS status, properties.name AS property_name, properties.agent AS agent, city.name AS location_name, properties.area, properties.property_type, size_parameters.type AS size_param, properties.size, properties.location,  properties.area, properties.property_category,  properties.address, properties.min_price, properties.max_price, property_purpose.name AS property_purpose_name, properties.featured, furnish_status.name AS fur_status, properties.amenities, properties.hall, properties.balcony, properties.kitchen, properties.bathrooms, properties.floors, properties.boundary_wall, properties.facingside_roadwidth, properties.floor_allowed,  properties.open_side_no, properties.bedrooms, users.name AS agent_name, repo.id AS repository_id, media.name AS media_name");
		$this->db->from('properties');
		$this->db->join('furnish_status', 'furnish_status.id = properties.furnish_status', 'left');
		$this->db->join('locations as city', 'city.id = properties.location');
		$this->db->join('size_parameters', 'size_parameters.id = properties.size_param', 'left');
		$this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose');
		$this->db->join('users', 'users.id = properties.agent');
		$this->db->join('repository as repo', 'repo.type_id = properties.id');
	    $this->db->join('media', 'repo.id = media.repository_id', 'left');
	    $this->db->where('properties.agent',$_SESSION['agent_id']);
	    $this->db->group_by('properties.id');
        $query = $this->db->get();
		return $query->result();
	}
    
    public function get_property_by_id_and_agent($pid, $agent_id){
        $this->db->select('*');
        $this->db->from('properties');
        $this->db->where('id',$pid);
        $this->db->where('agent',$agent_id);
        $query = $this->db->get();
        return $query->result();
    }
    
    // -----------------------pragya----------------------------------
    public function insert_create_property($data){
        // var_dump($data);
// 		$this->db->insert('properties',$data);
        // return $this->db->insert_id();
        
        $this->db->insert('properties',$data);
		$insert_id = $this->db->insert_id();
		if($this->db->affected_rows() > 0){
    		$rep_data = array(
    		        'type' => 'PROPERTY',
    		        'type_id' => $insert_id
    		    );
    		$this->db->insert('repository',$rep_data);
    		if($this->db->affected_rows() > 0){
    		   return $insert_id;
    		}
    		else{
    		    echo 'Repository Insert Error!';
    		    $this->db->error();
    		}
		}
		
		else{
		    echo 'Property Insert Error!';
		    $this->db->error();
		}
	}
	public function update_property_steps($data){
	    $property_id = $this->input->post('property_id');
	    $this->db->where('id',$property_id);
		$result = $this->db->update('properties',$data);
		return $result;
	}
	public function getCity_property($insert_create_property){
	    $this->db->select('location');
        $this->db->from('properties');
        $this->db->where('id',$insert_create_property);
        $query = $this->db->get();
        return $query->row()->location;
       
	}
	
	public function select_property($pid){
	    $this->db->select('*');
        $this->db->from('properties');
        $this->db->where('id',$pid);
        $query = $this->db->get();
        return $query->result();
	}
	
    public function property_search_copy($data){
        
        // PRICE BASED SEARCHING
        // if($this->input->get('min_price') != NULL && $this->input->get('max_price') != NULL){
        //     $where2 = "`properties.min_price` >= ".$this->input->get('min_price')." OR (`properties.min_price` <= ".$this->input->get('min_price')." AND `properties.max_price` >= ".$this->input->get('min_price').")
        //                 AND (`properties.max_price` <= ".$this->input->get('max_price')." OR `properties.max_price` >= ".$this->input->get('max_price')." AND `properties.min_price` <= ".$this->input->get('max_price').")";
        // }
        // AMENITIES BASED SEARCHING
        if($this->input->get('amenities') != NULL){
            $where = "";
            foreach($this->input->get('amenities') as $index => $value){
                if($index == 0){
                    $where .= "`properties.amenities` LIKE '%".$value."%'";
                }else{
                    $where .= " OR `properties.amenities` LIKE '%".$value."%'";
                }
            }
        }
        
        $this->db->select('properties.*, locations.name AS area_name, property_purpose.name AS property_purpose_name,furnish_status.name AS fur_status, repo.id AS repository_id, media.name AS media_name, builder.name as builder_name');
        
        $this->db->from('properties');
        
        $this->db->where($data);
        // if($this->input->get('min_price') != NULL && $this->input->post('max_price') != NULL){
        //     $this->db->where($where2);
        // }
        if($this->input->get('amenities') != NULL){
            $this->db->where($where);
        }
        
        //$this->db->where(['properties.location'=>3, 'properties.status'=>1]);
        
        $this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose');
        
        $this->db->join('locations', 'locations.id = properties.area');
        
        $this->db->join('builder', 'builder.id = properties.builder');
        
        $this->db->join('furnish_status', 'furnish_status.id = properties.furnish_status', 'left');
        
        $this->db->join('repository as repo', 'repo.type_id = properties.id');
        
        $this->db->join('property_type', 'property_type.id = properties.property_type');
        
        $this->db->join('property_status', 'property_status.id = properties.property_status');
	    
	    $this->db->join('media', 'repo.id = media.repository_id', 'left');
	    
	    $this->db->group_by('properties.id');
	    
        $query = $this->db->get();
        
        // echo $this->db->last_query();
        return $query->result();
    }
    
	public function get_global_properties(){
	    $this->db->where(['properties.status'=>1]);
	    $this->db->select('properties.*, properties.id as property_id, properties.name,size_parameters.type as size_parameter, furnish_status.name AS fur_status,  location, min_price, max_price, builder, address, property_purpose, property_purpose.name as property_purpose_name, area, bedrooms, bathrooms, size,hall, repository.id AS repository_id, media.name as media_name');
		$this->db->from('properties');
		$this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose');
		$this->db->join('furnish_status', 'furnish_status.id = properties.furnish_status', 'left');
		$this->db->join('size_parameters', 'size_parameters.id = properties.size_param', 'left');
		$this->db->join('repository', 'repository.type_id = properties.id');
	    $this->db->join('media', 'repository.id = media.repository_id', 'left');
	    $this->db->group_by('properties.id');
		$query = $this->db->get();
		return $query->result();
	}
	
	public function get_featured_global_properties(){
	    $this->db->where(['properties.status'=>1]);
	    $this->db->where(['properties.featured'=>1]);
	    $this->db->select('properties.*, properties.id as property_id, properties.name, furnish_status.name AS fur_status,  location, min_price, max_price, builder, address, property_purpose, property_purpose.name as property_purpose_name, area, bedrooms, bathrooms, size,hall, repository.id AS repository_id, media.name as media_name');
		$this->db->from('properties');
		$this->db->join('property_purpose', 'property_purpose.id = properties.property_purpose');
		$this->db->join('furnish_status', 'furnish_status.id = properties.furnish_status', 'left');
		$this->db->join('repository', 'repository.type_id = properties.id');
	    $this->db->join('media', 'repository.id = media.repository_id', 'left');
	    $this->db->group_by('properties.id');
		$query = $this->db->get();
		return $query->result();
	}

}

?>