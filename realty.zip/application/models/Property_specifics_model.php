<?php

class Property_specifics_model extends CI_model{
	
	public function get_property_type_all(){
	    $this->db->select('property_type.*, count(*) AS type_count');
	    $this->db->join('properties', 'properties.property_type = property_type.id', 'left');
	    $this->db->group_by('property_type.id');
	    $this->db->from('property_type');
	    $query = $this->db->get();
		return $query->result();
	}
	
	public function get_property_type_city($city_id){
	    $this->db->select('property_type.*, count(*) AS type_count');
	    $this->db->join('properties', 'properties.property_type = property_type.id', 'left');
	    $this->db->group_by('property_type.id');
	    $this->db->from('property_type');
	    $this->db->where('properties.location',$city_id);
	    $query = $this->db->get();
		return $query->result();
	}

    /**************************************************************************/
    /************************ Manage Property Type ****************************/
    /**************************************************************************/
   
    public function get_property_type(){
        $this->db->order_by('id','desc');
		$query = $this->db->get('property_type');
		return $query->result();
	}
	
	public function get_property_cat(){
        $this->db->order_by('id','desc');
		$query = $this->db->get('property_category');
		return $query->result();
	}
	
	public function select_create_property($pid){
		$this->db->select('*');
	    $this->db->from('properties');
	    $this->db->where('id',$pid);
	    $query = $this->db->get();
		return $query->result();
	}
	public function get_property_purpose(){
        $this->db->order_by('id','desc');
		$query = $this->db->get('property_purpose');
		return $query->result();
	}
	
	public function insert_property_type(){
	    date_default_timezone_set("Asia/Kolkata");
        $today =  date('Y-m-d h:i:s');
	    $data = array(
	                'name'          => $this->input->post('name'),
	                'created_at'    => $today
	        );
        $this->db->insert('property_type',$data);
        return $this->db->insert_id();
	}
	
	public function update_property_type(){
	    $ptid = $this->input->post('ptid');
	    $data = array(
	                'name'          => $this->input->post('name')
	        );
        $this->db->where('id',$ptid);
        $query = $this->db->update('property_type',$data);
        return $query;
	}
	
	public function remove_property_type(){
	    $ptid = $this->input->post('ptid');
	    $this->db->where('id',$ptid);
	    $query = $this->db->delete('property_type');
	    return $query;
	}
	
	/**************************************************************************/
    /************************ Manage Property Status **************************/
    /**************************************************************************/
    
	public function get_property_status(){
        $this->db->order_by('id','desc');
		$query = $this->db->get('property_status');
		return $query->result();
	}
	
	public function insert_property_status(){
	    $data = array(
	                'name'          => $this->input->post('name')
	        );
        $this->db->insert('property_status',$data);
        return $this->db->insert_id();
	}
	
	public function update_property_status(){
	    $psid = $this->input->post('psid');
	    $data = array(
	                'name'          => $this->input->post('name')
	        );
        $this->db->where('id',$psid);
        $query = $this->db->update('property_status',$data);
        return $query;
	}
	
	public function remove_property_status(){
	    $psid = $this->input->post('psid');
	    $this->db->where('id',$psid);
	    $query = $this->db->delete('property_status');
	    return $query;
	}
	
	/**************************************************************************/
    /************************ Manage Furnish Status ***************************/
    /**************************************************************************/
    
	public function get_furnish_status(){
        $this->db->order_by('id','desc');
		$query = $this->db->get('furnish_status');
		return $query->result();
	}
	
	public function insert_furnish_status(){
	    $data = array(
	                'name'          => $this->input->post('name')
	        );
        $this->db->insert('furnish_status',$data);
        return $this->db->insert_id();
	}
	
	public function update_furnish_status(){
	    $fsid = $this->input->post('fsid');
	    $data = array(
	                'name'          => $this->input->post('name')
	        );
        $this->db->where('id',$fsid);
        $query = $this->db->update('furnish_status',$data);
        return $query;
	}
	
	public function remove_furnish_status(){
	    $fsid = $this->input->post('fsid');
	    $this->db->where('id',$fsid);
	    $query = $this->db->delete('furnish_status');
	    return $query;
	}
	
	/**************************************************************************/
    /************************ Manage Size Parameter ***************************/
    /**************************************************************************/
	
	public function get_size_param(){
        $this->db->order_by('id','desc');
	    $query = $this->db->get('size_parameters');
	    return $query->result();
	}
	
	public function insert_size_parameters(){
	    $data = array(
	                'type'          => $this->input->post('name')
	        );
        $this->db->insert('size_parameters',$data);
        return $this->db->insert_id();
	}
	
	public function update_size_para(){
	    $spid = $this->input->post('spid');
	    $data = array(
	                'type'          => $this->input->post('name')
	        );
        $this->db->where('id',$spid);
        $query = $this->db->update('size_parameters',$data);
        return $query;
	}
	
	public function remove_size_para(){
	    $spid = $this->input->post('spid');
	    $this->db->where('id',$spid);
	    $query = $this->db->delete('size_parameters');
	    return $query;
	}
	
	/**************************************************************************/
    /************************ Manage Amenities ********************************/
    /**************************************************************************/
    
	public function get_amenities(){
        $this->db->order_by('id','desc');
	    $query = $this->db->get('amenities');
	    return $query->result();
	}
	public function get_amenitiestwo(){
	    $this->db->select('*');
        $this->db->from('amenities');
        $this->db->where('property_type',2);
        $query = $this->db->get();
        return $query->result();
	}
	
	public function insert_amenity(){
	    $data = array(
	                'name'          => $this->input->post('name')
	        );
        $this->db->insert('amenities',$data);
        return $this->db->insert_id();
	}
	
	public function update_amenity(){
	    $amid = $this->input->post('amid');
	    $data = array(
	                'name'          => $this->input->post('name')
	        );
        $this->db->where('id',$amid);
        $query = $this->db->update('amenities',$data);
        return $query;
	}
	
	public function remove_amenity(){
	    $amid = $this->input->post('amid');
	    $this->db->where('id',$amid);
	    $query = $this->db->delete('amenities');
	    return $query;
	}
	
	public function get_property_type_id($name){
	    $this->db->select('id');
	    $this->db->from('property_type');
	    $this->db->where('name',$name);
	    $this->db->limit('1');
	    $query = $this->db->get();
	    if($query->num_rows() > 0){
    	    $row = $query->result();
    	    return $row[0]->id;
	    }else{
	        return false;
	    }
	}
	
	public function get_property_location_id($name){
	    $this->db->select('id');
	    $this->db->from('locations');
	    $this->db->where('name',$name);
	    $this->db->limit('1');
	    $query = $this->db->get();
	    if($query->num_rows() > 0){
    	    $row = $query->result();
    	    return $row[0]->id;
	    }else{
	        return false;
	    }
	}
	
	public function get_property_area_id($name){
	    $this->db->select('id');
	    $this->db->from('locations');
	    $this->db->where('name',$name);
	    $this->db->limit('1');
	    $query = $this->db->get();
	    if($query->num_rows() > 0){
    	    $row = $query->result();
    	    return $row[0]->id;
	    }else{
	        return false;
	    }
	}
	
	public function get_property_status_id($name){
	    $this->db->select('id');
	    $this->db->from('property_status');
	    $this->db->where('name',$name);
	    $this->db->limit('1');
	    $query = $this->db->get();
	    if($query->num_rows() > 0){
    	    $row = $query->result();
    	    return $row[0]->id;
	    }else{
	        return false;
	    }
	}
	
	public function get_property_purpose_id($name){
	    $this->db->select('id');
	    $this->db->from('property_purpose');
	    $this->db->where('name',$name);
	    $this->db->limit('1');
	    $query = $this->db->get();
	    if($query->num_rows() > 0){
    	    $row = $query->result();
    	    return $row[0]->id;
	    }else{
	        return false;
	    }
	}
	
	public function get_property_furnish_status_id($name){
	    $this->db->select('id');
	    $this->db->from('furnish_status');
	    $this->db->where('name',$name);
	    $this->db->limit('1');
	    $query = $this->db->get();
	    if($query->num_rows() > 0){
    	    $row = $query->result();
    	    return $row[0]->id;
	    }else{
	        return false;
	    }
	}

}

?>