<?php

class Location_model extends CI_model{

	public function get_locations(){
		$query = $this->db->get('locations');
		return $query->result();
	}

	public function insert_location($data){
		$this->db->insert('locations',$data);
		return $this->db->insert_id();
	}
    
    public function get_areas(){
        $this->db->select('*');
        $this->db->from('locations');
        $query = $this->db->get();
        return $query->result();
    }
    
	public function get_city_areas($data){
		$this->db->where([

			'parent'=>$data['city_id']

			]);
		$query = $this->db->get('locations');
        if($query->num_rows() > 0){
            $result = $query->result();
    		echo form_label('Search for your area');
    		
            $dataCityId = array(
                'name' => 'property_id',
                'type' => 'hidden',
                'value' => $data['property_id']
            );
    
            echo form_input($dataCityId); 
         
            $js = array(
                    'class' => 'form-control',
                    'id' => 'city_areas',
                    'name' => 'location_id'
            );
                                    
    		foreach($result as $areas):
    		           $options[$areas->id] = $areas->name;
    		endforeach;
    		echo form_dropdown('location_id', $options, '',$js);
        }else{
            echo "No area listed for this city! Please contact admin to list your aera.";
        }
	}
	
	public function get_city_areas_home($data){
	    $this->db->where([

			'parent'=>$data['city_id']

			]);
		$query = $this->db->get('locations');

		$result = $query->result();
     
                                
		foreach($result as $areas):
		           $area[$areas->id] = $areas->name;
		endforeach;
		
		return $area;
	}
	
	public function areas_by_city($data){
	    $this->db->where([

			'parent'=>$data

			]);
		$query = $this->db->get('locations');

		$result = $query->result();
		return $result;
	}
	public function getCity_name($city_id){
		$this->db->select('*');
        $this->db->from('locations');
        $this->db->where('id',$city_id);
        $query = $this->db->get();
        return $query->result();
	}

	public function get_city_areas_home_name($data){
	    $this->db->where([

			'parent'=>$data['city_id']

			]);
		$query = $this->db->get('locations');

		$result = $query->result();
     
                                
		foreach($result as $areas):
		           $area[$areas->id] = $areas->name;
		endforeach;
		
		return $area;
	}
}

?>