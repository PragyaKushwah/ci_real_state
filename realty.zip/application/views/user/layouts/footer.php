<!--<button type="button" class="btn btn-primary"  id="fixed_popup" data-toggle="modal" data-target="#exampleModal">-->
<!--  Please Click-->
<!--</button>-->

<!-- Modal -->
<!--<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">-->
<!--  <div class="modal-dialog" role="document">-->
<!--    <div class="modal-content">-->
<!--      <div class="modal-header">-->
<!--        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>-->
<!--        <button type="button" class="close" data-dismiss="modal" aria-label="Close">-->
<!--          <span aria-hidden="true">&times;</span>-->
<!--        </button>-->
<!--      </div>-->
<!--      <div class="modal-body">-->
<!--        ...-->
<!--      </div>-->
<!--      <div class="modal-footer">-->
<!--        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>-->
<!--        <button type="button" class="btn btn-primary">Save changes</button>-->
<!--      </div>-->
<!--    </div>-->
<!--  </div>-->
<!--</div>-->




<a href="whatsapp://send?text=WHATEVER_LINK_OR_TEXT_YOU_WANT_TO_SEND" title="Share on whatsapp">
    <div id="fixed_whatsapp_btn">
        <i class="fab fa-whatsapp"></i>
    </div>
</a>

<?php
   if(isset($page) && ($page=='page')){
?>

<footer class="ftco-footer ftco-footer-2 ftco-section">
   <div class="container">
      <div class="row ">
         <div class="col-md-4">
            <div class="ftco-footer-widget mb-4">
               <div id="footer_logo">
                  <img src="<?php echo base_url()?>assets/images/pakiza_logo.png" alt="pakiza_realty_logo" id="logo" title="pakiza_realty">
               </div>
               <p>Pakiza Realty is a real estate company with 10+ residential township projects in India. We emphasis on contemporary architecture, strong project execution and quality construction which have helped them to launch some superior community residential projects across central India.</p>
               <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                  <li class="ftco-animate"><a href="https://twitter.com/RealtyPakiza"><span class="icon-twitter"></span></a></li>
                  <li class="ftco-animate"><a href="https://www.facebook.com/pg/PakizaRealty"><span class="icon-facebook"></span></a></li>
                  <li class="ftco-animate"><a href="https://www.instagram.com/p/CG4P0JEja-Q/"><span class="icon-instagram"></span></a></li>
               </ul>
            </div>
         </div>
         
         <div class="col-md-2">
            <div class="ftco-footer-widget mb-4 ml-md-4">
               <h2 class="ftco-heading-2">Projects</h2>
               <ul class="list-unstyled">
                  <?php foreach($pakiza_properties as $property){ ?>
                  <li><a href="<?php echo base_url('properties_single'); ?>?id=<?php echo $property->id?>"><?php echo $property->name?></a></li>
                  <?php }?>
               </ul>
            </div>
         </div>
         
         <div class="col-md-2">
            <div class="ftco-footer-widget mb-4 ml-md-4">
               <h2 class="ftco-heading-2">Company</h2>
               <ul class="list-unstyled">
                  <li><a href="<?php echo base_url('home')?>"><span class="icon-long-arrow-right mr-2"></span>Home</a></li>
                  <li><a href="<?php echo base_url('about')?>"><span class="icon-long-arrow-right mr-2"></span>About</a></li>
                  <li><a href="<?php echo base_url('properties')?>"><span class="icon-long-arrow-right mr-2"></span>Projects</a></li>
                  <li><a href="<?php echo base_url('blog')?>"><span class="icon-long-arrow-right mr-2"></span>Blog</a></li>
                  <li><a href="<?php echo base_url('contact')?>"><span class="icon-long-arrow-right mr-2"></span>Contact</a></li>
               </ul>
            </div>
         </div>
         
         
        <div class="col-md-4">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Enquiry Form</h2>
              <!-- <p>Pakiza Realty feels that transparency is more than just a business buzz word. </p>-->
               <form action="<?=base_url();?>User/enquiry_form" method="post" class="enquiry-form" id="footer_form">
                      
                       <input type="text" name="name" class="form-control" placeholder="Enter Name">
                       <input type="email" name="email" class="form-control" placeholder="Enter Email ">
                       
                        <textarea class="form-control" name="message" placeholder="Enter Message"></textarea>
                        <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
               </form>
            </div>
        </div>  
      </div>
      <!--<div class="row">-->
      <!--    <div class="col-md-6  mb-2 d-flex justify-content-center" id="instragram_section">-->
      <!--        <h2>Instagram</h2>-->
      <!--          <div class="flicker-img instragram">-->
      <!--            <a href="https://www.instagram.com/p/CG4P0JEja-Q/"><img src="<?php echo base_url()?>assets/images/pakiza_logo.png" alt="" target="blank"></a>-->
      <!--            <a href="https://www.instagram.com/p/CHFj1hhD-f2/"><img src="<?php echo base_url()?>assets/images/pakiza_logo.png" target="blank" alt=""></a>-->
      <!--            <a href="https://www.instagram.com/p/CHMtWYSjScE/"><img src="<?php echo base_url()?>assets/images/pakiza_logo.png" target="blank" alt=""></a>-->
      <!--            <a href="https://www.instagram.com/p/CGmqW70DU_H/"><img src="<?php echo base_url()?>assets/images/pakiza_logo.png" target="blank" alt=""></a>-->
      <!--            <a href="https://www.instagram.com/p/CGg8ptdDwNJ/"><img src="<?php echo base_url()?>assets/images/pakiza_logo.png" target="blank" alt=""></a>-->
      <!--            <a href="https://www.instagram.com/p/CGWwdbdDXlU/"><img src="<?php echo base_url()?>assets/images/pakiza_logo.png" target="blank" alt=""></a>-->
      <!--          </div>-->
      <!--    </div>  -->
          
      <!--    <div class="col-md-6  mb-2 d-flex justify-content-center" id="instragram_section">-->
      <!--        <h2>Instagram</h2>-->
      <!--          <div class="flicker-img instragram">-->
      <!--            <a href="https://www.instagram.com/p/CG4P0JEja-Q/"><img src="<?php echo base_url()?>assets/images/pakiza_logo.png" alt="" target="blank"></a>-->
      <!--            <a href="https://www.instagram.com/p/CHFj1hhD-f2/"><img src="<?php echo base_url()?>assets/images/pakiza_logo.png" target="blank" alt=""></a>-->
      <!--            <a href="https://www.instagram.com/p/CHMtWYSjScE/"><img src="<?php echo base_url()?>assets/images/pakiza_logo.png" target="blank" alt=""></a>-->
      <!--            <a href="https://www.instagram.com/p/CGmqW70DU_H/"><img src="<?php echo base_url()?>assets/images/pakiza_logo.png" target="blank" alt=""></a>-->
      <!--            <a href="https://www.instagram.com/p/CGg8ptdDwNJ/"><img src="<?php echo base_url()?>assets/images/pakiza_logo.png" target="blank" alt=""></a>-->
      <!--            <a href="https://www.instagram.com/p/CGWwdbdDXlU/"><img src="<?php echo base_url()?>assets/images/pakiza_logo.png" target="blank" alt=""></a>-->
      <!--          </div>-->
      <!--    </div>  -->
      <!--</div>-->
        
         
      
      <div class="row">
         <div class="col-md-12 text-center">
            <p id="copyright">
               Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved - Pakiza Realty
            </p>
         </div>
      </div>
   </div>
</footer>
<!--<div class="col-md">
            <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">Explore</h2>
            <ul class="list-unstyled">
            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Privacy</a></li>
            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Policy</a></li>
            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Terms</a></li>
            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Review</a></li>
            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Features</a></li>
            </ul>
            </div>
            </div>
            <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">Get Started</h2>
            <ul class="list-unstyled">
            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Buy</a></li>
            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Rent</a></li>
            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Payment</a></li>
            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Mortgage</a></li>
            <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Loan</a></li>
            </ul>
            </div>
            </div>-->

<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" /><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00" /></svg></div>
<script src="<?php echo base_url() ?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/jquery-migrate-3.0.1.min.js%2bpopper.min.js%2bbootstrap.min.js.pagespeed.jc.vUO0rUYm-d.js"></script><script>eval(mod_pagespeed_ewIumoUFDf);</script>
<script>eval(mod_pagespeed_QWZKD_Mp3l);</script>
<script>eval(mod_pagespeed_YcONR94Fnv);</script>
<script src="<?php echo base_url() ?>assets/js/jquery.easing.1.3.js%2bjquery.waypoints.min.js%2bjquery.stellar.min.js%2bowl.carousel.min.js.pagespeed.jc._1L9tLpeD8.js"></script><script>eval(mod_pagespeed_KOojltqo7L);</script>
<script>eval(mod_pagespeed_ieIALJV36k);</script>
<script>eval(mod_pagespeed_njh3SPzIjG);</script>
<script>eval(mod_pagespeed_OWcoQUDRjS);</script>
<script src="<?php echo base_url() ?>assets/js/jquery.magnific-popup.min.js%2baos.js%2bjquery.animateNumber.min.js%2bscrollax.min.js%2bgoogle-map.js%2bmain.js.pagespeed.jc.M6qYqD4QuS.js"></script><script>eval(mod_pagespeed_LYYtPw06Sf);</script>
<script>eval(mod_pagespeed_vktxTAoqHu);</script>
<script>eval(mod_pagespeed_D72doYPKfa);</script>
<script>eval(mod_pagespeed_ldt6sfpjZF);</script>
<!--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&amp;sensor=false"></script>-->
<script>eval(mod_pagespeed_oRIAhavrb4);</script>
<script>eval(mod_pagespeed_oE9lCcbcx8);</script>
<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&amp;sensor=false"></script>-->
<!--<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>-->
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
<script defer src="<?php echo base_url() ?>assets/js/beacon.min.js" data-cf-beacon='{"rayId":"673caab028ff0efc","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2021.7.0","si":10}'></script>

<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.0.7/css/swiper.min.css'>
<!--<link rel="stylesheet" href="./style.css">-->
<script src="https://unpkg.com/swiper/swiper-bundle.js"></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.0.7/js/swiper.min.js'></script>
<!--<script  src="./script.js"></script>-->

<script>


    var swiper = new Swiper(".swiper-pillars", {
        slidesPerView: 2,
        spaceBetween: 30,
        autoplay: true,
        loop:true,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
        breakpoints: {
            1024: {
            slidesPerView: 2,
            spaceBetween: 20,
            },
            768: {
            slidesPerView: 2,
            spaceBetween: 20,
            },
            640: {
            slidesPerView: 1,
            spaceBetween: 20,
            },
            320: {
            slidesPerView: 1,
            spaceBetween: 15,
            }
        }
    });
    
</script>
<script>
    var swiper = new Swiper('.home-slider', {
  // Optional parameters
  direction: 'horizontal',
  loop: true,

  // If we need pagination
  pagination: {
    el: '.swiper-pagination',
  },

  // Navigation arrows
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },

  // And if we need scrollbar
  scrollbar: {
    el: '.swiper-scrollbar',
  },
});
</script>
<script>
 var swiper = new Swiper(".swiper-blog", {
        effect: 'slide',
        grabCursor: true,
        slidesPerView: 3,
        spaceBetween: 30,
        loop:true,
        autoplay:{
           delay:3500,
           disableOnInteraction: false,
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
        breakpoints: {
            1024: {
            slidesPerView: 2,
            spaceBetween: 30,
            },
            768: {
            slidesPerView: 2,
            spaceBetween: 30,
            },
            640: {
            slidesPerView: 1,
            spaceBetween: 30,
            },
            320: {
            slidesPerView: 1,
            spaceBetween: 30,
            }
        }
    });
    
</script>
<script>
var swiper = new Swiper('.swiper-container.testimonial_swiper', {
      slidesPerView: 1,
        spaceBetween: 30,
        autoplay: true,
        loop:true,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
        breakpoints: {
            1024: {
            slidesPerView: 1,
            spaceBetween: 20,
            },
            768: {
            slidesPerView: 1,
            spaceBetween: 20,
            },
            640: {
            slidesPerView: 1,
            spaceBetween: 20,
            },
            320: {
            slidesPerView: 1,
            spaceBetween: 15,
            }
        }
    });
</script>
<?php
    
 }
?>




