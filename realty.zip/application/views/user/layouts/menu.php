<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
<div class="container">
<a class="navbar-brand" href="<?php echo base_url('User/index')?>"></a>
<img src="<?php echo base_url()?>assets/images/pakiza_logo.png" alt="pakiza_realty_logo" id="logo" title="pakiza_realty">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
<span class="oi oi-menu"></span> Menu
</button>
 
<div class="collapse navbar-collapse" id="ftco-nav">
<ul class="navbar-nav ml-auto">
<li class="nav-item active"><a href="<?php echo base_url('home')?>" class="nav-link">Home</a></li>
<li class="nav-item active"><a href="<?php echo base_url('properties')?>" class="nav-link">Projects</a></li>
<!--<li class="nav-item active"><a href="<?php echo base_url('agents')?>" class="nav-link">Our Team</a></li>-->
<li class="nav-item active"><a href="<?php echo base_url('blog')?>" class="nav-link">Blog</a></li>
<li class="nav-item active"><a href="<?php echo base_url('about')?>" class="nav-link">About</a></li>
<li class="nav-item active"><a href="<?php echo base_url('contact')?>" class="nav-link">Contact</a></li>
<!--<li class="nav-item cta"><a href="#" class="nav-link"><span>Sign Up</span></a></li>-->
</ul>
</div>
</div>
</nav>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    $(document).ready(function(){
       $(".nav-item li").click(function() {        
    $(".nav-item li.active").removeClass("active");      
    $(this).addClass("active");    
    });
</script>