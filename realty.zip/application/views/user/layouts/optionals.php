<script>
    var swiper = new Swiper(".partnerSwiper", {
       slidesPerView: 5,
       spaceBetween: 30,
       freeMode: true,
       autoplay: true,
       pagination: {
         el: ".swiper-pagination",
         clickable: true,
         breakpoints: {
            768: {
            slidesPerView: 3,
            spaceBetween: 20,
            },
            640: {
            slidesPerView: 2,
            spaceBetween: 20,
            },
            320: {
            slidesPerView: 2,
            spaceBetween: 15,
            }
            }
        }
    });
    
</script>

<script>
    var swiper = new Swiper(".swiper-pillars", {
        slidesPerView: 1,
        spaceBetween: 30,
        autoplay: true,
        loop:true,
        breakpoints: {
            1024: {
            slidesPerView: 2,
            spaceBetween: 20,
            },
            768: {
            slidesPerView: 1,
            spaceBetween: 20,
            },
            640: {
            slidesPerView: 1,
            spaceBetween: 20,
            },
            320: {
            slidesPerView: 1,
            spaceBetween: 15,
            }
        }
    });
    
</script>

<script>
    var swiper = new Swiper(".swiper-blog", {
        effect: "coverflow",
        grabCursor: true,
        centeredSlides: true,
        slidesPerView: "auto",
        coverflowEffect: {
          rotate: 50,
          stretch: 0,
          depth: 100,
          modifier: 1,
          slideShadows: true,
        },
        pagination: {
          el: ".swiper-pagination",
        },
      });    
        
    //     centeredSlides:true,
        
    //     loop:true,
    //     autoplay:{
    //       delay:3500,
    //       disableOnInteraction: false,
    //     },
    //     breakpoints: {
    //         640: {
    //           slidesPerView: 1,
    //           spaceBetween: 50,
    //         },
    //         768: {
    //           slidesPerView: 2,
    //           spaceBetween: 50,
    //         },
    //         1024: {
    //           slidesPerView: 3,
    //           spaceBetween: 30,
    //         },
    //     }
    // });
</script>