<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title><?php if(isset($title)){ echo $title; } ?></title>

<!--[if lt IE 10]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="" />
<meta name="keywords" content="">
<meta name="author" content="OnlineChalo" />

    <!------------------------------------------------------------------->
    <!------------------------LOADS HEADER SCRIPTS----------------------->
    <!------------------------------------------------------------------->
    <?php $this->load->view('user/layouts/header_scripts'); ?>
    
</head>
<body>

<div class="social_bar">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                 <div class="social_icons"></div>
            </div>
            <div class="col-md-6">
                <div class="row float_right">
                    <div class="phone">
                        <a href="tel:9999999999">+91-898-988-8899</a>
                        <div class="img_container"><i class="fab fa-whatsapp"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<nav class="navbar navbar-expand-lg navbar-light bg_light">
    
    <div class="container">
    
      <a class="navbar-brand ml-5" href="#">PAKIZA</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
 
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto mr-5">
          <li class="nav-item active">
            <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Communities</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">About Company</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact Us</a>
          </li>
          
        </ul>
        <form class="form-inline my-2 my-lg-0">
          
          <button class="btn get_in_touch" type="submit">Get In Touch</button>
        </form>
       
       </div>
    </div>
</nav>

<div class="page-content">
    
    
    <!------------------------------------------------------------------->
    <!------------------------LOADS PAGE CONTENT------------------------->
    <!------------------------------------------------------------------->
    <?php $this->load->view($view); ?>
    
    
</div>

<div id="footer">
    <div class="container">
        <div class="footer_1 bg_white">
            <div class="row">
                <div class="logo_section">
                    <img src="uploads/website/pk.jpg">
                </div>
            </div>
            <div class="row">
                <div class="social_links">
                    
                </div>
            </div>
            <div class="row map">
                <h1>Contact Us</h1>
                <div class="map_container">
                    <img src="uploads/website/map1.jpg">
                </div>
            </div>
             <div class="row">
                <div class="footer_links">
                    <a href="#">Home</a>
                    <a href="#">About Us</a>
                    <a href="#">Director's Desk</a>
                    <a href="#">Properties</a>
                    <a href="#">Blog</a>
                    <a href="#">Careers</a>
                    <a href="#">Building Documentation</a>
                </div>
            </div>
             <div class="row">
                <div class="col-md-3">
                    <h5>India</h5>
                    <p>Commercial Plot No.3,</p>
                    <p>Opp. Prestige College,</p>
                    <p>Near Bombay Hospital,</p>
                    <p>PU-4, Indore (M.P.)</p>
                </div>
                <div class="col-md-3">
                    <h5>UAE</h5>
                    <p>JBR,</p>
                    <p>Dubai,</p>
                    <p>United Arab Emirates</p>
                </div>
            
                <div class="col-md-6 align_right">
                    <h5>Contact Us</h5>
                    <p>+971-054-982-0897</p>
                    <p>0731-42907185</p>
                    <p>info@pakizaproperties.com</p> 
                </div>
            </div>
        </div>
        <div class="footer_2 bg_black">
            <div class="row">
                <div class="col-md-6">
                    <p>Copyrights &copy;2021-22 | Pakiza Properties</p>
                </div>
                <div class="col-md-2">
                    <a href="#">Cookie Policy</a>
                </div>
                <div class="col-md-2">
                    <a href="#">Terms and Condition</a>
                </div>
                <div class="col-md-2">
                    <a href="#">Privacy Policy</a>
                </div>
            </div>
        </div>
    </div>
</div>



    
    <!------------------------------------------------------------------->
    <!----------------------LOADS FOOTER SCRIPTS------------------------->
    <!------------------------------------------------------------------->
    <?php $this->load->view('user/layouts/footer_scripts'); ?>


</body>

</html>
