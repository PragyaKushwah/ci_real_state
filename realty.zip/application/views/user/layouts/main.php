<!DOCTYPE html>
<html lang="en">

<head>
<title><?php if(isset($title)){ echo $title; } ?></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<?php $this->load->view('user/layouts/header'); ?>
</head>
<body>
        
<?php $this->load->view('user/layouts/menu'); ?>


     

<?php $this->load->view($view); ?>


      

<?php $this->load->view('user/layouts/footer'); ?>
</body>

</html>