<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&amp;sensor=false"></script>

<section class="hero-wrap hero-wrap-2" style="background-image:url(<?php echo base_url()?>assets/images/page_header.jpg)" data-stellar-background-ratio="0.5">
   <div class="overlay"></div>
   <div class="container">
      <div class="row no-gutters slider-text align-items-center justify-content-center">
         <div class="col-md-9 ftco-animate text-center">
            <?php foreach($pakiza_properties as $property){?>
                <h1 class="mb-2 bread"><?=$property->name;?></h1>
            <?php } ?>
            <p class="breadcrumbs"><span class="mr-2"><a href="<?php echo base_url() ?>">Home <i class="ion-ios-arrow-forward"></i></a></span> <span class="mr-2"><a href="<?php echo base_url() ?>properties">Projects</a></span></p>
         </div>
      </div>
   </div>
</section>
<section class="ftco-section">
   <div class="container">
      <div class="row">
         <div class="col-md-12 properties-single">
            <?php foreach($pakiza_properties as $property){?>
                <h1><?php echo $property->name; ?></h1> 
            <?php } ?>
            <div class="single-slider owl-carousel">
               <?php foreach($pakiza_galleries as $gallery){
                  if($gallery){
                  ?>
                   <div class="item">
                      <div class="properties-img" style="background-image:url(<?php echo base_url() ?>assets/uploads/gallery/<?php echo $gallery->gallery_image?> )">
                         <p class="title"><?php echo $gallery->title;?></p>
                      </div>
                   </div>
               <?php
                  }else{
                      $url = base_url('home');
                      redirect($url);
                  }
                  } ?>
               <!--<div class="item">
                  <div class="properties-img" style="background-image:url(<?php echo base_url()?>assets/images/work-2.jpg)"></div>
                  </div>
                  <div class="item">
                  <div class="properties-img" style="background-image:url(<?php echo base_url()?>assets/images/xwork-3.jpg.pagespeed.ic.BKjj1CYFBk.jpg)"></div>
                  </div>-->
            </div>
            <?php foreach($pakiza_properties as $property){?>
            <?php $property_name =  $property->name;$property_desc = $property->description;$property_coordinates = $property->coordinates?>
            <?php }?>
            <div class="col-md-12 Properties-single mt-4 mb-5 ftco-animate">
               <span class="loc"><i class="icon-map"></i> About <?=$property_name;?></span>
               <p><?php echo $property_desc ?></p>
               
               <!--<div class="d-md-flex mt-5 mb-5">-->
               <!--   <ul>-->
               <!--      <li><span>Lot Area: </span> 1,250 SQ FT</li>-->
               <!--      <li><span>Bed Rooms: </span> 4</li>-->
               <!--      <li><span>Bath Rooms: </span> 4</li>-->
               <!--      <li><span>Garage: </span> 1</li>-->
               <!--   </ul>-->
               <!--   <ul class="ml-md-5">-->
               <!--      <li><span>Floor Area: </span> 1,300 SQ FT</li>-->
               <!--      <li><span>Year Build:: </span> 2018</li>-->
               <!--      <li><span>Stories: </span> 1</li>-->
               <!--      <li><span>Roofing: </span> New</li>-->
               <!--   </ul>-->
               <!--</div>-->
               <!--<p>When she reached the first hills of the Italic Mountains, she had a last view back on the skyline of her hometown Bookmarksgrove, the headline of Alphabet Village and the subline of her own road, the Line Lane. Pityful a rethoric question ran over her cheek, then she continued her way.</p>-->
            </div>
            <!--<div class="col-md-12 properties-single ftco-animate mb-5 mt-4">-->
            <!--   <h3 class="mb-4">Take A Tour</h3>-->
            <!--   <div class="block-16">-->
            <!--      <figure>-->
            <!--         <img src="<?php echo base_url()?>assets/images/ximage_2.jpg.pagespeed.ic.6AM6jjh_h4.jpg" alt="Image placeholder" class="img-fluid">-->
            <!--         <a href="https://vimeo.com/45830194" class="play-button popup-vimeo"><span class="icon-play"></span></a>-->
            <!--      </figure>-->
            <!--   </div>-->
            <!--</div>-->
            <!--<div class="col-md-12 properties-single ftco-animate mb-5 mt-4">-->
            <!--   <h4 class="mb-4">Review &amp; Ratings</h4>-->
            <!--   <div class="row">-->
            <!--      <div class="col-md-6">-->
            <!--         <form method="post" class="star-rating">-->
            <!--            <div class="form-check">-->
            <!--               <input type="checkbox" class="form-check-input" id="exampleCheck1">-->
            <!--               <label class="form-check-label" for="exampleCheck1">-->
            <!--                  <p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i> 100 Ratings</span></p>-->
            <!--               </label>-->
            <!--            </div>-->
            <!--            <div class="form-check">-->
            <!--               <input type="checkbox" class="form-check-input" id="exampleCheck1">-->
            <!--               <label class="form-check-label" for="exampleCheck1">-->
            <!--                  <p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star-o"></i> 30 Ratings</span></p>-->
            <!--               </label>-->
            <!--            </div>-->
            <!--            <div class="form-check">-->
            <!--               <input type="checkbox" class="form-check-input" id="exampleCheck1">-->
            <!--               <label class="form-check-label" for="exampleCheck1">-->
            <!--                  <p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star-o"></i><i class="icon-star-o"></i> 5 Ratings</span></p>-->
            <!--               </label>-->
            <!--            </div>-->
            <!--            <div class="form-check">-->
            <!--               <input type="checkbox" class="form-check-input" id="exampleCheck1">-->
            <!--               <label class="form-check-label" for="exampleCheck1">-->
            <!--                  <p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star-o"></i><i class="icon-star-o"></i><i class="icon-star-o"></i> 0 Ratings</span></p>-->
            <!--               </label>-->
            <!--            </div>-->
            <!--            <div class="form-check">-->
            <!--               <input type="checkbox" class="form-check-input" id="exampleCheck1">-->
            <!--               <label class="form-check-label" for="exampleCheck1">-->
            <!--                  <p class="rate"><span><i class="icon-star"></i><i class="icon-star-o"></i><i class="icon-star-o"></i><i class="icon-star-o"></i><i class="icon-star-o"></i> 0 Ratings</span></p>-->
            <!--               </label>-->
            <!--            </div>-->
            <!--         </form>-->
            <!--      </div>-->
            <!--   </div>-->
            <!--</div>-->
            <div class="row col-md-12">
             <div class='col-md-6 col-sm-12'>
               <?php 
                    if(isset($property->youtube_embed_url)){
                        if(!empty($property->youtube_embed_url)){
               
                        echo $property->youtube_embed_url; 
                    }
                }
               ?>
               </div>
               <script> 
            var map;
            var marker =[];
           /* var ltlng = <?php echo $property->coordinates ?>
             var coordinate=  ltlng.split(',')
             var lt  = parseFloat(coordinate[0]);
             var lng = parseFloat(coordinate[1]);*/
            var myLatlng = new google.maps.LatLng(22.7358121,75.9241626);
           /* var geocoder = new google.maps.Geocoder();
            var infowindow = new google.maps.InfoWindow();*/
         function initialize(){
                var mapOptions = {
                    zoom: 18,
                    center: myLatlng,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };

		       
                map = new google.maps.Map(document.getElementById("map"), mapOptions);
                
                  

	                marker = new google.maps.Marker({
	                    map: map,
	                    position: myLatlng,
	                    draggable: true 
	                });     
                
	                
                               
	                
	              
         }
            
            google.maps.event.addDomListener(window, 'load', initialize);
        </script>  
               <div class='col-md-6 col-sm-12'>
                <?php if($property_name == 'Pakiza Greens'){?>
                 <!--<div id="map" style="width:100%;height:100%;"></div>-->
                 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4504.284481817445!2d75.92501597586391!3d22.7353010546258!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3962e3df0d44a04f%3A0x1e11eebd0af55dcd!2sPakiza%20greens!5e0!3m2!1sen!2sin!4v1628936297809!5m2!1sen!2sin" width="100%" height="315px" style="border:1;" allowfullscreen="" loading="lazy"></iframe>
                <?php }else if($property_name == 'Dewas Lifestyle'){ ?>
                
                 <!--<div id="map" style="width:100%;height:100%;"></div>-->
                 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3672.87436868802!2d76.02324951478444!3d22.991646823253085!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3963171ce4b1152b%3A0x46210ccec454831f!2sDewas%20Lifestyle%201%20%26%202!5e0!3m2!1sen!2sin!4v1628936355212!5m2!1sen!2sin" width="100%" height="315px" style="border:1;" allowfullscreen="" loading="lazy"></iframe>
                <?php }elseif($property_name == 'Pakiza City'){ ?>
                
                 <!--<div id="map" style="width:100%;height:100%;"></div>-->
                 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3682.357725697336!2d75.9319464147789!3d22.64044733618287!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3962e52d59775367%3A0x84f8d03f5cc11e3f!2sPakiza%20City!5e0!3m2!1sen!2sin!4v1628936385387!5m2!1sen!2sin" width="100%" height="315px" style="border:1;" allowfullscreen="" loading="lazy"></iframe>
                <?php }else if($property_name == 'Pakiza Lifestyle'){  ?>
               
                 <!--<div id="map" style="width:100%;height:100%;"></div>-->
                 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3679.807651809997!2d75.92475411478037!3d22.735389632705687!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3962e294270dcadf%3A0xe1e780e0f23ba391!2sPakiza%20Lifestyle!5e0!3m2!1sen!2sin!4v1628936410532!5m2!1sen!2sin" width="100%" height="315px" style="border:1;" allowfullscreen="" loading="lazy"></iframe>
                <?php }else if($property_name == 'Pakiza GreenVille'){  ?>
               
                 <!--<div id="map" style="width:100%;height:100%;"></div>-->
                 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3679.796149338988!2d75.92416261478043!3d22.73581703268994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3962e29686abcd55%3A0x76d573ac3b518b5a!2sPakiza%20Green%20Ville!5e0!3m2!1sen!2sin!4v1628936431947!5m2!1sen!2sin" width="100%" height="315px" style="border:1;" allowfullscreen="" loading="lazy"></iframe>
                <?php } ?>
               </div>
            </div>   
            
         </div>
      </div>
   </div>
</section>

