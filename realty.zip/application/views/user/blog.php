<section class="hero-wrap hero-wrap-2" style="background-image:url(<?php echo base_url()?>assets/images/page_header.jpg)" data-stellar-background-ratio="0.5">
   <div class="overlay"></div>
   <div class="container">
      <div class="row no-gutters slider-text align-items-center justify-content-center">
         <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Blog</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="<?php echo base_url() ?>">Home <i class="ion-ios-arrow-forward"></i></a></span> <span><a href="<?php echo base_url() ?>blog">Blogs</a></span></p>
         </div>
      </div>
   </div>
</section>
<section class="ftco-section">
   <div class="container">
      <div class="row">
        <div class="col-md-9 ">
            <div class="row">
             <!--code for dynamic blog added here-->
             <?php foreach($blog_details as $blog){ ?>
             <div class="col-md-4  col-sm-12 ftco-animate">
                <div class="blog-entry blog_section">
                   <a href="<?php echo base_url('blog_single')?>?id=<?php echo $blog->blog_id ?>" class="block-20" style="background-image:url(<?php echo base_url()?>assets/uploads/blogs/<?php echo $blog->blog_image?>">
                   </a>
                   <div class="text text-center">
                      <div class="meta mb-2">
                         <div><a href="#"><?php echo $blog->created_date ?></a></div>
                         <div><a href="#">Admin</a></div>
                         <div><a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a></div>
                      </div>
                      <div class="desc">
                         <h3 class="heading"><a href="<?php echo base_url('blog_single')?>?id=<?php echo $blog->blog_id ?>"><?php echo $blog->blog_intro ?></a></h3>
                         <h3 class="heading"><a href="<?php echo base_url('blog_single')?>?id=<?php echo $blog->blog_id ?>" class="btn-custom">Read More<span class="ml-2 ion-ios-arrow-forward"></span></a></h3>
                      </div>
                   </div>
                </div>
             </div>
             <?php } ?>
            </div>
        </div>
        <div class="col-md-3">
                  <h3 class="mb-4 text-center">Instagram</h3>
                    <div class="flicker-img social_section">
                        <div class="row">
                            <div class="col-md-6">
                                <a href="https://www.instagram.com/p/CG4P0JEja-Q/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/instagram/pakiza_insta1.PNG" alt="" ></div></a>
                            </div>
                            <div class="col-md-6">
                                <a href="https://www.instagram.com/p/CHFj1hhD-f2/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/instagram/pakiza_green_insta.PNG"  alt=""></div></a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <a href="https://www.instagram.com/p/CG4P0JEja-Q/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/instagram/pakiza_insta1.PNG" alt=""></div></a>
                            </div>
                            <div class="col-md-6">
                                <a href="https://www.instagram.com/p/CGmqW70DU_H/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/instagram/pakiza_insta4.PNG"  alt=""></div></a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <a href="https://www.instagram.com/p/CGg8ptdDwNJ/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/instagram/pakiza_instagram5.PNG" alt=""></div></a>
                            </div>
                            <div class="col-md-6">
                                <a href="https://www.instagram.com/p/CGWwdbdDXlU/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/instagram/pakiza_insta6.PNG" alt=""></div></a>
                            </div>
                        </div>
                    </div>
              
           
        </div>
      </div>
      <div class="row no-gutters my-5">
         <div class="col text-center">
            <div class="block-27">
               <ul>
                  <!--<li><a href="#">&lt;</a></li>
                     <li class="active"><span>1</span></li>-->
                  <!--<li><a href="#">2</a></li>
                     <li><a href="#">3</a></li>
                     <li><a href="#">4</a></li>
                     <li><a href="#">5</a></li>
                     <li><a href="#">&gt;</a></li>-->
               </ul>
            </div>
         </div>
      </div>
   </div>
</section>

