<section class="hero-wrap hero-wrap-2" style="background-image:url(<?php echo base_url()?>assets/images/xbg_4.jpg.pagespeed.ic.OdZ0O5MoOw.jpg)" data-stellar-background-ratio="0.5">
	<div class="overlay"></div>
	<div class="container">
		<div class="row no-gutters slider-text align-items-center justify-content-center">
			<div class="col-md-9 ftco-animate text-center">
			    <?php foreach($blog_details as $blog){ ?>
			    <h1 class="mb-2 bread"><?php echo $blog->blog_intro ?></h1>
			    <?php } ?>
				<p class="breadcrumbs"><span class="mr-2"><a href="<?php echo base_url() ?>">Home <i class="ion-ios-arrow-forward"></i></a></span> <span class="mr-2"><a href="<?php echo base_url() ?>blog">Blogs</a></p>
			</div>
		</div>
	</div>
</section>
<section class="ftco-section">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 ftco-animate">
				<!--added here-->
				<?php foreach($blog_details as $blog){ ?>
					<p> <img src="<?php echo base_url()?>assets/uploads/blogs/<?php echo $blog->blog_image?>" alt="" class="img-fluid"> </p>
					<h2 class="mb-3"><?php echo $blog->blog_intro ?></h2>
					<div>
						<?php echo $blog->blog_description ?>
					</div>
				<?php } ?>
						<!--
<p>
<img src="<?php echo base_url()?>assets/images/b2.jpg" alt="" class="img-fluid">
</p>
<h2 class="mb-3 mt-5">#2.Indore: Landlords, tenants on collision course, police plaints on the rise</h2>
<p align="justify">INDORE: Tensions have started to mount between landlords and tenants over rent collection in Indore as the nation entered the first phase of Unlock 1. Many such disputes have been reported at various police stations. While students claim that they have been receiving threat calls from their renters, landlords claim that showing compassion in times of financial hardships is proving to be very difficult.
</p>
<p align="justify">The man has threatened that he will throw away my belongings if I don’t pay the dues immediately,” Vatsal told TOI. He added that he had been taking care of his rent and college fees by working in a call centre but that isn’t working out anymore. To address the tenants’ woes, district collector Manish Singh had issued an order in which it was stated that the landlords should be considerate towards the tenants and should give them time to pay the dues while understanding the situation.</p>
<p align="justify"> DIG Harinarayanachari Mishra said that they are addressing such complaints that are being received with an amicable discussion between both the parties. “If the dispute goes out of hands, a case is registered,” he said.

This was, however, misunderstood by many tenants who started fighting with their landlords claiming that there was a waiver of at least one month rent. ADM BBS Tomar cleared this by saying that the order did not say that there was a waiver. “It advised the landlords to be considerate towards the tenants,” he said.</p>
<p align="justify">Shrishthi Verma (25, name changed) from Ashok Nagar had faced a breakdown when suddenly her landlady had asked her to leave during the lockdown pointing out that she never cleaned the common area and did not keep the room clean. “I had nowhere to go. Even police officials from Bhanwarkuan police station couldn’t help me when I called them for help. It was only after I called my husband and other relatives that they made her understand that it was impossible for me to switch rooms during that time,” said Shrishthi.</p>


<p>
<img src="<?php echo base_url()?>assets/images/b3.jpg" alt="" class="img-fluid">
</p>
<h2 class="mb-3 mt-5">#3.Indore: About 2,000 allottees to get plots in March</h2>
<p align="justify">INDORE: As many as 2000 people, who are victims of tainted housing cooperatives societies and waiting to get justice for decades, will be allotted plots by March-end. They are eligible members of 17 housing cooperative societies and will be allotted the plots under second phase of district administration’s drive against fake and corrupt cooperative
</p>
<p align="justify">In presence of senior officials of district administration, cooperatives, Indore Development Authority, Indore Municipal Corporation and town and country planning, Tripathi on Saturday reviewed investigation against housing cooperative societies on radar. During the meeting, he learnt that there were 169 plots with ‘single’ property registration allotted in a colony developed by Jagruti Griha Nirman Sanstha, while 90 plots were sold multiple times to 211 people.</p>
<p align="justify">
    “There are clear instructions from our chief minister to lead investigation against housing cooperative societies and provide justice to eligible members by allotting them plots/flats. Instructions have also been issued for preparations of third phase of the drive,” divisional commissioner Akash Tripathi said.</p>
<p align="justify">Many people residing outside the state have been made members in Jagruti Griha Nirman Sanstha. Also, irregularities were found in its records during investigation.
</p>
<p align="justify">IDA and cooperative department have issued required permissions for allotment of plots to members of the society - Geeta Nagar Griha Nirman Sanstha. Now only some clearances from nazul department are awaited.
</p>
<p align="justify">During the meeting, divisional commissioner issued show-cause notice to a tehsildar for allegedly showing negligence in following instructions issued for investigation against Karmachari Griha Nirman Sanstha.
</p>
<p>Source: Economic Times
</p>

<p>
<img src="<?php echo base_url()?>assets/images/b4.jpg" alt="" class="img-fluid">
</p>
<h2 class="mb-3 mt-5">#4.Indore: Landlords, tenants on collision course, police plaints on the rise</h2>
<p align="justify">INDORE: Tensions have started to mount between landlords and tenants over rent collection in Indore as the nation entered the first phase of Unlock 1. Many such disputes have been reported at various police stations. While students claim that they have been receiving threat calls from their renters, landlords claim that showing compassion in times of financial hardships is proving to be very difficult.
</p>
<p align="justify">The man has threatened that he will throw away my belongings if I don’t pay the dues immediately,” Vatsal told TOI. He added that he had been taking care of his rent and college fees by working in a call centre but that isn’t working out anymore. To address the tenants’ woes, district collector Manish Singh had issued an order in which it was stated that the landlords should be considerate towards the tenants and should give them time to pay the dues while understanding the situation.</p>
<p align="justify"> DIG Harinarayanachari Mishra said that they are addressing such complaints that are being received with an amicable discussion between both the parties. “If the dispute goes out of hands, a case is registered,” he said.</p>
<p align="justify">This was, however, misunderstood by many tenants who started fighting with their landlords claiming that there was a waiver of at least one month rent. ADM BBS Tomar cleared this by saying that the order did not say that there was a waiver. “It advised the landlords to be considerate towards the tenants,” he said.</p>
<p align="justify">Shrishthi Verma (25, name changed) from Ashok Nagar had faced a breakdown when suddenly her landlady had asked her to leave during the lockdown pointing out that she never cleaned the common area and did not keep the room clean. “I had nowhere to go. Even police officials from Bhanwarkuan police station couldn’t help me when I called them for help. It was only after I called my husband and other relatives that they made her understand that it was impossible for me to switch rooms during that time,” said Shrishthi.</p>

<p>
<img src="<?php echo base_url()?>assets/images/b5.jpg" alt="" class="img-fluid">
</p>
<h2 class="mb-3 mt-5">#5.Indore: About 2,000 allottees to get plots in March</h2>
<p align="justify">INDORE: As many as 2000 people, who are victims of tainted housing cooperatives societies and waiting to get justice for decades, will be allotted plots by March-end. They are eligible members of 17 housing cooperative societies and will be allotted the plots under second phase of district administration’s drive against fake and corrupt cooperative</p>
<p align="justify">In presence of senior officials of district administration, cooperatives, Indore Development Authority, Indore Municipal Corporation and town and country planning, Tripathi on Saturday reviewed investigation against housing cooperative societies on radar. During the meeting, he learnt that there were 169 plots with ‘single’ property registration allotted in a colony developed by Jagruti Griha Nirman Sanstha, while 90 plots were sold multiple times to 211 people.</p>
<p align="justify"> “There are clear instructions from our chief minister to lead investigation against housing cooperative societies and provide justice to eligible members by allotting them plots/flats. Instructions have also been issued for preparations of third phase of the drive,” divisional commissioner Akash Tripathi said.</p>
<p align="justify">Many people residing outside the state have been made members in Jagruti Griha Nirman Sanstha. Also, irregularities were found in its records during investigation.</p>
<p align="justify">IDA and cooperative department have issued required permissions for allotment of plots to members of the society - Geeta Nagar Griha Nirman Sanstha. Now only some clearances from nazul department are awaited.
</p>
<p align="justify">During the meeting, divisional commissioner issued show-cause notice to a tehsildar for allegedly showing negligence in following instructions issued for investigation against Karmachari Griha Nirman Sanstha.</p>
<p align="justify">Source: Economic Times
</p>

<p>
<img src="<?php echo base_url()?>assets/images/b6.jpg" alt="" class="img-fluid">
</p>
<h2 class="mb-3 mt-5">#6.Property registrations up 6% in Indore district despite pandemic</h2>
<p align="justify">INDORE: Property registrations during the 9-day Navratri festival this year jumped by around 6 per cent on a year-on-year basis led by an increase in sales of ready-to-move in residential apartments and plots. Surpassing last year’s figures, the festival season saw sales of 3,371 property clocking income of Rs 36 crore. Last year during Navratri from September 29, 2019 to October 7, 2019, the revenues from property registrations were Rs 34 crore from sale of 2,577 property.</p>
<p align="justify">Last year during Navratri from September 29, 2019 to October 7, 2019, the revenues from property registrations were Rs 34 crore from sale of 2,577 property.</p>
<p align="justify" >District registrar, Balkrishna More said, “Number of property sold this year in Navratri has surpassed last year’s figures during the same nine-day festival. Property registrations have been encouraging in past months with most sales happening in the affordable category.” In Navratri, highest property sales were recorded on October 22 with 607 documents and income of Rs 7 crore. Residential property on bypass, Nipaniya, Rau, Mhow have witnessed encouraging enquiries post Covid while premium property have still not picked up, said realtors and real estate agents. A real estate consultant Arvind Gupta said, “A lot of pent-up demand is coming in the market. People holding back purchases are now finalizing the deals. Service class customers are the main buyers looking for affordable category houses.” In FY 2019/20, revenues from property registrations were Rs 1,173 crore as against Rs 1,134 crore a year ago, according to the registrar office.</p>-->
						<!--till here-->
						<!--<div class="tag-widget post-tag-container mb-5 mt-5">
							<div class="tagcloud"> <a href="#" class="tag-cloud-link">Life</a> <a href="#" class="tag-cloud-link">Sport</a> <a href="#" class="tag-cloud-link">Tech</a> <a href="#" class="tag-cloud-link">Travel</a> </div>
						</div>
						<div class="about-author d-flex p-4 bg-light">
							<div class="bio mr-5"> <img src="<?php echo base_url()?>assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg" alt="Image placeholder" class="img-fluid mb-4"> </div>
							<div class="desc">
								<h3>George Washington</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus itaque, autem necessitatibus voluptate quod mollitia delectus aut, sunt placeat nam vero culpa sapiente consectetur similique, inventore eos fugit cupiditate numquam!</p>
							</div>
						</div>-->
					<!--	<div class="pt-5 mt-5">
							<h3 class="mb-5 h4 font-weight-bold">6 Comments</h3>
							<ul class="comment-list">
								<li class="comment">
									<div class="vcard bio"> <img src="<?php echo base_url()?>assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg" alt="Image placeholder"> </div>
									<div class="comment-body">
										<h3>John Doe</h3>
										<div class="meta mb-2">January 03, 2019 at 2:21pm</div>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem laborum necessitatibus, ipsam impedit vitae autem, eum officia, fugiat saepe enim sapiente iste iure! Quam voluptas earum impedit necessitatibus, nihil?</p>
										<p><a href="#" class="reply">Reply</a></p>
									</div>
								</li>
								<li class="comment">
									<div class="vcard bio"> <img src="<?php echo base_url()?>assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg" alt="Image placeholder"> </div>
									<div class="comment-body">
										<h3>John Doe</h3>
										<div class="meta mb-2">January 03, 2019 at 2:21pm</div>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem laborum necessitatibus, ipsam impedit vitae autem, eum officia, fugiat saepe enim sapiente iste iure! Quam voluptas earum impedit necessitatibus, nihil?</p>
										<p><a href="#" class="reply">Reply</a></p>
									</div>
									<ul class="children">
										<li class="comment">
											<div class="vcard bio"> <img src="<?php echo base_url()?>assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg" alt="Image placeholder"> </div>
											<div class="comment-body">
												<h3>John Doe</h3>
												<div class="meta mb-2">January 03, 2019 at 2:21pm</div>
												<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem laborum necessitatibus, ipsam impedit vitae autem, eum officia, fugiat saepe enim sapiente iste iure! Quam voluptas earum impedit necessitatibus, nihil?</p>
												<p><a href="#" class="reply">Reply</a></p>
											</div>
											<ul class="children">
												<li class="comment">
													<div class="vcard bio"> <img src="<?php echo base_url()?>assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg" alt="Image placeholder"> </div>
													<div class="comment-body">
														<h3>John Doe</h3>
														<div class="meta mb-2">January 03, 2019 at 2:21pm</div>
														<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem laborum necessitatibus, ipsam impedit vitae autem, eum officia, fugiat saepe enim sapiente iste iure! Quam voluptas earum impedit necessitatibus, nihil?</p>
														<p><a href="#" class="reply">Reply</a></p>
													</div>
													<ul class="children">
														<li class="comment">
															<div class="vcard bio"> <img src="<?php echo base_url()?>assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg" alt="Image placeholder"> </div>
															<div class="comment-body">
																<h3>John Doe</h3>
																<div class="meta mb-2">January 03, 2019 at 2:21pm</div>
																<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem laborum necessitatibus, ipsam impedit vitae autem, eum officia, fugiat saepe enim sapiente iste iure! Quam voluptas earum impedit necessitatibus, nihil?</p>
																<p><a href="#" class="reply">Reply</a></p>
															</div>
														</li>
													</ul>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								<li class="comment">
									<div class="vcard bio"> <img src="<?php echo base_url()?>assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg" alt="Image placeholder"> </div>
									<div class="comment-body">
										<h3>John Doe</h3>
										<div class="meta mb-2">January 03, 2019 at 2:21pm</div>
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem laborum necessitatibus, ipsam impedit vitae autem, eum officia, fugiat saepe enim sapiente iste iure! Quam voluptas earum impedit necessitatibus, nihil?</p>
										<p><a href="#" class="reply">Reply</a></p>
									</div>
								</li>
							</ul>
							<div class="comment-form-wrap pt-5">
								<h3 class="mb-5 h4 font-weight-bold">Leave a comment</h3>
								<form action="#" class="p-5 bg-light">
									<div class="form-group">
										<label for="name">Name *</label>
										<input type="text" class="form-control" id="name"> </div>
									<div class="form-group">
										<label for="email">Email *</label>
										<input type="email" class="form-control" id="email"> </div>
									<div class="form-group">
										<label for="website">Website</label>
										<input type="url" class="form-control" id="website"> </div>
									<div class="form-group">
										<label for="message">Message</label>
										<textarea name="" id="message" cols="30" rows="10" class="form-control"></textarea>
									</div>
									<div class="form-group">
										<input type="submit" value="Post Comment" class="btn py-3 px-4 btn-primary"> </div>
								</form>
							</div>
						</div>-->
			</div>
			<div class="col-lg-4 sidebar ftco-animate">
				<!--<div class="sidebar-box">
					<form action="#" class="search-form">
						<div class="form-group"> <span class="icon icon-search"></span>
							<input type="text" class="form-control" placeholder="Type a keyword and hit enter"> </div>
					</form>
				</div>
				<div class="sidebar-box ftco-animate">
					<h3>Category</h3>
					<ul class="categories">
						<li><a href="#">Real Estate <span></span></a></li>
						<li><a href="#">Townships <span></span></a></li>
						<li><a href="#">Property <span></span></a></li>
						<li><a href="#">Investment <span></span></a></li>
						<li><a href="#">Row Houses <span></span></a></li>
						<li><a href="#">Villa <span></span></a></li>
						<li><a href="#">Luxurious Home <span></span></a></li>
					</ul>
				</div>-->
				<div class="sidebar-box ftco-animate">
					<h3>News and Blog Updates</h3>
					<?php
					    $i = 0;
					    foreach($blog_list as $blogs){
					?>
    					
        					<div class="block-21 mb-4 d-flex">
        						<a class="blog-img mr-4" style="background-image:url(<?php echo base_url()?>assets/uploads/blogs/<?php echo $blogs->blog_image; ?>)"></a>
        						<div class="text">
        							<h3 class="heading"><a href="<?php echo base_url('blog_single')?>?id=<?php echo $blogs->blog_id ?>"><?php echo $blogs->blog_intro; ?></a></h3>
        							<!--<div class="meta">-->
        								<!--< div><a href="#"><span class="icon-calendar"></span> Oct. 04, 2018</a></div>-->
        								<!--<div><a href="#"><span class="icon-person"></span> Dave Lewis</a></div>-->
        								<!--<div><a href="#"><span class="icon-chat"></span> 19</a></div>-->
        							<!--</div>-->
        						</div>
        					</div>
					<?
    					    $i++;
    					    if($i == 4){
    					        break;
    					    }
					    }
					?>
					
					<!--<div class="block-21 mb-4 d-flex">-->
					<!--	<a class="blog-img mr-4" style="background-image:url(<?php echo base_url()?>assets/images/b2.jpg)"></a>-->
					<!--	<div class="text">-->
					<!--		<h3 class="heading"><a href="#">Indore: Landlords, tenants on collision course, police plaints on the rise</a></h3>-->
					<!--		<div class="meta">-->
					<!--			<div><a href="#"><span class="icon-calendar"></span> Oct. 04, 2018</a></div>-->
					<!--			<div><a href="#"><span class="icon-person"></span> Dave Lewis</a></div>-->
					<!--			<div><a href="#"><span class="icon-chat"></span> 19</a></div>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--</div>-->
					<!--<div class="block-21 mb-4 d-flex">-->
					<!--	<a class="blog-img mr-4" style="background-image:url(<?php echo base_url()?>assets/images/b3.jpg)"></a>-->
					<!--	<div class="text">-->
					<!--		<h3 class="heading"><a href="#">Indore: About 2,000 allottees to get plots in March</a></h3>-->
					<!--		<div class="meta">-->
					<!--			<div><a href="#"><span class="icon-calendar"></span> Oct. 04, 2018</a></div>-->
					<!--			<div><a href="#"><span class="icon-person"></span> Dave Lewis</a></div>-->
					<!--			<div><a href="#"><span class="icon-chat"></span> 19</a></div>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--</div>-->
				</div>
				<div class="sidebar-box ftco-animate">
				<!--	<h3>Tag Cloud</h3>-->
					<ul class="tagcloud m-0 p-0">
						<!--<a href="#" class="tag-cloud-link">House</a>
<a href="#" class="tag-cloud-link">Office</a>
<a href="#" class="tag-cloud-link">Land</a>
<a href="#" class="tag-cloud-link">Building</a>
<a href="#" class="tag-cloud-link">Table</a>
<a href="#" class="tag-cloud-link">Intrior</a>
<a href="#" class="tag-cloud-link">Exterior</a>--><!--<a href="#" class="tag-cloud-link">Indore Real Estate</a> <a href="#" class="tag-cloud-link">Townships in indore</a> <a href="#" class="tag-cloud-link">Indore Property</a> <a href="#" class="tag-cloud-link">Row Houses in Indore</a> <a href="#" class="tag-cloud-link">Real Estate Investment</a> <a href="#" class="tag-cloud-link">Integrated Township</a> <a href="#" class="tag-cloud-link">Villa in indore</a> <a href="#" class="tag-cloud-link">Luxurious Home</a> </ul>-->
				</div>
				<!--<div class="sidebar-box ftco-animate">
					<h3>Archives</h3>
					<ul class="categories">
						<li><a href="#">September 2019<span>(1)</span></a></li>
						<li><a href="#">December 2019 <span>(1)</span></a></li>
						<li><a href="#">February 2020 <span>(1)</span></a></li>
						<li><a href="#">March 2020<span>(3)</span></a></li>
					</ul>
				</div>
				<div class="sidebar-box ftco-animate">
					<h3>Paragraph</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus itaque, autem necessitatibus voluptate quod mollitia delectus aut, sunt placeat nam vero culpa sapiente consectetur similique, inventore eos fugit cupiditate numquam!</p>
				</div>-->
			</div>
		</div>
	</div>
</section>