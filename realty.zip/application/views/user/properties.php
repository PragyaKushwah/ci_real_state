<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css" />
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />

<script src="https://unpkg.com/swiper/swiper-bundle.js"></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<style>
    /*.prop_desc{*/
    /*    text-align:center;*/
    /*}*/
    .intro {
       overflow: hidden;
   text-overflow: ellipsis;
   display: -webkit-box;
   -webkit-line-clamp: 2; /* number of lines to show */
   -webkit-box-orient: vertical; 
    }
    .btn-custom{
        width:100%;
    }
    
    .project{
        padding:10px;
        background: #fff;
    }
    
    .project .details{
        font-size: 0.8rem !important;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    .project h3{
        font-size: 1.5rem;
        font-weight: 600;
    }
    
    
</style>
<style>
  .testimonial_swiper{
    width:auto;  
  }
.testimonial {
  background-color: #f6f6f6;
  border-radius: 5px;
  padding: 20px;
  margin-left: 30px auto;
}

.testimonial::after {
  content: "";
  clear: both;
  display: table;
}

.testimonial img {
  float: left;
  margin-right: 20px;
  border-radius: 50%;
}

.testimonial span {
  font-size: 20px;
  margin-right: 15px;
}

.testimonial_swiper .swiper-slide > .row{
    background:#f6f6f6;
    padding:10px 30px;
}

.testimonial_swiper .swiper-slide .col-md-2{
    display: flex;
    align-items: center;
    justify-content: center;
}

@media (max-width: 500px) {
  .testimonial {
      text-align: center;
  }
  .testimonial img {
      margin: auto;
      float: none;
      display: block;
  }
}
</style>  
    

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<div class="page-content">
<section class="hero-wrap hero-wrap-2" style="background-image: url('<?php echo base_url()?>assets/images/page_header.jpg');" data-stellar-background-ratio="0.5">
   <div class="overlay"></div>
   <div class="container">
      <div class="row no-gutters slider-text align-items-center justify-content-center">
         <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Projects</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="<?=base_url();?>">Home <i class="ion-ios-arrow-forward"></i></a></span> <a href="<?php echo base_url() ?>properties"><span>Projects</span></a></p>
         </div>
      </div>
   </div>
</section>
<section class="ftco-section properties-list">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <div class="row">
               <?php foreach($pakiza_properties as $property){ ?>
               <div class="col-md-6 col-lg-4 ftco-animate">
                  <div class="project">
                     <a href="<?php echo base_url('properties_single')?>?id=<?php echo $property->id?>">
                     <div class="img">
                        <img src="<?php echo base_url()?>assets/uploads/gallery/<?= $property->photo ?>" class="img-fluid" alt="">
                        <div class="text">
                           <h3></h3>
                        </div>
                     </div>
                     </a>
                     <div class="desc row pt-1 prop_desc">
                        <div class="col-md-7">
                            <h3>
                                <?php echo $property->name;?>
                            </h3>
                            <span class="details">
                                <?php echo $property->address;?>
                            </span>
                        </div>
                        <div class="col-md-5">
                            <a href="<?php echo base_url('properties_single')?>?id=<?php echo $property->id?>" ><button class="btn btn-info">View Details</button></a>
                        </div>
                     </div>
                  </div>
               </div>
               <?php } ?>
               <!--<div class="col-md-6 col-lg-4 ftco-animate">
                  <div class="project">
                  <div class="img">
                  <img src="< ?php echo base_url()?>assets/images/work-2.jpg" class="img-fluid" alt="Colorlib Template">
                  <div class="text">
                  <span>Sale</span>
                  <h3><a href="< ?php echo base_url('User/properties_single')?>">Fatima <br> Subdivision</a></h3>
                  </div>
                  </div>
                  <div class="desc pt-3">
                  
                  <p class="h-info"><span class="location">New York</span> <span class="details">&mdash; 3bds, 2bath</span></p>
                  </div>
                  </div>
                  </div>-->
               <!--<div class="col-md-6 col-lg-4 ftco-animate">
                  <div class="project">
                  <div class="img">
                  <img src="< ?php echo base_url()?>assets/images/xwork-3.jpg.pagespeed.ic.BKjj1CYFBk.jpg" class="img-fluid" alt="Colorlib Template">
                  <div class="text">
                  <span>Sale</span>
                  <h3><a href="< ?php echo base_url('properties_single')?>">Fatima <br> Subdivision</a></h3>
                  </div>
                  </div>
                  <div class="desc pt-3">
                  
                  <p class="h-info"><span class="location">New York</span> <span class="details">&mdash; 3bds, 2bath</span></p>
                  </div>
                  </div>
                  </div>
                  <div class="col-md-6 col-lg-4 ftco-animate">
                  <div class="project">
                  <div class="img">
                  <img src="< ?php echo base_url()?>assets/images/xwork-4.jpg.pagespeed.ic.r4wJxMQEIi.jpg" class="img-fluid" alt="Colorlib Template">
                  <div class="text">
                  <span>Sale</span>
                  <h3><a href="< ?php echo base_url('User/properties_single')?>">Fatima <br> Subdivision</a></h3>
                  </div>
                  </div>
                  <div class="desc pt-3">
                  
                  <p class="h-info"><span class="location">New York</span> <span class="details">&mdash; 3bds, 2bath</span></p>
                  </div>
                  </div>
                  </div>
                  <div class="col-md-6 col-lg-4 ftco-animate">
                  <div class="project">
                  <div class="img">
                  <img src="< ?php echo base_url()?>assets/images/work-5.jpg" class="img-fluid" alt="Colorlib Template">
                  <div class="text">
                  <span>Sale</span>
                  <h3><a href="< ?php echo base_url('User/properties_single')?>">Fatima <br> Subdivision</a></h3>
                  </div>
                  </div>
                  <div class="desc pt-3">
                  
                  <p class="h-info"><span class="location">New York</span> <span class="details">&mdash; 3bds, 2bath</span></p>
                  </div>
                  </div>
                  </div>
                  <div class="col-md-6 col-lg-4 ftco-animate">
                  <div class="project">
                  <div class="img">
                  <img src="< ?php echo base_url()?>assets/images/work-6.jpg" class="img-fluid" alt="Colorlib Template">
                  <div class="text">
                  <span>Sale</span>
                  <h3><a href="< ?php echo base_url('User/properties_single')?>">Fatima <br> Subdivision</a></h3>
                  </div>
                  </div>
                  <div class="desc pt-3">
                  
                  <p class="h-info"><span class="location">New York</span> <span class="details">&mdash; 3bds, 2bath</span></p>
                  </div>
                  </div>
                  </div>
                  <div class="col-md-6 col-lg-4 ftco-animate">
                  <div class="project">
                  <div class="img">
                  <img src="< ?php echo base_url()?>assets/images/work-7.jpg" class="img-fluid" alt="Colorlib Template">
                  <div class="text">
                  <span>Sale</span>
                  <h3><a href="< ?php echo base_url('User/properties_single')?>">Fatima <br> Subdivision</a></h3>
                  </div>
                  </div>
                  <div class="desc pt-3">
                  
                  <p class="h-info"><span class="location">New York</span> <span class="details">&mdash; 3bds, 2bath</span></p>
                  </div>
                  </div>
                  </div>
                  <div class="col-md-6 col-lg-4 ftco-animate">
                  <div class="project">
                  <div class="img">
                  <img src="< ?php echo base_url()?>assets/images/work-8.jpg" class="img-fluid" alt="Colorlib Template">
                  <div class="text">
                  <span>Sale</span>
                  <h3><a href="< ?php echo base_url('User/properties_single')?>">Fatima <br> Subdivision</a></h3>
                  </div>
                  </div>
                  <div class="desc pt-3">
                  
                  <p class="h-info"><span class="location">New York</span> <span class="details">&mdash; 3bds, 2bath</span></p>
                  </div>
                  </div>
                  </div>
                  <div class="col-md-6 col-lg-4 ftco-animate">
                  <div class="project">
                  <div class="img">
                  <img src="< ?php echo base_url()?>assets/images/work-9.jpg" class="img-fluid" alt="Colorlib Template">
                  <div class="text">
                  <span>Sale</span>
                  <h3><a href="< ?php echo base_url('User/properties_single')?>">Fatima <br> Subdivision</a></h3>
                  </div>
                  </div>
                  <div class="desc pt-3">
                  
                  <p class="h-info"><span class="location">New York</span> <span class="details">&mdash; 3bds, 2bath</span></p>
                  </div>
                  </div>
                  </div>-->
               <!--till here-->
            </div>
           <!-- <div class="row no-gutters my-5">
               <div class="col text-center">
                  <div class="block-27">
                     <ul>
                        <li><a href="#">&lt;</a></li>
                        <li class="active"><span>1</span></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">5</a></li>
                        <li><a href="#">&gt;</a></li>
                     </ul>
                  </div>
               </div>
            </div>-->
         </div>
      </div>
   </div>
</section>
<section class="ftco-section ftco-no-pt mb-5 testimony-section" id="satisfied_customer">
   <div class="container mb-5">
      <div class="row justify-content-start mb-5">
         <div class="col-md-12 heading-section ftco-animate text-center">
            <h2 class="">Satisfied Clients</h2>
            <!--<h2 class="mb-4">Recently Added</h2>-->
            <p class="text-center">Energy Behind Us!</p>
         </div>
      </div>
      
      <div class="row ftco-animate">
         <div class="col-md-12">
            <div class="swiper-container testimonial_swiper">
              <div class="swiper-wrapper">
                  <div class="swiper-slide">
                    <div class="row">
                      <!--<div class="col-md-2">-->
                      <!--    <img src="<?php echo base_url('assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg')?>" alt="Avatar" style="width:90px">-->
                      <!--</div>-->
                      <div class="testimonial col-md-12">
                        <p><span>Asif Syed </span></p>
                        <p>“It was great Experience. Awesome Project and amenities”.  </p>
                      </div>
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <div class="row">
                      <!--<div class="col-md-2">-->
                      <!--    <img src="<?php echo base_url('assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg')?>" alt="Avatar" style="width:90px">-->
                      <!--</div>-->
                      <div class="testimonial col-md-12 ">
                        <p><span>Ali Khan</span></p>
                        <p>“Good to see such adorable project with good approach and amenities in Indore”</p>
                      </div>
                    </div>
                  </div>
                  <div class="swiper-slide">
                        <div class="row">
                          <!--<div class="col-md-2">-->
                          <!--    <img src="<?php echo base_url('assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg')?>" alt="Avatar" style="width:90px">-->
                          <!--</div>-->
                          <div class="testimonial col-md-12 ">
                            <p><span>Abdul Hashmi</span></p>
                            <p>“Unique Concept and amazing development”</p>
                          </div>
                        </div>
                  </div>
                  
                  <div class="swiper-slide">
                        <div class="row">
                          <!--<div class="col-md-2">-->
                          <!--    <img src="<?php echo base_url('assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg')?>" alt="Avatar" style="width:90px">-->
                          <!--</div>-->
                          <div class="testimonial col-md-12 ">
                            <p><span>Vaibhav Singh</span></p>
                            <p>“Only developer in Indore, who provides Plot covered boundary walls with glass number plate. World class Infrastructure which justifies the tag line ‘A Name You Can Trust’.</p>
                          </div>
                        </div>
                  </div>
                  
                  <div class="swiper-slide">
                      <div class="row">
                        <!--<div class="col-md-2">-->
                        <!--    <img src="<?php echo base_url('assets/images/avatar_g2.jpg')?>" alt="Avatar" style="width:90px">-->
                        <!--</div>-->
                        <div class="testimonial col-md-12 ">
                            <p><span>Fatima Sheikh</span></p>
                            <p>“Very Nice Infrastructure”</p>
                        </div>
                     </div>
                  </div>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div>
          </div>
        </div>
      </div>
   </div>
</section>
</div>
 <!--New Layout added here-->
      
      
        
       <!--New Layout till here-->
