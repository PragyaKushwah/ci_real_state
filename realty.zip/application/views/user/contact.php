
 <section class="hero-wrap hero-wrap-2" style="background-image:url(<?php echo base_url()?>assets/images/page_header.jpg)" data-stellar-background-ratio="0.5">
   <div class="overlay"></div>
   <div class="container">
      <div class="row no-gutters slider-text align-items-center justify-content-center">
         <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Contact Us</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Contact</span></p>
         </div>
      </div>
   </div>
</section>
<section class="ftco-section ftco-no-pt contact-section mt-5">
   <div class="container">
      <div class="row d-flex align-items-stretch no-gutters">
          <div class="col-md-12 text-center heading-section ftco-animate">
                <h2 class="mb-4 pb-3">Feel Free To Contact Us!</h2>
          </div>
            
         <div class="col-md-12 p-4 p-md-5 order-md-last bg-light">
             <form action="<?=base_url();?>User/enquiry_form" method="post" class="enquiry-form" >
                <div class="row mb-3">
                    <div class="col">
                      <input type="text" name="name" class="form-control" placeholder="Your name">
                    </div>
                    <div class="col">
                      <input type="email" name="email" class="form-control" placeholder="Your Email">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col">
                      <input type="text" name="subject" class="form-control" placeholder="Subject">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col">
                      <textarea name="message" cols="30" rows="4" class="form-control" placeholder="Message"></textarea>
                    </div>
                </div>
               
               <div class="form-group d-flex justify-content-center">
                  <input type="submit" value="Send Message" class="btn btn-primary py-3 px-5">
               </div>
            </form>
         </div>
      </div>
   </div>
</section>

<section class="ftco-section ftco-no-pt spl-arrows blogs_section">
   <div class="container">
      <div class="row">
         <div class="col-md-3 mb-5 heading-section ftco-animate">
            <h2 class="mb-4">Pakiza Realty</h2>
            <p class="mb-5"><h5>Head Office</h5>Commercial Plot No.3,<br>PU-04, Opp. Prestige College, <br> Nr Bombay Hospital,Indore (M.P.) - 452010</p>
            
         </div>
         <!---contact slider---->
         <div class="col-md-9">
            
            <div class="row swiper-container swiper-blog contact_details">
               <div class="swiper-wrapper">
                  <div class="swiper-slide">
                     <div class="blog-view">
                        <div class="blog-entry">
                           <div class="text py-0">
                              <div class="title">
                                  <h5>Pakiza Lifestyle</h5>
                              </div>
                              <div class="desc">
                                 <p class="p-0">MR-9, Dargah Bypass Road<br>Khajrana, Indore (M.P.) - 452016<br><strong class="mt-2">Phone:</strong><br> <a href="tel:+918889144497">+91-8889144497(Mob)</a></p>
                                 <!--<h3 class="heading"><a href="< ?php echo base_url('blog_single')?>?id=< ?php echo $blog->blog_id ?>" class="btn-custom">Know More<span class="ml-2 ion-ios-arrow-forward"></span></a></h3>-->
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="blog-view">
                        <div class="blog-entry">
                           <div class="text py-0">
                              <div class="title">
                                  <h5>Dewas lifestyle</h5>
                              </div>
                              <div class="desc">
                                 <p class="p-0">Dewas Bypass Rd<br>Near Sharda school, Dewas (M.P.) - 455001<br><strong class="mt-2">Phone:</strong><br> <a href="tel:+919893236634">+91 9893236634 (Mob)</a></p>
                                 <!--<h3 class="heading"><a href="< ?php echo base_url('blog_single')?>?id=< ?php echo $blog->blog_id ?>" class="btn-custom">Know More<span class="ml-2 ion-ios-arrow-forward"></span></a></h3>-->
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="blog-view">
                        <div class="blog-entry">
                           <div class="text py-0">
                              <div class="title">
                                  <h5>Pakiza City</h5>
                              </div>
                              <div class="desc">
                                 <p class="p-0">Ahead S.S Cricket ground, Gram Behadia,<br>NaytaMundla, Indore (M.P.) - 452020<br><strong class="mt-2">Phone:</strong><br> <a href="tel:+91 9174404444">+91 9174404444(Mob)</a></p>
                                 <!--<h3 class="heading"><a href="< ?php echo base_url('blog_single')?>?id=< ?php echo $blog->blog_id ?>" class="btn-custom">Know More<span class="ml-2 ion-ios-arrow-forward"></span></a></h3>-->
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  
               </div>
              
            </div>
         </div>
      </div>
   </div>
</section>

<section class="ftco-section contact-section">
   <div class="container">
      <div class="row d-flex contact-info">
         <div class="col-md-12 d-flex">
            <div class="text-center block">
                <div class="icon_box">
                    <i class="fas fa-share-alt"></i>
                </div>
               <h3 class="mb-4">Digital Connects</h3>
               <!--<div class="row">-->
               <!--    <div class="col-md-6  mb-2 d-flex justify-content-center" id="instragram_section">-->
               <!--       <h2 class="mb-4">Instagram</h2>-->
               <!--         <div class="flicker-img social_section">-->
               <!--             <div class="row">-->
               <!--                 <div class="col-md-4">-->
               <!--                     <a href="https://www.instagram.com/p/CG4P0JEja-Q/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/instagram/pakiza_insta1.PNG" alt="" ></div></a>-->
               <!--                 </div>-->
               <!--                 <div class="col-md-4">-->
               <!--                     <a href="https://www.instagram.com/p/CHFj1hhD-f2/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/instagram/pakiza_green_insta.PNG"  alt=""></div></a>-->
               <!--                 </div>-->
               <!--                 <div class="col-md-4">-->
               <!--                     <a href="https://www.instagram.com/p/CG4P0JEja-Q/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/instagram/pakiza_insta1.PNG" alt=""></div></a>-->
               <!--                 </div>-->
               <!--             </div>-->
               <!--             <div class="row">-->
               <!--                 <div class="col-md-4">-->
               <!--                     <a href="https://www.instagram.com/p/CGmqW70DU_H/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/instagram/pakiza_insta4.PNG"  alt=""></div></a>-->
               <!--                 </div>-->
               <!--                 <div class="col-md-4">-->
               <!--                     <a href="https://www.instagram.com/p/CGg8ptdDwNJ/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/instagram/pakiza_instagram5.PNG" alt=""></div></a>-->
               <!--                 </div>-->
               <!--                 <div class="col-md-4">-->
               <!--                     <a href="https://www.instagram.com/p/CGWwdbdDXlU/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/instagram/pakiza_insta6.PNG" alt=""></div></a>-->
               <!--                 </div>-->
               <!--             </div>-->
               <!--         </div>-->
               <!--   </div>  -->
                  
               <!--   <div class="col-md-6  mb-2 d-flex justify-content-center" id="facebook_section">-->
               <!--       <h2 class="mb-4">Facebook</h2>-->
               <!--         <div class="flicker-img social_section">-->
               <!--             <div class="row">-->
               <!--                 <div class="col-md-4">-->
               <!--                     <a href="https://www.facebook.com/PakizaRealty/photos/998875217606062" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/facebook/face1.jpg" alt="" ></div></a>-->
               <!--                 </div>-->
               <!--                 <div class="col-md-4">-->
               <!--                     <a href="https://www.facebook.com/PakizaRealty/photos/886436688849916" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/facebook/face3.jpg"  alt=""></div></a>-->
               <!--                 </div>-->
               <!--                 <div class="col-md-4">-->
               <!--                     <a href="https://www.facebook.com/PakizaRealty/photos/877405853086333" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/facebook/face5.jpg" alt="" ></div></a>-->
               <!--                 </div>-->
               <!--             </div>-->
               <!--             <div class="row">-->
               <!--                 <div class="col-md-4">-->
               <!--                     <a href="https://www.facebook.com/PakizaRealty/photos/848455745981344" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/facebook/face6.jpg"  alt=""></div></a>-->
               <!--                 </div>-->
               <!--                 <div class="col-md-4">-->
               <!--                     <a href="https://www.facebook.com/PakizaRealty/photos/795470864613166/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/facebook/facebook5.PNG"  alt=""></div></a>-->
               <!--                 </div>-->
               <!--                 <div class="col-md-4">-->
               <!--                     <a href="https://www.facebook.com/PakizaRealty/photos/763916584435261/" target="blank"><div class="img_container"><img src="<?php echo base_url()?>assets/uploads/facebook/facebook6.PNG"  alt=""></div></a>-->
               <!--                 </div>-->
               <!--             </div>-->
               <!--         </div>-->
               <!--   </div>  -->
               <!--</div>-->
               <div class="row d-flex justify-content-center">
                   <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                      <li class="ftco-animate"><a href="https://twitter.com/RealtyPakiza"><span class="icon-twitter"></span></a></li>
                      <li class="ftco-animate"><a href="https://www.facebook.com/pg/PakizaRealty"><span class="icon-facebook"></span></a></li>
                      <li class="ftco-animate"><a href="https://www.instagram.com/p/CG4P0JEja-Q/"><span class="icon-instagram"></span></a></li>
                   </ul>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="ftco-section ftco-no-pt contact-section">
   <div class="container">
      <div class="row d-flex align-items-stretch no-gutters">
         <div class="col-md-12 d-flex align-items-stretch">
            <div class="map">
                <div class="map_container" id="map-canvas">
                   
                </div>
            </div>
         </div>
      </div>
   </div>
</section>
