<section class="hero-wrap hero-wrap-2" style="background-image:url(<?php echo base_url()?>assets/images/page_header.jpg)" data-stellar-background-ratio="0.5">
	<div class="overlay"></div>
	<div class="container">
		<div class="row no-gutters slider-text align-items-center justify-content-center">
			<div class="col-md-9 ftco-animate text-center">
				<h1 class="mb-2 bread">About Us</h1>
				<p class="breadcrumbs"><span class="mr-2"><a href="<?php echo base_url()?>">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>About us</span></p>
			</div>
		</div>
	</div>
</section>
<section class="ftco-section ftco-no-pt about-intro">
	<div class="container">
		<div class="row no-gutters">
			<div class="col-md-5 pt-5 mt-5 ">
				 <video width="550"  controls>
                  <source src="<?php echo base_url()?>assets/video/about_video.mp4" type="video/mp4">
                  <source src="<?php echo base_url()?>assets/video/about_video.ogg" type="video/ogg">
                  Your browser does not support the video tag.
                </video> 
				<!--<a href="#" class="icon-video popup-vimeo d-flex justify-content-center align-items-center">-->
					
    <!--          <span class="ion-ios-play"></span> </a>-->
			</div>
			<div class="col-md-7 pt-5 mt-5 wrap-about pb-md-5 ftco-animate">
				<div class="heading-section mb-5">
					<div class="pl-md-5 ml-md-5">
						<h2 class="mb-4">Welcome to Pakiza Real Estate Agency</h2> </div>
				</div>
				<div class="pl-md-5 ml-md-5 mb-5">
					<p align="justify">"Pakiza Realty is a real estate company with 10+ residential township projects in India. We emphasis on contemporary architecture, strong project execution and quality construction which have helped them to launch some superior community residential projects across central India."</p>
					<!--<p align="justify">Connecting emotionally with customers and understanding what they really want has always been the motto of the Pakiza Group. The Pakiza Group has excelled in the retail business with its innovative and revolutionary thinking and most importantly for taking the retail industry in Central India to another level.Going beyond its role as a premier retail leader, the Pakiza Group which has been a socially responsible business house nearly for four decades, is now focusing on education& real estate as the best medium to enrich society. Through their residential premium townships, they want to provide opportunity to all class and age group to own a comfortable house at best location, where people can enjoy living amid their own community & culture. They have a humble desire to facilitate lucrative investment deals fitting every budget from premium to affordable segments.</p>-->
					
				</div>
			</div>
			<div class="col-md-12 mt-5 wrap-about">
			    <p align="justify">Connecting emotionally with customers and understanding what they really want has always been the motto of the Pakiza Group. The Pakiza Group has excelled in the retail business with its innovative and revolutionary thinking and most importantly for taking the retail industry in Central India to another level.Going beyond its role as a premier retail leader, the Pakiza Group which has been a socially responsible business house nearly for four decades, is now focusing on education& real estate as the best medium to enrich society. Through their residential premium townships, they want to provide opportunity to all class and age group to own a comfortable house at best location, where people can enjoy living amid their own community & culture. They have a humble desire to facilitate lucrative investment deals fitting every budget from premium to affordable segments.</p>
			    <p align="justify">"AFTER INTRODUCING INDORE'S MOST SUCCESSFUL COMMUNITY TOWNSHIP PAKIZA LIFESTYLE THEY ARE PRESENTING SOME REMARKABLE INVESTMENT OPPORTUNITIES ACROSS CENTRAL INDIA."</p>
		        <p align="justify">Pakiza's clean title land,well panned projects, excellent execution, timely possession & transparency in deals have worked well to create the best value for customers. Innovation in their offerings combine an emphasis on contemporary architecture, strong project execution and quality construction, which have helped them to launch some of the superior community residential projects across central India.</p>
		    </div>
		</div>
		
		<!--<div class="row about mt-5 pt-4">-->
		<!--	<div class="col-md-4 ftco-animate">-->
		<!--	    <div class="block">-->
  <!--  				<h3 class="h4">Mission</h3>-->
  <!--  				<p align="justify">"Culmination of hard work, honest effort and belief to initiate a new concept in the market resulted in the brand name pakiza."</p>-->
		<!--	    </div>-->
		<!--	</div>-->
		<!--	<div class="col-md-4 ftco-animate">-->
		<!--	    <div class="block_center">-->
  <!--  				<h3 class="h4">Vision</h3>-->
  <!--  				<p>Pakiza is the one to start the chapter of retailing in the entire state even when the name of the book was not heard. The response of the people towards Pakiza has been overwhelming which in turn has boosted their confidence further.When the group enered the real estate segment through Pakiza Lifestyle, the same trust & faith in our offering was accorded to us by customers.</p>-->
		<!--	    </div>-->
		<!--	</div>-->
		<!--	<div class="col-md-4 ftco-animate">-->
		<!--		<div class="block">-->
  <!--  				<h3 class="h4">Pakiza Realty</h3>-->
  <!--  				<p>Pakiza Realty is a multi project, leading realtor of central india with 8 running projects. and earned trust of over 1000 families in its various offering.</p>-->
		<!--	    </div>-->
		<!--	</div>-->
		<!--</div>-->
		
		<div class="row about mt-5 pt-4">
		    <div class="col-md-12 text-center heading-section ftco-animate">
                <h2 class="mb-4 pb-3">The Pakiza Realty</h2>
                <p></p>
            </div>
		    
			<div class="col-md-12 ftco-animate">
			    <div class="block mb-4">
    				<h3 class="h4">Vision & Mission</h3>
    				<p align="justify">"Culmination of hard work, honest effort and belief to initiate a new concept in the market resulted in the brand name Pakiza."</p>
			    </div>
			    
			    <div class="block">
    				<h3 class="h4">Pakiza Realty</h3>
    				<p>Pakiza Realty is a multi project, leading realtor of central india with 8 running projects. and earned trust of over 1000 families in its various offering.</p>
			    </div>
			    
			</div>
			<!--<div class="col-md-6 ftco-animate">
			    <div class="block_center">
    				<h3 class="h4">Vision</h3>
    				<p>Pakiza is the one to start the chapter of retailing in the entire state even when the name of the book was not heard. The response of the people towards Pakiza has been overwhelming which in turn has boosted their confidence further.When the group enered the real estate segment through Pakiza Lifestyle, the same trust & faith in our offering was accorded to us by customers.</p>
			    </div>
			</div>-->
			
		</div>
	</div>
</section>

<section class="ftco-section ftco-no-pt mb-5 testimony-section" id="satisfied_customer">
   <div class="container mb-5">
      <div class="row justify-content-start mb-5">
         <div class="col-md-12 heading-section ftco-animate text-center">
            <h2 class="">Satisfied Clients</h2>
            <!--<h2 class="mb-4">Recently Added</h2>-->
            <p class="text-center">Energy Behind Us!</p>
         </div>
      </div>
      
      <div class="row ftco-animate">
         <div class="col-md-12">
            <div class="swiper-container testimonial_swiper">
              <div class="swiper-wrapper">
                  <div class="swiper-slide">
                    <div class="row">
                      <!--<div class="col-md-2">-->
                      <!--    <img src="<?php echo base_url('assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg')?>" alt="Avatar" style="width:90px">-->
                      <!--</div>-->
                      <div class="testimonial col-md-12">
                        <p><span>Asif Syed </span></p>
                        <p>“It was great Experience. Awesome Project and amenities”.  </p>
                      </div>
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <div class="row">
                      <!--<div class="col-md-2">-->
                      <!--    <img src="<?php echo base_url('assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg')?>" alt="Avatar" style="width:90px">-->
                      <!--</div>-->
                      <div class="testimonial col-md-12 ">
                        <p><span>Ali Khan</span></p>
                        <p>“Good to see such adorable project with good approach and amenities in Indore”</p>
                      </div>
                    </div>
                  </div>
                  <div class="swiper-slide">
                        <div class="row">
                          <!--<div class="col-md-2">-->
                          <!--    <img src="<?php echo base_url('assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg')?>" alt="Avatar" style="width:90px">-->
                          <!--</div>-->
                          <div class="testimonial col-md-12 ">
                            <p><span>Abdul Hashmi</span></p>
                            <p>“Unique Concept and amazing development”</p>
                          </div>
                        </div>
                  </div>
                  <div class="swiper-slide">
                        <div class="row">
                          <!--<div class="col-md-2">-->
                          <!--    <img src="<?php echo base_url('assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg')?>" alt="Avatar" style="width:90px">-->
                          <!--</div>-->
                          <div class="testimonial col-md-12 ">
                            <p><span>Vaibhav Singh</span></p>
                            <p>“Only developer in Indore, who provides Plot covered boundary walls with glass number plate. World class Infrastructure which justifies the tag line ‘A Name You Can Trust’.</p>
                          </div>
                        </div>
                  </div>
                  <div class="swiper-slide">
                      <div class="row">
                        <!--<div class="col-md-2">-->
                        <!--    <img src="<?php echo base_url('assets/images/avatar_g2.jpg')?>" alt="Avatar" style="width:90px">-->
                        <!--</div>-->
                        <div class="testimonial col-md-12 ">
                            <p><span>Fatima Sheikh</span></p>
                            <p>“Very Nice Infrastructure”</p>
                        </div>
                     </div>
                  </div>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div>
          </div>
        </div>
      </div>
   </div>
</section>

<!--<section class="ftco-section ftco-no-pt testimony-section">-->
<!--	 <div class="overlay"></div>-->
<!--   <div class="container">-->
<!--      <div class="row justify-content-center mb-5 pb-3">-->
<!--         <div class="col-md-8 text-center heading-section ftco-animate">-->
<!--            <h2 class="mb-4">SATISFIED CLIENTS -ENERGY BEHIND US</h2>-->
<!--            <p></p>-->
<!--         </div>-->
<!--      </div>-->
<!--      <div class="row ftco-animate">-->
<!--         <div class="col-md-12">-->
<!--            <div class="carousel-testimony owl-carousel">-->
<!--               <div class="item">-->
<!--                  <div class="testimony-wrap p-4 pb-5">-->
                     <!--<div class="user-img mb-4" style="background-image:url('<?php echo base_url()?>assets/images/xperson_1.jpg.pagespeed.ic.P4pHl6glbj.jpg')"></div>-->
<!--                     <div class="text">-->
<!--                        <span class="quote d-flex align-items-center justify-content-center">-->
<!--                        <i class="icon-quote-left"></i>-->
<!--                        </span>-->
<!--                        <p class="mb-4 line">Good to see such adorable project with good aproach and amenities near Indore, best luck Pakiza group.</p>-->
<!--                        <div class="mb-4">-->
<!--                           <p class="name">Ali Khan</p>-->
                           <!--<span class="position">Buyer</span>-->
<!--                        </div>-->
<!--                     </div>-->
<!--                  </div>-->
<!--               </div>-->
<!--               <div class="item">-->
<!--                  <div class="testimony-wrap p-4 pb-5">-->
                     <!--<div class="user-img mb-4" style="background-image:url('<?php echo base_url()?>assets/images/xperson_2.jpg.pagespeed.ic.yyrmjBH91b.jpg')"></div>-->
<!--                     <div class="text">-->
<!--                        <span class="quote d-flex align-items-center justify-content-center">-->
<!--                        <i class="icon-quote-left"></i>-->
<!--                        </span>-->
<!--                        <p class="mb-4 line">Unique concept and amazing development!</p>-->
<!--                        <div class="mb-4">-->
<!--                           <p class="name">Abdul Hashmi</p>-->
                           <!--<span class="position">Buyer</span>-->
<!--                        </div>-->
<!--                     </div>-->
<!--                  </div>-->
<!--               </div>-->
<!--               <div class="item">-->
<!--                  <div class="testimony-wrap p-4 pb-5">-->
                     <!--<div class="user-img mb-4" style="background-image: url('<?php echo base_url()?>assets/images/person_3.jpg')"></div>-->
<!--                     <div class="text">-->
<!--                        <span class="quote d-flex align-items-center justify-content-center">-->
<!--                        <i class="icon-quote-left"></i>-->
<!--                        </span>-->
<!--                        <p class="mb-4 line">It was great experience. Awesome Project.</p>-->
<!--                    </p>-->
<!--                        <div class="mb-4">-->
<!--                           <p class="name">Asif Syed</p>-->
                           <!--<span class="position">Buyer</span>-->
<!--                        </div>-->
<!--                     </div>-->
<!--                  </div>-->
<!--               </div>-->
<!--            </div>-->
<!--         </div>-->
<!--      </div>-->
<!--   </div>-->
<!--</section>-->
<!--<section class="ftco-section ftco-no-pb ftco-no-pt ftco-counter img ftco-animate" id="section-counter">
	<div class="container">
		<div class="row d-md-flex align-items-center justify-content-start">
			<div class="col-lg-10">
				<div class="bg-counter p-4">
					<div class="row py-2 d-md-flex align-items-center">
						<div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
							<div class="block-18">
								<div class="text"> <strong class="number" data-number="1000">0</strong> <span>Properties</span> </div>
							</div>
						</div>
						<div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
							<div class="block-18">
								<div class="text"> <strong class="number" data-number="351">0</strong> <span>Happy Clients</span> </div>
							</div>
						</div>
						<div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
							<div class="block-18">
								<div class="text"> <strong class="number" data-number="564">0</strong> <span>Finished Projects</span> </div>
							</div>
						</div>
						<div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
							<div class="block-18">
								<div class="text"> <strong class="number" data-number="300">0</strong> <span>Working Days</span> </div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>-->