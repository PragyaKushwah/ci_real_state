<section class="home-slider swiper-container">
   <!-- Additional required wrapper -->
   <div class="swiper-wrapper">
      <!-- Slides -->
      <div class="swiper-slide slider-item">
         <div class="overlay"></div>
         <div class="container d-md-block  content-block">
            <h3>Enter the world of your lifestyle</h3>
            <h1 class="mb-4">Comfort and peace always make for a quality life!</h1>
         </div>
         <div class="img" style="background-image:url(<?php echo base_url()?>assets/images/slider_img1.jpg)">
         </div>
      </div>
      <div class="swiper-slide slider-item">
         <div class="overlay"></div>
         <div class="container d-md-block  content-block">
            <h3>Let your dream come true</h3>
            <h1 class="mb-4">We built dream into reality!</h1>
         </div>
         <div class="img" style="background-image:url(<?php echo base_url()?>assets/images/slider_property3.jpeg)">
         </div>
      </div>
      <div class="swiper-slide slider-item">
         <div class="overlay"></div>
         <div class="container d-md-block  content-block">
            <h3>Promise that could be delivered</h3>
            <h1 class="mb-4">User driven projects!</h1>
         </div>
         <div class="img" style="background-image:url(<?php echo base_url()?>assets/images/Asset_68-50.jpg)">
         </div>
      </div>
   </div>
   <!-- If we need pagination -->
   <!--<div class="swiper-pagination"></div>-->
   <!-- If we need navigation buttons -->
   <div class="swiper-button-prev"></div>
   <div class="swiper-button-next"></div>
   <!-- If we need scrollbar -->
   <!--<div class="swiper-scrollbar"></div>-->
</section>
<section class="ftco-section pt-5" id="welcome_pakiza_realty">
   <div class="container">
      <div class="row">
         <div class="col-md-6">
            <div class="heading-section mb-5 ftco-animate">
               <h2 class="mb-4">Welcome to Pakiza Realty</h2>
            </div>
            <div class="about-img img p-5 d-flex align-items-center" style="background-image:url('<?php echo base_url()?>assets/images/Asset 2-80.jpg')">
               <div class="about-div">
                  <h4 style="color:white;">Culmination in Hardwork and Honest efforts to initiate a new concept in the market resulted in the brand name ‘Pakiza’.</h4>
                  <p class="mb-0"><a href="<?php echo base_url('about'); ?>" class="btn-custom-2">Read more <span class="ml-2 icon-long-arrow-right"></span></a></p>
               </div>
            </div>
         </div>
         <div class="col-md-6 d-flex home-spl">
            <div class="img img-3 p-5 d-flex align-self-stretch border box" style="background-image: url('<?php echo base_url()?>assets/images/about-3.html');">
               <p class="box1">Pakiza Realty is a real estate company, leading developer with several projects across central India. Growing continuously with an earned trust of over thousands of families.</p>
               <div class="about-div bg-darken about-wrap box2">
                  <h4 style="color:white;">Pakiza is not only about consumerism, but it’s fundamental is to get connected with the emotions of the customer and provide them with the best at best price and quality. </h4>
                  <p class="mb-0"><a href="<?php echo base_url('about'); ?>" class="btn-custom-2">Read more <span class="ml-2 icon-long-arrow-right"></span></a></p>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!--section added here-->
<!--till here-->
<section class="ftco-section ftco-no-pt" id="our_projects">
   <div class="container">
      <div class="row justify-content-start mb-5">
         <div class="col-md-8 heading-section ftco-animate">
            <h2 class="">Our Projects</h2>
            <!--<h2 class="mb-4">Recently Added</h2>-->
            <p>Our Projects across Central India</p>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="carousel-properties owl-carousel">
               <?php foreach($pakiza_properties as $property){ ?>
               <div class="item">
                  <div class="project">
                     <div class="img">
                        <img src="<?php echo base_url()?>assets/uploads/gallery/<?= $property->photo ?>" class="img-fluid" alt="Pakiza Realty">
                        <div class="text">
                           <!--<span>Sale</span>-->
                           <h3><a href="<?php echo base_url('properties_single'); ?>?id=<?php echo $property->id?>"><?php echo $property->name?><br></a></h3>
                        </div>
                     </div>
                     <div class="desc">
                        <h5><?php echo $property->address ?></h5>
                     </div>
                  </div>
               </div>
               <?php }?>
               <!--<div class="item">
                  <div class="project">
                     <div class="img">
                        <img src="<?php echo base_url()?>assets/images/xwork-4.jpg.pagespeed.ic.r4wJxMQEIi.jpg" class="img-fluid" alt="Colorlib Template">
                        <div class="text">
                           <span>Sale</span>
                           <h3><a href="<?php echo base_url('properties'); ?>">Fatima <br> Subdivision</a></h3>
                        </div>
                     </div>
                     <div class="desc pt-3">
                       
                        <p class="h-info"><span class="location">New York</span> <span class="details">&mdash; 3bds, 2bath</span></p>
                     </div>
                  </div>
                  </div>
                  <div class="item">
                  <div class="project">
                     <div class="img">
                        <img src="<?php echo base_url();?>assets/images/xwork-3.jpg.pagespeed.ic.BKjj1CYFBk.jpg" class="img-fluid" alt="Colorlib Template">
                        <div class="text">
                           <span>Sale</span>
                           <h3><a href="<?php echo base_url('properties'); ?>">Fatima <br> Subdivision</a></h3>
                        </div>
                     </div>
                     <div class="desc pt-3">
                       
                        <p class="h-info"><span class="location">New York</span> <span class="details">&mdash; 3bds, 2bath</span></p>
                     </div>
                  </div>
                  </div>
                  <div class="item">
                  <div class="project">
                     <div class="img">
                        <img src="<?php echo base_url()?>assets/images/xwork-4.jpg.pagespeed.ic.r4wJxMQEIi.jpg" class="img-fluid" alt="Colorlib Template">
                        <div class="text">
                           <span>Sale</span>
                           <h3><a href="<?php echo base_url('properties'); ?>">Fatima <br> Subdivision</a></h3>
                        </div>
                     </div>
                     <div class="desc pt-3">
                       
                        <p class="h-info"><span class="location">New York</span> <span class="details">&mdash; 3bds, 2bath</span></p>
                     </div>
                  </div>
                  </div>
                  <div class="item">
                  <div class="project">
                     <div class="img">
                        <img src="<?php echo base_url()?>assets/images/xwork-3.jpg.pagespeed.ic.BKjj1CYFBk.jpg" class="img-fluid" alt="Colorlib Template">
                        <div class="text">
                           <span>Sale</span>
                           <h3><a href="<?php echo base_url('properties'); ?>">Fatima <br> Subdivision</a></h3>
                        </div>
                     </div>
                     <div class="desc pt-3">
                        
                        <p class="h-info"><span class="location">New York</span> <span class="details">&mdash; 3bds, 2bath</span></p>
                     </div>
                  </div>-->
            </div>
            <!--items end here-->
         </div>
      </div>
   </div>
</section>
<section class="ftco-section ftco-no-pt spl-arrows" id="pakiza_realty_pillars">
   <div class="container">
      <div class="row no-gutters">
         <!--<div class="col-md-4 p-md-5 img img-2" style="background-image: url('<?php echo base_url()?>assets/images/index_imglong.png');"></div>-->
         <div class="col-md-12 wrap-about ftco-animate">
            <div class="heading-section text-center">
               <h2 class="text-center">The Pakiza Realty</h2>
            </div>
            <div class="text-center">
               <p class="text-center">8 Pillars Of Pakiza Realty</p>
               <div class="row pt-5">
                     <div class="col-md-4">
                        <div class="services-2 px-4 text-center row  ftco-animate">
                           <div class="icon d-flex justify-content-center align-items-center col-3"><i class="fa fa-gavel"></i></div>
                           <div class="text col-9">
                              <h3>Legal</h3>
                              <p>All the Projects are statutory and approved by MPRERA</p>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-4">
                         <div class="services-2 px-4 text-center row  ftco-animate">
                           <div class="icon d-flex justify-content-center align-items-center col-3"><i class="fa fa-clock-o"></i></div>
                           <div class="text col-9">
                              <h3>Timely Possession</h3>
                              <p>One of the best record when it comes to delivering of project </p>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="services-2 px-4 text-center row  ftco-animate">
                           <div class="icon d-flex justify-content-center align-items-center col-3"><i class="fa fa-check-square"></i></div>
                           <div class="text col-9">
                              <h3>Quality Development</h3>
                              <p>Has earned its name for Quality construction and development</p>
                           </div>
                        </div>
                     </div>
                </div>
                <div class="row">
                     <div class="col-md-4">
                        <div class="services-2 px-4 text-center row  ftco-animate">
                           <div class="icon d-flex justify-content-center align-items-center col-3"><i class="fa fa-briefcase"></i></div>
                           <div class="text col-9">
                              <h3>Transparent Sales Policies</h3>
                              <p>Keep transparency in information to fulfill the expectation of consumers</p>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="services-2 px-4 text-center row  ftco-animate">
                           <div class="icon d-flex justify-content-center align-items-center col-3"><i class="fa fa-user"></i></span></div>
                           <div class="text col-9">
                              <h3>End User Driven Projects</h3>
                              <p>Making the user define the project according to its requirement </p>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="services-2 px-4 text-center row  ftco-animate">
                           <div class="icon d-flex justify-content-center align-items-center col-3"><i class="fa fa-handshake-o"></i></div>
                           <div class="text col-9">
                              <h3>Promise that could be delivered</h3>
                              <p>Delivering the trust to do what is required for the consumer</p>
                           </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="services-2 px-4 text-center row  ftco-animate">
                           <div class="icon d-flex justify-content-center align-items-center col-3"><i class="fa fa-user"></i></div>
                           <div class="text col-9">
                              <h3>Customer Care</h3>
                              <p>Valuing the customer more than anything, to get a name you can trust </p>
                           </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="services-2 px-4 text-center row  ftco-animate">
                           <div class="icon d-flex justify-content-center align-items-center col-3"><i class="fa fa-ban"></i></span></div>
                           <div class="text col-9">
                              <h3>No fake commitments</h3>
                              <p>Commit to build a long term relationship with the consumers</p>
                           </div>
                        </div>
                    </div>
                  </div>
               </div>
            </div>
            <!--<p><a href="#" class="btn-custom">Learn More <span class="ml-2 ion-ios-arrow-forward"></span></a></p>-->
         </div>
      </div>
   </div>
   </div>
</section>
<!--<section class="ftco-section ftco-no-pt testimony-section" id="satisfied_customer">
   <div class="overlay"></div>
   <div class="container">
      <div class="row justify-content-center mb-5 pb-3">
         <div class="col-md-8 text-center heading-section ftco-animate">
            <h2 class="mb-4">Our Satisfied Customer Says</h2>
            <p></p>
         </div>
      </div>
      <div class="row ftco-animate">
         <div class="col-md-12">
            <div class="carousel-testimony owl-carousel">
               <div class="item">
                  <div class="testimony-wrap p-4 pb-5">
                   
                     <div class="text">
                        <span class="quote d-flex align-items-center justify-content-center">
                        <i class="icon-quote-left"></i>
                        </span>
                        <p class="mb-4 line">Good to see such adorable project with good aproach and amenities near Indore, best luck Pakiza group.</p>
                        <div class="mb-4">
                           <p class="name">Ali Khan</p>
                           
                        </div>
                     </div>
                  </div>
               </div>
               <div class="item">
                  <div class="testimony-wrap p-4 pb-5">
                     
                     <div class="text">
                        <span class="quote d-flex align-items-center justify-content-center">
                        <i class="icon-quote-left"></i>
                        </span>
                        <p class="mb-4 line">Unique concept and amazing development!</p>
                        <div class="mb-4">
                           <p class="name">Abdul Hashmi</p>
                          
                        </div>
                     </div>
                  </div>
               </div>
               <div class="item">
                  <div class="testimony-wrap p-4 pb-5">
                   
                     <div class="text">
                        <span class="quote d-flex align-items-center justify-content-center">
                        <i class="icon-quote-left"></i>
                        </span>
                        <p class="mb-4 line">It was great experience. Awesome Project.</p>
                        </p>
                        <div class="mb-4">
                           <p class="name">Asif Syed</p>
                          
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>-->
<section class="ftco-section ftco-no-pt spl-arrows blogs_section">
   <div class="container">
      <div class="row">
         <div class="col-md-3 mb-5 heading-section ftco-animate">
            <h2 class="mb-4">News & Blog Updates</h2>
            <p class="mb-5">Check the latest updates and news about real estate </p>
            <p class="d-sm-none hidden-mobile"><a href="<?php echo base_url('blog')?>" class="btn-custom">Read our blog <span class="ml-2 ion-ios-arrow-forward"></span></a></p>
         </div>
         <!---blog slider---->
         <div class="col-md-9">
            
            <div class="row swiper-container swiper-blog">
               <div class="swiper-wrapper">
                  <?php foreach($blog_details as $blog){?>
                  <div class="swiper-slide">
                     <div class="blog-view">
                        <div class="blog-entry">
                           <a href="<?php echo base_url('blog_single')?>?id=<?php echo $blog->blog_id ?>" class="block-20" style="background-image: url('<?php echo base_url()?>assets/uploads/blogs/<?php echo $blog->blog_image?>');">
                           </a>
                           <div class="text py-4">
                              <div class="title">
                                  <?=nl2br(substr($blog->blog_intro,0,50)).'...';?>
                                 
                              </div>
                              <div class="meta mb-2">
                                 <div><a href="#"><?php echo $blog->created_date ?></a></div>
                                 <div><a href="#">Admin</a></div>
                                 <div><a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a></div>
                              </div>
                              <div class="desc">
                                 <h3 class="heading"><a href="<?php echo base_url('blog_single')?>?id=<?php echo $blog->blog_id ?>" class="btn-custom">Read More<span class="ml-2 ion-ios-arrow-forward"></span></a></h3>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <?php } ?>
                  
               </div>
               <div class="swiper-button-prev"></div>
               <div class="swiper-button-next"></div>
            </div>
         </div>
      </div>
   </div>
</section>

<!--  <div class="col-md-4 ftco-animate">
                     <div class="blog-entry" data-aos-delay="100">
                        <a href="<?php echo base_url('blog_single')?>" class="block-20" style="background-image: url('<?php echo base_url()?>assets/images/b2.jpg');">
                        </a>
                        <div class="text py-4">
                           <div class="meta mb-2">
                              <div><a href="#">Jan. 20, 2019</a></div>
                              <div><a href="#">Admin</a></div>
                              <div><a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a></div>
                           </div>
                           <div class="desc">
                             <h3 class="heading"><a href="<?php echo base_url('blog')?>" class="btn-custom">Know More<span class="ml-2 ion-ios-arrow-forward"></span></a></h3>
                           </div>
                        </div>
                     </div>
                     </div>-->
                  <!--<div class="col-md-4 ftco-animate">
                     <div class="blog-entry" data-aos-delay="200">
                        <a href="<?php echo base_url('blog_single')?>" class="block-20" style="background-image: url('<?php echo base_url()?>assets/images/b3.jpg');">
                        </a>
                        <div class="text py-4">
                           <div class="meta mb-2">
                              <div><a href="#">Jan. 20, 2019</a></div>
                              <div><a href="#">Admin</a></div>
                              <div><a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a></div>
                           </div>
                           <div class="desc">
                              <h3 class="heading"><a href="<?php echo base_url('blog')?>" class="btn-custom">Know More<span class="ml-2 ion-ios-arrow-forward"></span></a></h3>
                           </div>
                        </div>
                     </div>
                     </div>-->
<!--<section class="ftco-section ftco-no-pb ftco-no-pt ftco-counter img ftco-animate" id="section-counter">
   <div class="container">
      <div class="row d-md-flex align-items-center justify-content-start">
         <div class="col-lg-10">
            <div class="bg-counter p-4">
               <div class="row py-2 d-md-flex align-items-center">
                  <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                     <div class="block-18">
                        <div class="text">
                           <strong class="number" data-number="1000">0</strong>
                           <span>Properties</span>
                        </div>
                     </div>
                  </div>
                  <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                     <div class="block-18">
                        <div class="text">
                           <strong class="number" data-number="351">0</strong>
                           <span>Happy Clients</span>
                        </div>
                     </div>
                  </div>
                  <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                     <div class="block-18">
                        <div class="text">
                           <strong class="number" data-number="564">0</strong>
                           <span>Finished Projects</span>
                        </div>
                     </div>
                  </div>
                  <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                     <div class="block-18">
                        <div class="text">
                           <strong class="number" data-number="300">0</strong>
                           <span>Working Days</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   </section>-->
