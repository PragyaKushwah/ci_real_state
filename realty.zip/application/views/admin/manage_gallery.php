<style>
    .btn-success {
    background-color: #2e33d8;
    border-color: #2ed8b6;
    color: #fff;
    }
     .card-block{
        overflow:scroll;
    }
</style>

<!--Layout Starts Here-->


                        <div class="page-header card">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title"> <i class="feather icon-watch bg-c-blue"></i>
                                        <div class="d-inline">
                                            <h5>Manage Gallery</h5> <span>All the Gallery Images are managed here</span> </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="page-header-breadcrumb">
                                        <ul class=" breadcrumb breadcrumb-title">
                                            <li class="breadcrumb-item"> <a href="#"><i class="feather icon-home"></i></a> </li>
                                            <li class="breadcrumb-item"> <a href="<?php echo base_url('Admin/manage_properties')?>">Manage Properties</a> </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">
                                    <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h5>Manage Gallery</h5>
                                                        <button type="button" class="btn btn-success mb-2" data-toggle="modal" data-target="#addModal">Add New Gallery Images</button>	
                                                        <a class="btn btn-primary float-right"  href="<?php echo base_url('/Admin/manage_properties'); ?>">Back to Manage Properties</a>	
                                                        <div class="card-header-right">
                                                            <ul class="list-unstyled card-option">
                                                                <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                                                <li><i class="feather icon-maximize full-card"></i></li>
                                                                <li><i class="feather icon-minus minimize-card"></i></li>
                                                                <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                                                <li><i class="feather icon-trash close-card"></i></li>
                                                                <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class="card-block">
                                                       <table id="example" class="table display table-striped table-hover wrap m-b-0 data-table">
                                                            <thead>
                                                            <tr>
                                                            <th>S.No</th>
                                                            <th>Title</th>
                                                            <th>Image</th>
                                                            <th>Property ID</th>
                                                            <th>Action</th>
                                                            </tr>
                                                            </thead>
                                                            
                                                            <tbody>
                                                            <?php
                                                                           $i=1;
                                                                          if($gallery){
                                                                          foreach($gallery as $row)
                                                                          {
                                                                          $property_id =$row->property_id;    
                                                                        $this->session->set_userdata('property_id',$property_id);
                                                                          echo "<tr>";
                                                                          echo "<td>".$i."</td>";
                                                                          
                                                                          echo "<td>".$row->title."</td>";
                                                                         
                                                                          echo "<td>";
                                                                          ?>
                                                                          <img src='<?=base_url('/assets/uploads/gallery/').$row->gallery_image ?>' style="height:100px;width:100px"/>
                                                                          <?php
                                                                          echo "</td>";
                                                                          echo "<td>".$row->property_id."</td>";
                                                                          echo '<td><a href="update_gallery?id='.$row->id.'"><i class="icon feather icon-edit f-w-600 f-16 m-r-15 text-c-green"></i></a><a href="delete_gallery" data-toggle="modal" data-target="#delete'.$row->id .'"><i class="feather icon-trash-2 f-w-600 f-16 text-c-red"></i></a></td>';
                                                                          ?>
                                                                               <!------------------------- Modal    delete ----------------------->
                                                                                                            <div class="modal fade" id="delete<?=$row->id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                                                                              <div class="modal-dialog" role="document">
                                                                                                                <div class="modal-content">
                                                                                                                  <div class="modal-header">
                                                                                                                    <h5 class="modal-title" id="exampleModalLabel">Delete</h5>
                                                                                                                  </div>
                                                                                                                  <div class="modal-body">
                                                                                                                      <p>Are you Sure, you want to delete this data permanently.!</p>
                                                                                                                      
                                                                                                                  </div>
                                                                                                                  <div class="modal-footer">
                                                                                                                    <a  class="btn btn-secondary" data-dismiss="modal">Close</a>
                                                                                                                    <a  class="btn btn-primary" href="delete_gallery?id=<?=$row->id;?>">Delete</a>
                                                                                                                  </div>
                                                                                                                </div>
                                                                                                              </div>
                                                                                                            </div>
                                                                                                        <!------------------------- Modal    edit ----------------------->
                                                                          
                                                                          <?php
                                                                          
                                                                          
                                                                          
                                                                          echo "</tr>";
                                                                          $i++;
                                                                          }
                                                                          }
                                                                         ?>
                                                            
                                                            </tbody>
</table>

 
    <form action="<?php echo base_url('/Admin/add_gallery'); ?>" enctype="multipart/form-data" method="post">
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add New Gallery Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
             
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" class="form-control" name="title" placeholder="Title">
                </div>
         
                <div class="form-group">
                    <label>Gallery Image</label>
                    <input type="file" class="form-control" name="document" placeholder="Service icon">
                </div>
                
                <div class="form-group">
                    <label></label>
                    <input type="hidden" class="form-control" name="property_id" placeholder="Property" value=<?php echo $this->session->userdata('property_id'); ?>>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <input type="submit" name="submit" value="Add" class="btn btn-primary">
            </div>
            </div>
        </div>
        </div>
    </form>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        

<!--Layout Ends Here-->


