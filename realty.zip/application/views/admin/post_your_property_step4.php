<?php if($this->session->has_userdata('session_property_id')){ 
        $sessionid = $this->session->userdata('session_property_id');
?>
<!-- [ breadcrumb ] start -->
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="feather icon-home bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Create Properties</h5>
                    <span>Create Your Properties Here!</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url();?>admin"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Create Properties</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>
                                           
<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card latest-update-card">
                            <div class="card-header">
                                <h5>Create Property!</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-block">
                                    <?php
                                        if(isset($_SESSION['errors'])){
                                                echo "<div class='alert alert-danger'>".$_SESSION['errors']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                        }
                                    ?>
                                     <?php
                                    //   ------------------if jumping page call----------------
                                        if(isset($selected_property)){
                                            foreach($selected_property as $sproperty){?>
                                                    <?php
                                                    if(isset($select_property_media)){
                                                        if(empty($select_property_media)){
                                                          echo "<div class='alert alert-danger'>Please select property image!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                        }
                                                    }
                                                    ?>
                                                   <div class="container">
                                                        <div class="col-md-12">
                                                            <div class="row">
                                                                <a href="<?=base_url();?>create_update_property_admin/create_property/<?= $sessionid; ?>">
                                                                    <div class="num-block">
                                                                        <div class="num green"><h6>1</h6></div>
                                                                        <div class="num-block-content"><p><b  class="greenfont">Add Property</b></p></div>
                                                                    </div>
                                                                </a>
                                                                <?php
                                                                    $area = $sproperty->area;
                                                                    $name = $sproperty->name;
                                                                    $address = $sproperty->address;
                                                                    $builder = $sproperty->builder;?>
                                                            
                                                                <a href="<?=base_url();?>create_update_property_admin/create_property_step1"> 
                                                                    <?php
                                                                        if(!empty( $name && $address && $builder)){?>
                                                                        	<div class="num-block">
                                                                                <div class="num green"><h6>2</h6></div>
                                                                                <div class="num-block-content"><p><b  class="greenfont">Add Locality</b></p></div>
                                                                            </div>
                                                                        <?php }else{?>
                                                                        	<div class="num-block">
                                                                                <div class="num red"><h6>2</h6></div>
                                                                                <div class="num-block-content"><p><b class="redfont">Add Locality</b></p></div>
                                                                            </div>
                                                                        <?php }
                                                                    ?>
                                                                </a> 
                                                                <?php
                                                                    $property_status = $sproperty->property_status;
                                                                    $min_price = $sproperty->min_price;
                                                                    $description = $sproperty->description;
                                                                    $furnish_status = $sproperty->furnish_status;
                                                                    $size = $sproperty->size;
                                                                    $hall = $sproperty->hall;
                                                                    $bedrooms = $sproperty->bedrooms;
                                                                    $facing_direction = $sproperty->facing_direction;
                                                                    $payment_type = $sproperty->payment_type;
                                                                    $max_price = $sproperty->max_price;
                                                                    $maintainance_charges = $sproperty->maintainance_charges;
                                                                    $size_param = $sproperty->size_param;
                                                                    $size = $sproperty->size;
                                                                    $builtup_size = $sproperty->builtup_size;
                                                                    $carpet_size = $sproperty->carpet_size;
                                                                    $loan_offered_by = $sproperty->loan_offered_by;
                                                                    $kitchen = $sproperty->kitchen;
                                                                    $floors = $sproperty->floors;
                                                                    $bathrooms = $sproperty->bathrooms;
                                                                    $balcony = $sproperty->balcony;
                                                                    $amenities = $sproperty->amenities;
                                                                    
                                                                ?>
                                                                    
                                                                <a href="<?=base_url();?>create_update_property_admin/create_property_step2">
                                                                <?php
                                                                    if(!empty($property_status && $min_price && $description && $furnish_status && $size && $hall && $bedrooms && $facing_direction)){?>
                                                                        	<div class="num-block">
                                                                                <div class="num green"><h6>3</h6></div>
                                                                                <div class="num-block-content"><p><b  class="greenfont">Property Details</b></p></div>
                                                                            </div>
                                                                        <?php }else{?>
                                                                        	<div class="num-block">
                                                                                <div class="num red"><h6>3</h6></div>
                                                                                <div class="num-block-content"><p><b class="redfont">Property Details</b></p></div>
                                                                            </div>
                                                                        <?php }
                                                                    ?>
                                                                </a>
                                                                
                                                                <div class="num-block active"> 
                                                                    <div class="num"><h6>4</h6></div>
                                                                    <div class="num-block-content"><p><b>Add  Picture</b></p></div>
                                                                </div>
                                                            </div>
                                                            
                                                        </div>
                                                        <div class="row">
                                                            
                                                            <div class="form-group col-md-12  mt-3 pt-3 ">
                                                                <div class="row upload-img">
                                                        			<div class="col-sm-12">
                                                					    <div class="row">
                                                					        <div class="col-md-5">
                                                					            <?php echo form_open_multipart('create_update_property_admin/do_upload');?>
                                                                                    <input type="file" name="userfile[]" multiple="multiple" required>
                                                                                        
                                                                                    <br /><br />
                                                                                    <input type="text" name="property_id" value="<?= $sessionid;?>" hidden>
                                                                                    <button  name="do_upload" type="submit">Upload more Photos<br><span>Accepted File Formats jpeg, jpg</span></button>
                                                                                    
                                                                                </form>
                                                					           
                                                					        </div>
                                                					        
                                                					         <div class="col-md-1">
                                                					            <h5>or let us upload -></h5>
                                                					        </div>
                                                					        <div class="col-md-3">
                                                					            <p>Whatsapp photos on<br><span>+91-8989898989</span></p>
                                                					        </div>
                                                					        <div class="col-md-3">
                                                					            <p>Email photos on<br><span>info@propertyrealstateinindia.com</span></p>
                                                					        </div>
                                                					    </div>
                                                        			</div>
                                                        		</div>
                                                        		<div class="form-group col-md-12  mt-3 pt-3 ">
                                                        		    <div class="image_list">
                                                                        <?php
                                                                        if(isset($select_property_media)){?>
                                                                            <?php echo form_open('create_update_property_admin/add_image_caption');?>
                                                                            <?php foreach($select_property_media as $media ){?>
                                                                                 <?php if(!is_null($media->name)){ ?>
                                                                                    <img src="<?php echo base_url(); ?>/uploads/<?php echo $media->name; ?>" alt="Media" style="height:200px; width:200px;"/>
                                                                                    <input type="text" class="captions" name="captions<?=$media->id;?>" value="<?php echo $media->caption; ?>" placeholder="Enter Caption" required>
                                                                                    <input type="text" id="medianame" name="medianame" value="<?= $media->name; ?>" hidden>
                                                                                    <!--<input type="text" name="media_id[]" value="<?= $media->id; ?>" required>-->
                                                                                <?php } ?>
                                                                            <?php
                                                                            }?>
                                                                            <button name="do_upload" type="submit" class="do_upload btn btn-primary">Next</button>
                                                                            <?php echo form_close();
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                   <a class="btn btn-primary" href="<?=base_url();?>create_update_property_admin/create_property_step2">Back</a>
                                                    
                                                    
                                            <?php        
                                            }
                                        }
                                        else{?>
                                             <!--//   ------------------if come step by step in page---------------- -->
                                             <div class="container">
                                                <div class="col-md-12">
                                                    <div class="row">
                                                        <a href="<?=base_url();?>create_update_property_admin/create_property/<?= $sessionid; ?>">
                                                            <div class="num-block">
                                                                <div class="num green"><h6>1</h6></div>
                                                                <div class="num-block-content"><p><b  class="greenfont">Add Property</b></p></div>
                                                            </div>
                                                        </a>
                                                        <a href="<?=base_url();?>create_update_property_admin/create_property_step1"> 
                                                            <?php
                                                                if(!empty( $name && $address && $builder)){?>
                                                                	<div class="num-block">
                                                                        <div class="num green"><h6>2</h6></div>
                                                                        <div class="num-block-content"><p><b  class="greenfont">Add Locality</b></p></div>
                                                                    </div>
                                                                <?php }else{?>
                                                                	<div class="num-block">
                                                                        <div class="num red"><h6>2</h6></div>
                                                                        <div class="num-block-content"><p><b class="redfont">Add Locality</b></p></div>
                                                                    </div>
                                                                <?php }
                                                            ?>
                                                        </a> 
                                                        <a href="<?=base_url();?>create_update_property_admin/create_property_step2">
                                                        <?php
                                                            if(!empty($property_status && $min_price && $description && $furnish_status && $size && $hall && $bedrooms && $facing_direction)){?>
                                                                	<div class="num-block">
                                                                        <div class="num green"><h6>3</h6></div>
                                                                        <div class="num-block-content"><p><b  class="greenfont">Property Details</b></p></div>
                                                                    </div>
                                                                <?php }else{?>
                                                                	<div class="num-block">
                                                                        <div class="num red"><h6>3</h6></div>
                                                                        <div class="num-block-content"><p><b class="redfont">Property Details</b></p></div>
                                                                    </div>
                                                                <?php }
                                                            ?>
                                                        </a>
                                                        
                                                        <div class="num-block active">
                                                            <div class="num"><h6>4</h6></div>
                                                            <div class="num-block-content"><p><b>Add  Picture</b></p></div>
                                                        </div>
                                                        
                                                             <!------------field count------------->
                                                                    <?php 
                                                                        if(!empty($property_status)){
                                                                            $count = 0;
                                                                            $totalcount = 0;
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($min_price)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($description)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($furnish_status)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($size)){
                                                                            $count = 0;
                                                                            $totalcount = 0;
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($hall)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($bedrooms)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($facing_direction)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($builtup_size)){
                                                                            $count = 0;
                                                                            $totalcount = 0;
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($carpet_size)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($loan_offered_by)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($kitchen)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($floors)){
                                                                            $count = 0;
                                                                            $totalcount = 0;
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($bathrooms)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($balcony)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($amenities)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($size)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($size_param)){
                                                                            $count = 0;
                                                                            $totalcount = 0;
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($maintainance_charges)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($max_price)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                        
                                                                        if(!empty($payment_type)){
                                                                            $count = ++$count;
                                                                            $totalcount = ++$totalcount;
                                                                        }else{
                                                                            $totalcount = ++$totalcount;
                                                                        }
                                                                    ?> 
                                                                    
                                                                    
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="form-group col-md-12  mt-3 pt-3 ">
                                                        <?php
                                                        if(isset($select_property_media)){
                                                            foreach($select_property_media as $media ){?>
                                                                <p><?=$media->name;?></p>
                                                            <?php
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                    <div class="form-group col-md-12  mt-3 pt-3 ">
                                                        <div class="row upload-img">
                                                			<div class="col-sm-12">
                                        					    <div class="row">
                                        					        <div class="col-md-5">
                                            					        <?php echo form_open_multipart('create_update_property_admin/do_upload');?>
                                                                            <input type="file" name="userfile[]" multiple="multiple" required>
                                                                                
                                                                            <br /><br />
                                                                            <input type="text" name="property_id" value="<?= $property_id;?>" hidden>
                                                                            <button name="do_upload" type="submit">Upload more Photos<br><span>Accepted File Formats jpeg, jpg</span></button>
                                                                            <p class="redfont">(please select atleast one property image.)</p>
                                                                        </form>
                                        					        </div>
                                        					        
                                        					         <div class="col-md-1">
                                        					            <h5>or let us upload -></h5>
                                        					        </div>
                                        					        <div class="col-md-3">
                                        					            <p>Whatsapp photos on<br><span>+91-8989898989</span></p>
                                        					        </div>
                                        					        <div class="col-md-3">
                                        					            <p>Email photos on<br><span>info@property-realstate.com</span></p>
                                        					        </div> 
                                        					    </div>
                                                			</div>
                                                		</div>
                                                		
                                                		<div class="form-group col-md-12  mt-3 pt-3 ">
                                                		   
                                                		    <div class="image_list">
                                                                <?php
                                                                if(isset($select_property_media)){?>
                                                                    <?php $attributes = array('id'=>'mediaform'); ?>
                                                                    <?php echo form_open('create_update_property_admin/add_image_caption', $attributes);?>
                                                                    <?php foreach($select_property_media as $media ){?>
                                                                         <?php if(!is_null($media->name)){ ?>
                                                                         
                                                                           
                                                                            <img src="<?php echo base_url(); ?>/uploads/<?php echo $media->name; ?>" alt="Media" style="height:200px; width:200px;"/>
                                                                            <input type="text" class="captions" name="captions<?=$media->id;?>" value="<?php echo $media->caption; ?>" placeholder="Enter Caption" required>
                                                                             <input type="text" id="medianame" name="medianame" value="<?= $media->name; ?>" hidden>
                                                                            <!--<input type="text" name="media_id[]" value="<?= $media->id; ?>" required>-->
                                                                        <?php } ?>
                                                                    <?php
                                                                    }?>
                                                                    
                                                                    <button name="do_upload" onclick="myFunction()" type="submit" class="do_upload btn btn-primary">Next</button>
                                                                    <?php echo form_close();
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <a class="btn btn-primary" href="<?=base_url();?>create_update_property_admin/create_property_step2">Back</a>
                                            
                                        <?php } ?>
                        
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
}
else{
    redirect('admin/properties');
}
 ?>