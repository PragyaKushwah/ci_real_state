<!-- [ breadcrumb ] start -->
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="feather icon-home bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Property</h5>
                    <span>Manage Your Agents Here!</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url();?>admin"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Manage Agents</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>
                                           
<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card latest-update-card">
                            <div class="card-header">
                                <h5>Create A New Agent!</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-block">
                            <?php
                                if($this->session->flashdata('errors')){
                                    echo '<div class="alert alert-danger border-danger">
                                                <button type="button" class="close"
                                                    data-dismiss="alert" aria-label="Close">
                                                    <i class="icofont icofont-close-line-circled"></i>
                                                </button>'.
                                              $this->session->flashdata("errors")  
                                            .'</div>';
                                }else if($this->session->flashdata('success')){
                                    echo '<div class="alert alert-success border-success">
                                                <button type="button" class="close"
                                                    data-dismiss="alert" aria-label="Close">
                                                    <i class="icofont icofont-close-line-circled"></i>
                                                </button>'.
                                              $this->session->flashdata("success")  
                                            .'</div>';
                                }
                            ?>
                            <?php $attributes = array('id'=>'create_users', 'class'=>'form_horizontal'); ?>
                            
                            <?= form_open('admin/insert_roles', $attributes); ?>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <!-- Username -->
                                    <?= form_label('Name'); ?>
                                    <?php
                                        $data = array(
                                            'class' => 'form-control',
                                            'placeholder' => 'Enter User\'s Name',
                                            'name' => 'name',
                                            'type' => 'text'
                                        );
            
                                        echo form_input($data); 
                                    ?>
                                </div>
                                <div class="form-group col-md-6">
                                    <!-- Email -->
                                    <?= form_label('Email'); ?>
                                    <?php
                                        $data = array(
                                            'class' => 'form-control',
                                            'placeholder' => 'Enter Email ID',
                                            'name' => 'mail',
                                            'type' => 'text'
                                        );
                                        echo form_input($data); 
                                    ?>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <!-- Username -->
                                    <?= form_label('10 Digit Mobile Number'); ?>
                                    <?php
                                        $data = array(
                                            'class' => 'form-control',
                                            'placeholder' => 'Enter 10 Digit Contact!',
                                            'name' => 'contact',
                                            'type' => 'number',
                                            'max' => '9999999999',
                                            'min' => '0000000000'
                                        );
            
                                        echo form_input($data); 
                                    ?>
                                </div>
                                <div class="form-group col-md-6">
                                    <!-- Username -->
                                    <?= form_label('10 Digit Mobile Number For Enquiry'); ?>
                                    <?php
                                        $data = array(
                                            'class' => 'form-control',
                                            'placeholder' => 'Enter 10 Digit Contact For Enquiry!',
                                            'name' => 'viewable_contact',
                                            'type' => 'number',
                                            'max' => '9999999999',
                                            'min' => '0000000000'
                                        );
            
                                        echo form_input($data); 
                                    ?>
                                </div>
                                <!--<div class="form-group col-md-4">-->
                                    <!-- Username -->
                                    <?//= form_label('Select Role'); ?>
                                    <?php
                                        // $options = array(
                                        //         '-1'=> 'Select Role',
                                        //         '0' => 'ADMIN',
                                        //         '1' => 'AGENT',
                                        //         '2' => 'MANAGER'
                                        // );
                                        // $js = array(
                                        //         'class' => 'form-control'
                                        // );
            
                                        // echo form_dropdown('role', $options, '-1',$js);
                                    ?>
                            <!--    </div>-->
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <!-- Email -->
                                    <?= form_label('Password'); ?>
                                    <?php
                                        $data = array(
                                            'class' => 'form-control',
                                            'placeholder' => 'Enter password',
                                            'name' => 'password',
                                            'type' => 'password'
                                        );
                                        echo form_input($data); 
                                    ?>
                                </div>
                                <div class="form-group col-md-6">
                                    <!-- Email -->
                                    <?= form_label('Confirm Password!'); ?>
                                    <?php
                                        $data = array(
                                            'class' => 'form-control',
                                            'placeholder' => 'Re-enter your password',
                                            'name' => 'confirm_password',
                                            'type' => 'password'
                                        );
                                        echo form_input($data); 
                                    ?>
                                </div>
                            </div>
            
                            <?php
                                $data = array(
                                    'value' => 'Submit',
                                    'name' => 'submit_create_users',
                                    'type' => 'submit',
                                    'class' => 'btn waves-effect waves-light btn-grd-primary'
                                );
            
                                echo form_input($data); 
                            ?>
                            <?= form_close(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card latest-update-card">
                            <div class="card-header">
                                <h5>Agent List!</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-block">
                            <?php 
                                if(isset($_SESSION['upd_errors'])):
                                    echo "<div class='alert alert-danger border-danger'>".$_SESSION['upd_errors']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                endif;
                                if(isset($_SESSION['rmv_errors'])):
                                    echo "<div class='alert alert-danger border-danger'>".$_SESSION['rmv_errors']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                endif;
                                if(isset($_SESSION['agent_updated'])):
                                    echo "<div class='alert alert-success border-success'>".$_SESSION['agent_updated']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                endif;
                                if(isset($_SESSION['agent_removed'])):
                                    echo "<div class='alert alert-success border-success'>".$_SESSION['agent_removed']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                endif;
                            ?>
                                <div class="table-responsive dt-responsive">
                                    <table class="table table-striped table-bordered nowrap" id="table">
                                        <thead>
                                            <tr>
                                                <th>#id</th>
                                                <th>Name</th>
                                                <th>Contact</th>
                                                <th>Contact For Enquiry</th>
                                                <th>E-mail</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                    <?php
                                        $i = 1;
                                        foreach($results as $agent):
                                    ?>
                                            <tr>
                                                <th><?=$i;?></th>
                                                <th><?=$agent->name;?></th>
                                                <th><?=$agent->contact;?></th>
                                                <th><?=$agent->viewable_contact;?></th>
                                                <th><?=$agent->email;?></th>
                                                <td>
                                                    <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#edit<?=$agent->id;?>" data-whatever="@getbootstrap"><i class="fa fa-lg fa-edit"></i></button>
                                                    <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#remove<?=$agent->id;?>" data-whatever="@getbootstrap"><i class="fa fa-lg fa-trash"></i></button>
                                                </td>
                                            </tr>
                                            
                                    <?php
                                        $i++;
                                        endforeach;
                                    ?> 
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
    foreach($results as $agent):
?>
	<!--Modal For Remove Agent-->
    <div class="modal fade" id="remove<?=$agent->id;?>" tabindex="-1" role="dialog" aria-labelledby="remove<?=$agent->id;?>" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
			    <div class="modal-header bg-dark text-light">
			        <h4>Delete!</h4>
			    </div>
				<div class="modal-body">
				    <?php
				        echo validation_errors("<p class='bg-warning'>");
				        $attributes = array('class' => '', 'id' => 'rmvagt');
                        echo form_open('admin/remove_agent', $attributes);
                        echo form_hidden('agid',$agent->id);
				    ?>
				    <p>
				        Are You Sure You Want to Remove <strong><?=$agent->name;?></strong> ?
				    </p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
					<button type="submit" name="btn_removeAgent" class="btn btn-sm btn-danger">Remove</button>
				</div>
				<?php
				    echo form_close();
				?>
			</div>
		</div>
	</div>
<?php 
    endforeach; 
?>

<?php
    foreach($results as $agent):
?>
    <!--Modal For Update Agent-->
    <div class="modal fade" id="edit<?=$agent->id;?>" tabindex="-1" role="dialog" aria-labelledby="edit<?=$agent->id;?>" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header bg-dark text-light">
					<h5 class="modal-title" id="exampleModalLabel">Editing <?=$agent->name;?></h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body">
				    <?php
				        echo validation_errors("<p class='bg-warning'>");
				        $attributes= array('class' => '', 'id' => 'udtagt');
                        echo form_open('admin/update_agent', $attributes);
                        echo form_hidden('agid',$agent->id);
				    ?>
						<div class="form-group">
						    <?php
						        echo form_label('Agent Name!');
						        echo '<br>';
						        $attr1 = array(
                                        'name'          => 'name',
                                        'class'         => 'form-control',
                                        'id'            => 'name',
                                        'value'         => $agent->name
                                );
                                
                                echo form_input($attr1);
						    ?>
						</div>
						<div class="form-group">
						    <?php
						        echo form_label('Agent Contact!');
						        echo '<br>';
						        $attr2 = array(
                                        'name'          => 'contact',
                                        'class'         => 'form-control',
                                        'id'            => 'contact',
                                        'value'         => $agent->contact
                                );
                                
                                echo form_input($attr2);
						    ?>
						</div>
						<div class="form-group">
						    <?php
						        echo form_label('Agent Contact For Enquiry!');
						        echo '<br>';
						        $attr2 = array(
                                        'name'          => 'viewable_contact',
                                        'class'         => 'form-control',
                                        'id'            => 'viewable_contact',
                                        'value'         => $agent->viewable_contact
                                );
                                
                                echo form_input($attr2);
						    ?>
						</div>
						<div class="form-group">
						    <?php
						        echo form_label('Agent Email!');
						        echo '<br>';
						        $attr3 = array(
                                        'name'          => 'email',
                                        'class'         => 'form-control',
                                        'id'            => 'email',
                                        'value'         => $agent->email,
                                        'type'          => 'email'
                                );
                                
                                echo form_input($attr3);
						    ?>
						</div>
			    </div>
				<div class="modal-footer">
					<button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
					<button type="submit" name="btn_updateAgent" class="btn btn-sm btn-warning">Update</button>
				</div>
				<?php
				    echo form_close();
				?>
			</div>
		</div>
	</div>
<?php 
    endforeach; 
?>

