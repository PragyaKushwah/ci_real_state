<style>
   td {
    width:auto;
}
 .card-block{
        overflow:scroll;
    }
     div.dataTables_wrapper {
        margin-bottom: 3em;
    }
 /*table {
  table-layout:fixed;
}*/
/*table td {
  word-wrap: break-word;
  max-width: 450px;
  text-align:justify;
}*/
#example td {
  white-space:inherit;
  text-align:justify;
}  
</style>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
	<script>
    $(document).ready(function() {
    	$('table.display').DataTable();
    </script>
<div class="page-header card">
        <div class="row align-items-end">
            <div class="col-lg-8">
                <div class="page-header-title"> <i class="feather icon-watch bg-c-blue"></i>
                    <div class="d-inline">
                        <h5>Manage Blog</h5> 
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="page-header-breadcrumb">
                    <ul class=" breadcrumb breadcrumb-title">
                        <li class="breadcrumb-item"> <a href="<?=base_url();?>Admin/dashboard"><i class="feather icon-home"></i></a> </li>
                        <li class="breadcrumb-item"> <a href="<?=base_url();?>Admin/manage_blog">Manage Blog</a> </li>
                    </ul>
                </div>
            </div>
        </div>
</div>
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12 container">
                            <div class="card">
                                        <div class="card-header">
                                            <h5>Manage Blog</h5>
                            <button type="button" class="btn btn-success mb-2" data-toggle="modal" data-target="#addModal">Add New Blog</button>	
                                            <div class="card-header-right">
                                                <ul class="list-unstyled card-option">
                                                    <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                                    <li><i class="feather icon-maximize full-card"></i></li>
                                                    <li><i class="feather icon-minus minimize-card"></i></li>
                                                    <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                                    <li><i class="feather icon-trash close-card"></i></li>
                                                    <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                                </ul>
                                            </div>
                                        </div>
                                         <div class="card-block">
                                                    <table id="example" class="table table-striped table-hover wrap data-table display">
                                                    <thead>
                                                    <tr>
                                                    <th>S.No</th>
                                                    <th>Blog_Title</th>
                                                    <th>Blog_Intro</th>
                                                    <!--<th>Blog_Description</th>-->
                                                    <th>Blog_Image</th>
                                                    
                                                    <th>Action</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php
                                                    $i=1;
                                                    if($blog_details){
                                                    foreach($blog_details as $row)
                                                    {
                                                    echo "<tr>";
                                                    echo "<td>".$i."</td>";
                                                    echo "<td>".$row->blog_title."</td>";
                                                     echo "<td>".$row->blog_intro."</td>";
                                                    /*echo "<td>".$row->blog_description."</td>";*/
                                                    echo '<td><a class="btn btn-primary" href="view_blog_desc" data-toggle="modal" data-target="#view'.$row->blog_id .'">View Description</a></td>';
                                                    ?>
                                                    <div class="modal fade" id="view<?=$row->blog_id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                  <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                      <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Blog Description</h5>
                                                      </div>
                                                      <div class="modal-body">
                                                         <div>
                                                             <h1>Blog Description</h1>
                                                             <p><?php echo $row->blog_description; ?></p>
                                                         </div>
                                                          
                                                      </div>
                                                      <div class="modal-footer">
                                                        <a  class="btn btn-secondary" data-dismiss="modal">Close</a>
                                                        
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                            <!------------------------- Modal    edit ----------------------->
                                                    
                                                    <?php
                                                    echo "<td>";
                                                      ?>
                                                      <img src='<?=base_url('/assets/uploads/blogs/').$row->blog_image ?>' style="height:100px;width:100px"/>
                                                      <?php
                                                      echo "</td>";
                                                    
                                                   
                                                    echo '<td><a href="update_blog?id='.$row->blog_id.'"><i class="icon feather icon-edit f-w-600 f-16 m-r-15 text-c-green"></i></a><a href="delete_blog" data-toggle="modal" data-target="#delete'.$row->blog_id .'"><i class="feather icon-trash-2 f-w-600 f-16 text-c-red"></i></a></td>';
                                                    ?>
                                                      <!------------------------- Modal    delete ----------------------->
                                                <div class="modal fade" id="delete<?=$row->blog_id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                  <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                      <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Delete</h5>
                                                      </div>
                                                      <div class="modal-body">
                                                          <p>Are you Sure, you want to delete this data permanently.!</p>
                                                          
                                                      </div>
                                                      <div class="modal-footer">
                                                        <a  class="btn btn-secondary" data-dismiss="modal">Close</a>
                                                        <a  class="btn btn-primary" href="delete_blog?id=<?=$row->blog_id;?>">Delete</a>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                            <!------------------------- Modal    edit ----------------------->
                                                    
                                                    <?php
                                                    
                                                    
                                                    echo "</tr>";
                                                    $i++;
                                                    }
                                                    }
                                                    ?>
                                                    
                                                    </tbody>
                                                    </table>
                                                    <!-- Modal Add Service-->
								<form action="<?php echo base_url('/Admin/add_blog'); ?>"  enctype="multipart/form-data" method="post">
									<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
										<div class="modal-dialog" role="document">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title" id="exampleModalLabel">Add New Blog</h5>
													<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
												</div>
												<div class="modal-body">
													<div class="form-group">
														<label for="blog_title"><b>Blog_Title</b></label>
                                                        <input type="text" name="blog_title" class="form-control" placeholder="Enter Blog Title">
                                                        
                                                        <label for="blog_intro"><b>Blog_Intro</b></label>
                                                        <input type="text" name="blog_intro" class="form-control" placeholder="Enter Blog Intro">
                                                        
                                                        
                                                        
                                                        <label for="blog_desc"><b>Blog_Description</b></label>
                                                        <textarea name="blog_description" class="form-control" placeholder="Enter Blog Description"></textarea>
														
														<label for="blog_intro"><b>Blog_Image</b></label>
                                                        <input type="file" class="form-control" name="document" placeholder="Service icon">
                                                        
														

												   </div>
												<div class="modal-footer">
													<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
													<input type="submit" name="submit" value="Add" class="btn btn-primary"> </div>
											</div>
										</div>
									</div>
								</form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    </div>



	