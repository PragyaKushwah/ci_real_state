<style>
   td {
    width:auto;
}
 .card-block{
        overflow:scroll;
    }
     div.dataTables_wrapper {
        margin-bottom: 3em;
    }
 /*table {
  table-layout:fixed;
}*/
/*table td {
  word-wrap: break-word;
  max-width: 450px;
  text-align:justify;
}*/
#example td {
  white-space:inherit;
  text-align:justify;
}  
</style>
      <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
	<script>
    $(document).ready(function() {
    	$('table.display').DataTable();
    </script>
<div class="page-header card">
        <div class="row align-items-end">
            <div class="col-lg-8">
                <div class="page-header-title"> <i class="feather icon-watch bg-c-blue"></i>
                    <div class="d-inline">
                        <h5>Manage Contact</h5> 
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="page-header-breadcrumb">
                    <ul class=" breadcrumb breadcrumb-title">
                        <li class="breadcrumb-item"> <a href="<?=base_url();?>Admin/dashboard"><i class="feather icon-home"></i></a> </li>
                        <li class="breadcrumb-item"> <a href="<?=base_url();?>Admin/manage_contact">Manage Contact</a> </li>
                    </ul>
                </div>
            </div>
        </div>
</div>
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12 container">
                            <div class="card">
                                        <div class="card-header">
                                            <h5>Manage Contact</h5>
                            <button type="button" class="btn btn-success mb-2" data-toggle="modal" data-target="#addModal">Add New Contact</button>	
                                            <div class="card-header-right">
                                                <ul class="list-unstyled card-option">
                                                    <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                                    <li><i class="feather icon-maximize full-card"></i></li>
                                                    <li><i class="feather icon-minus minimize-card"></i></li>
                                                    <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                                    <li><i class="feather icon-trash close-card"></i></li>
                                                    <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                                </ul>
                                            </div>
                                        </div>
                                         <div class="card-block">
                                                    <table id="example" class="table table-striped table-hover wrap data-table display">
                                                    <thead>
                                                    <tr>
                                                    <th>S.No</th>
                                                    <th>Type</th>
                                                    <th>Detail</th>
                                                    
                                                    <th>Action</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php
                                                    $i=1;
                                                    if($contact_details){
                                                    foreach($contact_details as $row)
                                                    {
                                                    echo "<tr>";
                                                    echo "<td>".$i."</td>";
                                                    echo "<td>".$row->type."</td>";
                                                     echo "<td>".$row->detail."</td>";
                                                   
                                                    
                                                   
                                                    echo '<td><a href="update_contact?id='.$row->id.'"><i class="icon feather icon-edit f-w-600 f-16 m-r-15 text-c-green"></i></a><a href="delete_blog" data-toggle="modal" data-target="#delete'.$row->id .'"><i class="feather icon-trash-2 f-w-600 f-16 text-c-red"></i></a></td>';
                                                    ?>
                                                      <!------------------------- Modal    delete ----------------------->
                                                <div class="modal fade" id="delete<?=$row->id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                  <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                      <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Delete</h5>
                                                      </div>
                                                      <div class="modal-body">
                                                          <p>Are you Sure, you want to delete this data permanently.!</p>
                                                          
                                                      </div>
                                                      <div class="modal-footer">
                                                        <a  class="btn btn-secondary" data-dismiss="modal">Close</a>
                                                        <a  class="btn btn-primary" href="delete_contact?id=<?=$row->id;?>">Delete</a>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                            <!------------------------- Modal    edit ----------------------->
                                                    
                                                    <?php
                                                    
                                                    
                                                    echo "</tr>";
                                                    $i++;
                                                    }
                                                    }
                                                    ?>
                                                    
                                                    </tbody>
                                                    </table>
                                                    <!-- Modal Add Service-->
								<form action="<?php echo base_url('/Admin/add_contact'); ?>"   method="post">
									<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
										<div class="modal-dialog" role="document">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title" id="exampleModalLabel">Add New Contact</h5>
													<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
												</div>
												<div class="modal-body">
													<div class="form-group">
														<label for="type"><b>Type</b></label>
                                                       <select name="type" id="type">
                                                           <option value="">Select</option>
                                                           <option value="email">Email</option>
                                                           <option value="number">Number</option>
                                                       </select>
                                                        
                                                        <label for="detail"><b>Detail</b></label>
                                                        <input type="text" name="detail" class="form-control" placeholder="Enter Detail here">
                                                        
                                                        
                                                       
                                                        
														

												   </div>
												<div class="modal-footer">
													<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
													<input type="submit" name="submit" value="Add" class="btn btn-primary"> </div>
											</div>
										</div>
									</div>
								</form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    </div>



	