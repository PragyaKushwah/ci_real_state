

<!--Layout Starts Here-->
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="feather icon-watch bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Edit Contact</h5>
                    <span>Edit Contact</span> 
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item"> <a href="<?=base_url();?>Admin/dashboard"><i class="feather icon-home"></i></a> </li>
                    <li class="breadcrumb-item"> <a href="#">Edit Contact</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>Edit Contact Details</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-block">
                                <form method="POST" action="<?php echo base_url("/Admin/update_contact");?>"   >
                                <div class="form-group">
                                    <?php foreach($contact_details as $contact_detail){ ?>
                                    <input type="hidden"  name="id" value="<?php echo $contact_detail->id ;?>">
                                   
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label"  for="type"><b>Type</b></label>
                                        <div class="col-sm-10">
                                             <select class="form-control" name="type"  >
                                                 <option value="">Select</option>
                                                 <option value="<?php echo $contact_detail->type ;?>" selected = "selected"><?php echo $contact_detail->type ;?></option>
                                                 
                                                 <option value="email">Email</option>
                                                 <option value="number">Number</option>
                                             </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label"  for="detail"><b>Detail</b></label>
                                        <div class="col-sm-10">
                                             <input type="text" name="detail" class="form-control" value="<?php echo $contact_detail->detail ;?>">
                                        </div>
                                    </div>
                                    
                                    
                                    
                                    
                                    
                                    
                                    <input type="submit" name="update" class="signupbtn btn btn-primary m-b-0 " value="Update">
                                    <?php } ;?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Layout Ends Here-->

