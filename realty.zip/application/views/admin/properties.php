<!-- [ breadcrumb ] start -->
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="feather icon-home bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Properties</h5>
                    <span>Manage Your Properties Here!</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url();?>admin"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Manage Properties</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>
                                           
<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card latest-update-card">
                            <div class="card-header">
                                <h5>Create A New Property!</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-block">
                                <button type="button" class="btn btn-success btn-sm  add_property_btn" style="margin-right:20px;">
                                  <a href="<?=base_url();?>create_update_property_admin/create_property">
                                      <span class="text-white">Add New Property!</span>
                                  </a>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card latest-update-card">
                            <div class="card-header">
                                <h5>Properties List!</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            
                            <?php 
                                if(isset($_SESSION['property_created'])):
                                    echo "<div class='alert alert-success'>".$_SESSION['property_created']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                endif; 
                                if(isset($_SESSION['property_updated'])):
                                    echo "<div class='alert alert-success'>".$_SESSION['property_updated']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                endif; 
                                if(isset($_SESSION['error'])):
                                    echo "<div class='alert alert-danger'>".$_SESSION['error']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                endif; 
                            ?>
                            
                            <div class="card-block">
                                    <?php
                                        if(isset($_SESSION['rmv_errors'])){
                                            echo "<div class='alert alert-danger'>".$_SESSION['rmv_errors']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                        }
                                        if(isset($_SESSION['property_removed'])){
                                            echo "<div class='alert alert-success'>".$_SESSION['property_removed']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                        }
                                    ?>
                        
                                    <?php
                                        foreach($properties as $property):
                                    ?>
                                    
                                    
                                    <div class="col-md-12">
                                        <div class="property_list">
                                                <?php
                                                    if(($property->property_type == 1) || ($property->property_type == 6)){
                                                   
                                                           if(!empty($property->property_name)  && !empty($property->size) && !empty($property->min_price)  && !empty($property->boundary_wall) && !empty($property->open_side_no)){
                                                           }
                                                           else{?>
                                                                <div class="Property_overlay">
                                                                    <h4><?= $property->property_name;?></h4>
                                                                    <h3 class="message">Please Fill All Mandatory Details In Order To Post Your Property!</h3>
                                                                    
                                                                    <button type="button" class="btn btn-warning btn-sm " name="edit_property">
                                                                      <a href="<?=base_url();?>create_update_property_admin/create_property_step1/<?=$property->id.'/'.$property->agent.'/'.$property->property_category.'/'.$property->property_type;?>">
                                                                          <span class="text-white">Edit!</span>
                                                                      </a>
                                                                    </button>
                                                                    <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#remove<?=$property->id;?>" data-whatever="@getbootstrap">Remove!</button>
                                                                
                                                                </div>
                                                            <?php } 
                                                    }else{
                                                            if($property->property_category == 1){
                                                                   if(!empty($property->property_name) && !empty($property->size)  && !empty($property->min_price) && !empty($property->amenities) && !empty($property->hall) && !empty($property->kitchen) && !empty($property->bedrooms) || !empty($property->balcony) || !empty($property->floors) || !empty($property->bathrooms)){
                                                                   }
                                                                   else{?>
                                                                        <div class="Property_overlay">
                                                                            <h4><?= $property->property_name;?></h4>
                                                                            <!--<h4><..?= $property->property_category;?></h4>-->
                                                                            <h3 class="message">Please Fill All Mandatory Details In Order To Post Your Property!</h3>
                                                                            
                                                                            <button type="button" class="btn btn-warning btn-sm " name="edit_property">
                                                                              <a href="<?=base_url();?>create_update_property_admin/create_property_step1/<?=$property->id.'/'.$property->agent.'/'.$property->property_category.'/'.$property->property_type;?>">
                                                                                  <span class="text-white">Edit!</span>
                                                                              </a>
                                                                            </button>
                                                                            <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#remove<?=$property->id;?>" data-whatever="@getbootstrap">Remove!</button>
                                                                        
                                                                        </div>
                                                                    <?php }
                                                            }
                                                            if($property->property_category == 2){
                                                                    if(!empty($property->property_name) && !empty($property->min_price) && !empty($property->amenities)){
                                                                    }
                                                                    else{?>
                                                                        <div class="Property_overlay">
                                                                            <h4><?= $property->property_name;?></h4>
                                                                            <!--<h4><..?= $property->property_category;?></h4>-->
                                                                            <h3 class="message">Please Fill All Mandatory Details In Order To Post Your Property!</h3>
                                                                            
                                                                            <button type="button" class="btn btn-warning btn-sm " name="edit_property">
                                                                              <a href="<?=base_url();?>create_update_property/create_property_step1/<?=$property->id.'/'.$property->agent.'/'.$property->property_category.'/'.$property->property_type;?>">
                                                                                  <span class="text-white">Edit!</span>
                                                                              </a>
                                                                            </button>
                                                                            <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#remove<?=$property->id;?>" data-whatever="@getbootstrap">Remove!</button>
                                                                        
                                                                        </div>
                                                                    <?php } 
                                                            }
                                                    }
                                                    ?>
                                            
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="property_image_container">
                                                         <?php 
                                                            if($property->media_name != ''){?>
                                                               
                                                                <img src="<?php echo base_url(); ?>uploads/<?php echo $property->media_name; ?>" alt="Media" style="height:250px; width:100%;"/>
                                                            <?php }else{?>
                                                               
                                                                <img src="<?php echo base_url(); ?>assets/img/property-icon-default.jpg" alt="Media" style="height:250px; width:100%;"/>
                                                            <?php }
                                                        ?>
                                            
                                                    </div>
                                                </div>
                                                <div class="col-md-7">
                                                    <div class="property_details">
                                                        <span class="bg_black white right"><b>For <?=$property->property_purpose_name;?><span><b class="bg_white black">Rs.<?=$property->min_price;?></b></span></b></span>
                                                        <h3><?php if(isset($property->property_name)){ echo $property->property_name; }?></h3>
                                                        
                                                        <h6><span><?php if(isset($property->address)){ echo $property->address; }?></span><span><?php if(isset($property->area)){ echo $property->area; }?></span><?=$property->location_name;?></h6>
                                                        
                                                        <div class="row">
                                                            <?php
                                                            if(($property->property_type == 1) || ($property->property_type == 6)){?>
                                                                <div class="col-md-6">
                                                                    <ul>
                                                                        <li>Construction allow   :     <?=$property->floor_allowed;?> floors</li>
                                                                        <li>Face-side Road-width     :     <?=$property->facingside_roadwidth ;?> fts</li>
                                                                    </ul>  
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <ul>
                                                                        <li>Open side numbers     :     <?=$property->open_side_no;?></li>
                                                                        <li>Boundary Wall     :     <?=$property->boundary_wall ;?></li>
                                                                        
                                                                    </ul>  
                                                                </div>
                                                            <?php }else{
                                                                    if($property->property_category == 1){
                                                                    ?>
                                                                    <div class="col-md-6">
                                                                        <ul>
                                                                            <li>Hall     :     <?=$property->hall;?></li>
                                                                            <li>Kitchen     :     <?=$property->kitchen;?></li>
                                                                            <li>Bedrooms     :     <?=$property->bedrooms;?></li>
                                                                            <li>Furnish status     :     <?=$property->fur_status;?></li> 
                                                                        </ul>  
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <ul>
                                                                            <li>Balcony     :     <?=$property->balcony;?></li>
                                                                            <li>Floors     :     <?=$property->floors;?></li>
                                                                            <li>Bathrooms     :     <?=$property->bathrooms;?></li>
                                                                        </ul>
                                                                    </div>
                                                                    <?php }
                                                                    else{ ?>
                                                                        <div class="col-md-6">
                                                                            <ul>
                                                                                <li>Furnish status     :     <?=$property->fur_status;?></li>
                                                                                <li>Floors     :     <?=$property->floors;?></li>
                                                                            </ul>
                                                                        </div>
                                                                    <?php }
                                                            }
                                                            ?>
                                                        </div>
                                                        
                                                        <P><b>Area </b><?= $property->size; ?><span><?php if(isset($property->size_param)){ echo $property->size_param; }?></span></P>
                                                        <P><b>Facities Available: </b><?= $property->amenities; ?></P>
                                                        
                                                        <h6 class="right">
                                                            <?php
                                                                if($property->status == 0){?>
                                                                    <div class="property_status btn btn-danger"><h5>DEACTIVE</h5></div>
                                                                <?php }else if($property->status == 1){?>
                                                                    <div class="property_status btn btn-success"><h5>ACTIVE</h5></div>
                                                                <?php }else if($property->status == 2){?>
                                                                    <div class="property_status btn btn-primary"><h5>UNDER REVIEW</h5></div>
                                                                   
                                                                <?php }else if($property->status == 3){?>
                                                                    <div class="property_status btn btn-warning"><h5>REJECTED BY ADMIN</h5></div>
                                                                <?php }
                                                            ?>
                                                        </h6>
                                                        <button class=" right btn-oc <?php if($property->featured == 0){echo 'no';} else{echo 'yes';} ?>" id="prod<?=$property->id;?>" onclick="pushme(<?=$property->id;?>,<?=$property->featured;?>)"><?php if($property->featured == 0){echo 'no';} else{echo 'yes';} ?></button>
                                                        
                                                        <button type="button" class="btn btn-warning btn-sm " name="edit_property">
                                                          <a href="<?=base_url();?>create_update_property_admin/create_property_step1/<?=$property->id.'/'.$property->agent.'/'.$property->property_category.'/'.$property->property_type;?>">
                                                              <span class="text-white">Edit!</span>
                                                          </a>
                                                        </button>
                                                        <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#remove<?=$property->id;?>" data-whatever="@getbootstrap">Remove!</button>
                                                
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="customer_interest">
                                                        <h5>Customer Interested</h5>
                                                        <?php
                                                        $i = 0;
                                                        foreach($customer_agent_contacts as $customer){
                                                            
                                                            if($customer->property_id == $property->id){
                                                            $i++;
                                                            ?>
                                                            
                                                                <ul>
                                                                    <li><b><?=$customer->cname;?></b>:- <?=$customer->cmobile;?></li>
                                                                </ul>
                                                               
                                                            <?php
                                                            }else{
                                                                
                                                            }
                                                        }
                                                        
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                            
                                    <?php
                                        endforeach;
                                    ?>
                                    
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
    foreach($properties as $property):
?>
	<!--Modal For Remove Property-->
    <div class="modal fade" id="remove<?=$property->id;?>" tabindex="-1" role="dialog" aria-labelledby="remove<?=$property->id;?>" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-body">
				    <?php
				        echo validation_errors("<p class='bg-warning'>");
				        $attributes = array('class' => '', 'id' => 'rmvprop');
                        echo form_open('admin/remove_property', $attributes);
                        echo form_hidden('prid',$property->id);
				    ?>
				    <p>
				        Are You Sure You Want to Remove <strong><?=$property->property_name;?></strong> ?
				    </p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					<button type="submit" name="btn_removeProperty" class="btn btn-danger">Remove</button>
				</div>
				<?php
				    echo form_close();
				?>
			</div>
		</div>
	</div>
<?php endforeach; ?>
    