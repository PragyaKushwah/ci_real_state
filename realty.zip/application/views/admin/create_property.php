<!-- [ breadcrumb ] start -->
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="feather icon-home bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Create Properties</h5>
                    <span>Create Your Properties Here!</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url();?>admin"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Create Properties</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>
                                           
<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card latest-update-card">
                            <div class="card-header">
                                <h5>Create A New Property!</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-block">
                                    <?php
                                        if(isset($_SESSION['errors'])){
                                                echo "<div class='alert alert-danger'>".$_SESSION['errors']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                        }
                                    ?>
                                    
                                    <?php
                                    //   ------------------if jumping page call----------------
                                        if(isset($selected_property)){
                                            foreach($selected_property as $sproperty){
                                            $user_type = $sproperty->user_type;
                                            $property_category = $sproperty->property_category;
                                            $property_purpose = $sproperty->property_purpose;
                                            $property_type = $sproperty->property_purpose;
                                            $location = $sproperty->location;
                                            $agent = $sproperty->agent;
                                            $rera_id = $sproperty->rera_id;
                                            ?>
                                                <?php
                                                    $attributes = array('id' => 'create_property', 'name' => 'create_property', 'class'=>'form_horizontal', 'method' =>'post');
                                					echo form_open('create_update_property_admin/create_property_step1', '$attributes'); ?>
                                					<div class="row">
                                    					<div class="col-md-6">
                                    					    <h5>You are*</h5>
                                                            <div class="form-row">
                                                                <div class="form-group col-md-12">
                                                                    <?php if(isset($user_type)){
                                                                        if(!empty($user_type)){?>
                                                                            <label class="oc-chkbx-contain"><?=$user_type;?>
                                                                              <input type="radio" id="<?=$user_type;?>" name="user_type" value="<?=$user_type;?>" checked="checked">
                                                                              <span class="checkmark"></span>
                                                                            </label>
                                                                            <?php if($user_type == 'agent'){?>
                                                                            <div class="rera">
                                                                                <input type="text" name="rera_id"  placeholder="Enter RERA ID" value="<?php if(isset($rera_id)){echo $rera_id;}?>" /> 
                                                                            </div>
                                                                            <?php }?>
                                                                    <?php    
                                                                        }
                                                                    }else{?>
                                                                        <label class="oc-chkbx-contain">Owner
                                                                          <input type="radio" id="owner" name="user_type" value="owner" checked="checked">
                                                                          <span class="checkmark"></span>
                                                                        </label>
                                                                        <label class="oc-chkbx-contain">Agent
                                                                          <input type="radio" id="agent" name="user_type" value="agent" class="cp-usr-type">
                                                                          <span class="checkmark"></span>
                                                                        </label>
                                                                        <div class="rera_id">
                                                                            <input type="text" name="rera_id" class="input-spl"  placeholder="Enter RERA ID" />
                                                                        </div>
                                                                        <div class="rera-off">
                                                                        </div>
                                                                    <?php }?>
                                                                </div>
                                                            </div>
                                                            
                                                            <h5>Property Category*</h5>
                                                            <div class="form-row">
                                                                <div class="form-group col-md-12">
                                                                   
                                                                    <?php if(isset($property_category)){
                                                                            ?>
                                                                            <?php
                                                                                foreach($property_cats as $pcat){
                                                                                    if($property_category == $pcat->id){
                                                                                        
                                                                            ?>
                                                                                <label class="oc-chkbx-contain"><?= $pcat->name;?>
                                                                                  <input type="radio" name="property_category" id="<?= $pcat->name;?>" value="<?= $pcat->id;?>" checked="checked">
                                                                                  <span class="checkmark"></span>
                                                                                </label>
                                                                            <?php
                                                                                }}
                                                                            ?>
                                                                    <?php }else{?>
                                                                            <?php
                                                                                foreach($property_cats as $pcat){
                                                                            ?>
                                                                                <label class="oc-chkbx-contain"><?= $pcat->name;?>
                                                                                  <input type="radio" name="property_category" id="<?= $pcat->name;?>" value="<?= $pcat->id;?>" >
                                                                                  <span class="checkmark"></span>
                                                                                </label>
                                                                            <?php
                                                                                }
                                                                            ?>
                                                                    <?php }?>
                                                                </div>
                                                            </div>
                                                            
                                    					    <h5>Posting Property for*</h5>
                                                            <div class="form-row">
                                                                <div class="form-group col-md-12">
                                                                    <?php if(isset($property_purpose)){ ?>
                                                                            <?php
                                                                                foreach($property_purposes as $ppurpose){
                                                                                    if($property_purpose == $ppurpose->id){
                                                                            ?>
                                                                                <label class="oc-chkbx-contain"><?= $ppurpose->name;?>
                                                                                  <input type="radio" name="property_purpose" id="<?= $ppurpose->name;?>" value="<?= $ppurpose->id;?>" checked="checked" >
                                                                                  <span class="checkmark"></span>
                                                                                </label>
                                                                            <?php
                                                                               } }
                                                                            ?>
                                                                    <?php }else{?>
                                                                            <?php
                                                                                foreach($property_purposes as $ppurpose){
                                                                            ?>
                                                                                <label class="oc-chkbx-contain"><?= $ppurpose->name;?>
                                                                                  <input type="radio" name="property_purpose" id="<?= $ppurpose->name;?>" value="<?= $ppurpose->id;?>" >
                                                                                  <span class="checkmark"></span>
                                                                                </label>
                                                                            <?php
                                                                                }
                                                                            ?>
                                                                    <?php }?>
                                                                    
                                                                </div>
                                                            </div>
                                                            
                                        					<h5>Property Type*</h5>
                                                            <div class="form-row">
                                                                <div class="form-group col-md-12">
                                                                        <?php if(isset($property_type)){
                                                                                foreach($property_types as $ptype){
                                                                                    if($property_type == $ptype->id){
                                                                        ?>
                                                                                    <label class="oc-chkbx-contain"><?= $ptype->name;?>
                                                                                      <input type="radio" name="property_type" value="<?= $ptype->id;?>" checked="checked">
                                                                                      <span class="checkmark"></span>
                                                                                    </label>
                                                                                    
                                                                                <?php }}?>
                                                                        <?php }else{?>
                                                                                <?php
                                                                                    foreach($property_types as $ptype){
                                                                                        if($ptype->property_category_id == 1){
                                                                                ?>
                                                                                        <!--<div class="res_id">-->
                                                                                            <label class="res_id oc-chkbx-contain"><?= $ptype->name;?>
                                                                                              <input type="radio" name="property_type" value="<?= $ptype->id;?>" >
                                                                                              <span class="checkmark"></span>
                                                                                            </label>
                                                                                        <!--</div>-->
                                                                                        <?php } ?>
                                                                                        
                                                                                        <?php if($ptype->property_category_id == 2){?>
                                                                                        <!--<div class="comm_id">-->
                                                                                            <label class="comm_id oc-chkbx-contain"><?= $ptype->name;?>
                                                                                              <input type="radio" name="property_type" value="<?= $ptype->id;?>" >
                                                                                              <span class="checkmark"></span>
                                                                                            </label>
                                                                                        <!--</div>-->
                                                                                        <?php } ?>
                                                                                        
                                                                                <?php
                                                                                    }
                                                                                ?>
                                                                        <?php }?>
                                                                </div>
                                                            </div>
                                                        </div>
                                    					<div class="col-md-6">
                                                            <h5>City where your property is located</h5>
                                                            <div class="form-row">
                                                                <div class="form-group col-md-12">
                                                                    <?php
                                                                        $options['-1']  = 'Select City';
                                                                        foreach($locations as $state){
                                                                            if($state->parent == 0){
                                                                                //$options[$state->id] = $state->name;
                                                                                foreach($locations as $city){
                                                                                    if($city->parent == $state->id){
                                                                                        $options[$state->name][$city->id] = $city->name;
                                                                                        //$options[$city->id] = $city->name;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                        
                                                                        $js = array(
                                                                                'class' => 'form-control select-js',
                                                                                'id' => 'select_city'
                                                                        );
                                            
                                                                        echo form_dropdown('location', $options, $location,$js);
                                                                        
                                                                    ?>
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="form-row">
                                                                <div class="form-group col-md-12">
                                                                    <?= form_label('Select Agent'); ?>
                                                                    <?php
                                                                        $options_agent['-1'] = 'Select Possession Status';
                                                                        foreach($agents as $agent){
                                                                                        $options_agent[$agent->id] = $agent->name;
                                                                        }
                                            
                                                                        $js = array(
                                                                                'class' => 'form-control select-js',
                                                                                'id' => 'agent'
                                                                        );
                                            
                                                                        echo form_dropdown('agent', $options_agent, $agent,$js);
                                                                    ?>
                                                                    <?php
                                                                        // if(empty($sproperty->property_status)):
                                                                        //     echo "<div class='alert alert-warning'>Please select the Agent!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                        // endif;
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                					</div>
                                					<a class="btn btn-primary" href="<?=base_url();?>create_update_property_admin/create_property_step1">Next</a>
                                                    
                                                </div>
                                                
                                                 <?php echo form_close(); ?>
                                                    
                                            <?php        
                                            }
                                        }
                                        else{?>
                                             <!--//   ------------------if come step by step in page---------------- -->
                                          
                                             <?php
                                                    $attributes = array('id' => 'create_property','name' => 'create_property', 'class'=>'form_horizontal', 'method' =>'post');
                                					echo form_open('create_update_property_admin/create_property_step1', '$attributes'); ?>
                                					<div class="row">
                                    					<div class="col-md-6">
                                    					    <h5>You are*</h5>
                                                            <div class="form-row">
                                                                <div class="form-group col-md-12">
                                                                    <?php if(isset($user_type)){
                                                                        if(!empty($user_type)){?>
                                                                            <label class="oc-chkbx-contain"><?=$user_type;?>
                                                                              <input type="radio" id="<?=$user_type;?>" name="user_type" value="<?=$user_type;?>" checked="checked">
                                                                              <span class="checkmark"></span>
                                                                            </label>
                                                                            <?php if($user_type == 'agent'){?>
                                                                            <div class="rera">
                                                                                <input type="text" name="rera_id"  placeholder="Enter RERA ID" value="<?php if(isset($rera_id)){echo $rera_id;}?>" /> 
                                                                            </div>
                                                                            <?php }?>
                                                                    <?php    
                                                                        }
                                                                    }else{?>
                                                                            <?php if(($this->session->flashdata('flashdata_create_property') != '')){
                                                                            $flashdata_create_property = $this->session->flashdata('flashdata_create_property'); ?>
                                                                                
                                                                        
                                                                                        <?php if($flashdata_create_property['user_type'] == 'owner'){ ?>
                                                                                            <label class="oc-chkbx-contain">Owner
                                                                                              <input type="radio" id="owner" name="user_type" value="owner" checked="checked">
                                                                                              <span class="checkmark"></span>
                                                                                            </label>
                                                                                        <?php }else{ ?>
                                                                                            <label class="oc-chkbx-contain">Owner
                                                                                              <input type="radio" id="owner" name="user_type" value="owner" >
                                                                                              <span class="checkmark"></span>
                                                                                            </label>
                                                                                        <?php } ?>
                                                                                        
                                                                                        <?php if($flashdata_create_property['user_type'] == 'agent'){ ?>
                                                                                            <label class="oc-chkbx-contain">Agent
                                                                                              <input type="radio" id="agent" name="user_type" value="agent" class="cp-usr-type" checked="checked">
                                                                                              <span class="checkmark"></span>
                                                                                            </label>
                                                                                            <div class="rera_id">
                                                                                                <input type="text" name="rera_id"  placeholder="Enter RERA ID" value="<?= $flashdata_create_property['rera_id'] ?>" />
                                                                                            </div>
                                                                                        <?php }else{ ?>
                                                                                            <label class="oc-chkbx-contain">Agent
                                                                                              <input type="radio" id="agent" name="user_type" value="agent" class="cp-usr-type">
                                                                                              <span class="checkmark"></span>
                                                                                            </label>
                                                                                            <div class="rera_id">
                                                                                                <input type="text" name="rera_id"  placeholder="Enter RERA ID" />
                                                                                            </div>
                                                                                        <?php } ?>
                                                                                        
                                                                            <?php  }else{ ?>
                                                                            
                                                                                            <label class="oc-chkbx-contain">Owner
                                                                                              <input type="radio" id="owner" name="user_type" value="owner" >
                                                                                              <span class="checkmark"></span>
                                                                                            </label>
                                                                                            <label class="oc-chkbx-contain">Agent
                                                                                              <input type="radio" id="agent" name="user_type" value="agent" class="cp-usr-type">
                                                                                              <span class="checkmark"></span>
                                                                                            </label>
                                                                                            <div class="rera_id">
                                                                                                <input type="text" name="rera_id"  placeholder="Enter RERA ID" />
                                                                                            </div>
                                                                                            <div class="rera-off">
                                                                                            </div>
                                                                            
                                                                            <?php } ?>
                                                                    <?php }?>
                                                                </div>
                                                            </div>
                                                            
                                                            <h5>Property*</h5>
                                                            <div class="form-row">
                                                                <div class="form-group col-md-12">
                                                                   
                                                                    <?php if(isset($property_category)){
                                                                            ?>
                                                                            <?php
                                                                                foreach($property_cats as $pcat){
                                                                                    if($property_category == $pcat->id){
                                                                            ?>
                                                                                <label class="oc-chkbx-contain"><?= $pcat->name;?>
                                                                                  <input type="radio" name="property_category" id="<?= $pcat->name;?>" value="<?= $pcat->id;?>" checked="checked">
                                                                                  <span class="checkmark"></span>
                                                                                </label>
                                                                            <?php
                                                                                }}
                                                                            ?>
                                                                    <?php }else{?>
                                                                    
                                                                                <?php
                                                                                    foreach($property_cats as $pcat){
                                                                                ?>
                                                                                
                                                                                    <?php if(($this->session->flashdata('flashdata_create_property') != '')){
                                                                                    $flashdata_create_property = $this->session->flashdata('flashdata_create_property'); ?>
                                                                                    
                                                                            
                                                                                        <?php if($flashdata_create_property['property_category'] == $pcat->id){ ?>
                                                                                            <label class="oc-chkbx-contain"><?= $pcat->name;?>
                                                                                              <input type="radio" name="property_category" id="<?= $pcat->name;?>" value="<?= $pcat->id;?>" checked="checked" >
                                                                                              <span class="checkmark"></span>
                                                                                            </label>
                                                                                        <?php }else{ ?>
                                                                                            <label class="oc-chkbx-contain"><?= $pcat->name;?>
                                                                                              <input type="radio" name="property_category" id="<?= $pcat->name;?>" value="<?= $pcat->id;?>" >
                                                                                              <span class="checkmark"></span>
                                                                                            </label>
                                                                                        <?php } ?>
                                                                                        
                                                                                    <?php } else {?>
                                                                                    
                                                                                    <label class="oc-chkbx-contain"><?= $pcat->name;?>
                                                                                      <input type="radio" name="property_category" id="<?= $pcat->name;?>" value="<?= $pcat->id;?>" >
                                                                                      <span class="checkmark"></span>
                                                                                    </label>
                                                                                    
                                                                                    <?php } ?>
                                                                                <?php
                                                                               }
                                                                            ?>
                                                                    <?php }?>
                                                                </div>
                                                            </div>
                                                            
                                    					    <h5>Posting Property for*</h5>
                                                            <div class="form-row">
                                                                <div class="form-group col-md-12">
                                                                    <?php if(isset($property_purpose)){ ?>
                                                                            <?php
                                                                                foreach($property_purposes as $ppurpose){
                                                                                    if($property_purpose == $ppurpose->id){
                                                                            ?>
                                                                                <label class="oc-chkbx-contain"><?= $ppurpose->name;?>
                                                                                  <input type="radio" name="property_purpose" id="<?= $ppurpose->name;?>" value="<?= $ppurpose->id;?>" checked="checked" >
                                                                                  <span class="checkmark"></span>
                                                                                </label>
                                                                            <?php
                                                                               } }
                                                                            ?>
                                                                    <?php }else{?>
                                                                            <?php
                                                                                foreach($property_purposes as $ppurpose){
                                                                            ?>
                                                                            
                                                                                <?php if(($this->session->flashdata('flashdata_create_property') != '')){
                                                                                $flashdata_create_property = $this->session->flashdata('flashdata_create_property'); ?>
                                                                                
                                                                        
                                                                                    <?php if($flashdata_create_property['property_purpose'] == $ppurpose->id){ ?>
                                                                                        <label class="oc-chkbx-contain"><?= $ppurpose->name;?>
                                                                                          <input type="radio" name="property_purpose" id="<?= $ppurpose->name;?>" value="<?= $ppurpose->id;?>" checked="checked" >
                                                                                          <span class="checkmark"></span>
                                                                                        </label>
                                                                                    <?php }else{ ?>
                                                                                        <label class="oc-chkbx-contain"><?= $ppurpose->name;?>
                                                                                          <input type="radio" name="property_purpose" id="<?= $ppurpose->name;?>" value="<?= $ppurpose->id;?>" >
                                                                                          <span class="checkmark"></span>
                                                                                        </label>
                                                                                    <?php } ?>
                                                                                    
                                                                                <?php } else {?>
                                                                                    
                                                                                <label class="oc-chkbx-contain"><?= $ppurpose->name;?>
                                                                                  <input type="radio" name="property_purpose" id="<?= $ppurpose->name;?>" value="<?= $ppurpose->id;?>" >
                                                                                  <span class="checkmark"></span>
                                                                                </label>
                                                                                
                                                                            <?php
                                                                                } }
                                                                            ?>
                                                                    <?php }?>
                                                                    
                                                                </div>
                                                            </div>
                                                            
                                        					<h5>Property Type*</h5>
                                                            <div class="form-row">
                                                                <div class="form-group col-md-12">
                                                                        <?php if(isset($property_type)){
                                                                                foreach($property_types as $ptype){
                                                                                    if($property_type == $ptype->id){
                                                                        ?>
                                                                                    <label class="oc-chkbx-contain"><?= $ptype->name;?>
                                                                                      <input type="radio" name="property_type" value="<?= $ptype->id;?>" checked="checked">
                                                                                      <span class="checkmark"></span>
                                                                                    </label>
                                                                                    
                                                                                <?php }}?>
                                                                        <?php }else{?>
                                                                                <?php
                                                                                    foreach($property_types as $ptype){
                                                                                        if($ptype->property_category_id == 1){
                                                                                ?>
                                                                                
                                                                                                <?php if(($this->session->flashdata('flashdata_create_property') != '')){
                                                                                                $flashdata_create_property = $this->session->flashdata('flashdata_create_property'); ?>
                                                                                                
                                                                                        
                                                                                                    <?php if($flashdata_create_property['property_type'] == $ptype->id){ ?>
                                                                                                            <label class="res_id oc-chkbx-contain"><?= $ptype->name;?>
                                                                                                              <input type="radio" name="property_type" value="<?= $ptype->id;?>" checked="checked" >
                                                                                                              <span class="checkmark"></span>
                                                                                                            </label>
                                                                                                    <?php }else{ ?>
                                                                                                            <label class="res_id oc-chkbx-contain"><?= $ptype->name;?>
                                                                                                              <input type="radio" name="property_type" value="<?= $ptype->id;?>" >
                                                                                                              <span class="checkmark"></span>
                                                                                                            </label>
                                                                                                    <?php } ?>
                                                                                                    
                                                                                                <?php } else {?>
                                                                                                
                                                                                                        <label class="res_id oc-chkbx-contain"><?= $ptype->name;?>
                                                                                                          <input type="radio" name="property_type" value="<?= $ptype->id;?>" >
                                                                                                          <span class="checkmark"></span>
                                                                                                        </label>
                                                                                                <?php } ?>
                                                                                        <?php } ?>
                                                                                        
                                                                                        <?php if($ptype->property_category_id == 2){?>
                                                                                        
                                                                                        <?php if(($this->session->flashdata('flashdata_create_property') != '')){
                                                                                        $flashdata_create_property = $this->session->flashdata('flashdata_create_property'); ?>
                                                                                        
                                                                                
                                                                                            <?php if($flashdata_create_property['property_type'] == $ptype->id){ ?>
                                                                                                
                                                                                                    <label class="comm_id oc-chkbx-contain"><?= $ptype->name;?>
                                                                                                      <input type="radio" name="property_type" value="<?= $ptype->id;?>" checked="checked" >
                                                                                                      <span class="checkmark"></span>
                                                                                                    </label>
                                                                                            <?php }else{ ?>
                                                                                                    <label class="comm_id oc-chkbx-contain"><?= $ptype->name;?>
                                                                                                      <input type="radio" name="property_type" value="<?= $ptype->id;?>" >
                                                                                                      <span class="checkmark"></span>
                                                                                                    </label>
                                                                                            <?php } ?>
                                                                                            
                                                                                        <?php } else {?>
                                                                                                
                                                                                                <label class="comm_id oc-chkbx-contain"><?= $ptype->name;?>
                                                                                                  <input type="radio" name="property_type" value="<?= $ptype->id;?>" >
                                                                                                  <span class="checkmark"></span>
                                                                                                </label>
                                                                                        <?php } } ?>
                                                                                        
                                                                                <?php
                                                                                        }
                                                                                    }
                                                                                ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                    					<div class="col-md-6">
                                                            <h5>City where property is located</h5>
                                                            <div class="form-row">
                                                                <div class="form-group col-md-12">
                                                                    <?php if(($this->session->flashdata('flashdata_create_property') != '')){
                                                                    $flashdata_create_property = $this->session->flashdata('flashdata_create_property'); ?>
                                                                    
                                                                            <?php
                                                                                $options['-1']  = 'Select City';
                                                                                foreach($locations as $state){
                                                                                    if($state->parent == 0){
                                                                                        //$options[$state->id] = $state->name;
                                                                                        foreach($locations as $city){
                                                                                            if($city->parent == $state->id){
                                                                                                $options[$state->name][$city->id] = $city->name;
                                                                                                //$options[$city->id] = $city->name;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                    
                                                                                $js = array(
                                                                                        'class' => 'form-control select-js',
                                                                                        'id' => 'select_city'
                                                                                );?>
                                                                                
                                                                            
                                                                               
                                                                                <?php  echo form_dropdown('location', $options, $flashdata_create_property["location"],$js); ?>
                                                                    
                                                                    <?php } else {?>
                                                                    
                                                                            <?php
                                                                                $options['-1']  = 'Select City';
                                                                                foreach($locations as $state){
                                                                                    if($state->parent == 0){
                                                                                        //$options[$state->id] = $state->name;
                                                                                        foreach($locations as $city){
                                                                                            if($city->parent == $state->id){
                                                                                                $options[$state->name][$city->id] = $city->name;
                                                                                                //$options[$city->id] = $city->name;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                    
                                                                                $js = array(
                                                                                        'class' => 'form-control select-js',
                                                                                        'id' => 'select_city'
                                                                                );
                                                    
                                                                                echo form_dropdown('location', $options, '',$js);
                                                                            ?>
                                                                    <?php } ?>
                                                                    
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="form-row">
                                                                <div class="form-group col-md-12">
                                                                    <?= form_label('Select Agent'); ?>
                                                                    <?php if(($this->session->flashdata('flashdata_create_property') != '')){
                                                                    $flashdata_create_property = $this->session->flashdata('flashdata_create_property'); ?>
                                                                    
                                                                    <?php
                                                                        $options_agent['-1'] = 'Select Possession Status';
                                                                        foreach($agents as $agent){
                                                                                        $options_agent[$agent->id] = $agent->name;
                                                                        }
                                            
                                                                        $js = array(
                                                                                'class' => 'form-control select-js',
                                                                                'id' => 'agent'
                                                                        );
                                            
                                                                        echo form_dropdown('agent', $options_agent, '',$js);
                                                                    ?>
                                                                    
                                                                    <?php } else {?>
                                                                    
                                                                    <?php
                                                                        $options_agent['-1'] = 'Select Possession Status';
                                                                        foreach($agents as $agent){
                                                                                        $options_agent[$agent->id] = $agent->name;
                                                                        }
                                            
                                                                        $js = array(
                                                                                'class' => 'form-control select-js',
                                                                                'id' => 'agent'
                                                                        );
                                            
                                                                        echo form_dropdown('agent', $options_agent, '',$js);
                                                                    ?>
                                                                    
                                                                    <?php } ?>
                                                                    
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                					</div>
                                					<?php if(isset($message)){?>
                                					    <h6 class="redfont"><?=$message;?></h6>
                                					<?php } ?>
                                					<?php
                                                		$data = array(
                                                		        'type'          => 'submit',
                                                                'name'          => 'submit_create_property',
                                                                'id'            => 'submit_create_property',
                                                                'value'         => 'true',
                                                                'content'       => 'Submit',
                                                                'class'         => 'btn btn-primary'
                                                        );
                                                        
                                                        echo form_button($data);
                                                    ?>
                                                    
                                                </div>
                                                
                                                 <?php echo form_close(); ?>
                                             
                                        <?php } ?>
                        
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>

    $(document).ready(function(){
        $(".rera_id").hide();
        $(".comm_id").hide();
        
        $("#agent").click(function() {
             $(".rera_id").show();
        });
      
            if($('#agent').is(':checked')){
                $(".rera_id").show();
            }else{
                $(".rera_id").hide();
            }
            
        $("#owner").click(function() {
             $(".rera_id").hide();
        });
        
        $("#residential").click(function() {
             $(".res_id").show();
             $(".comm_id").hide();
        });
        
        $("#commercial").click(function() {
             $(".comm_id").show();
             $(".res_id").hide();
        });
        
            if($('#commercial').is(':checked')){
                $(".comm_id").show();
                $(".res_id").hide();
            }else{
                $(".comm_id").hide();
                $(".res_id").show();
            }
        
    });
    
</script>
<script>
    // function validateForm() {
    //     let agent = document.forms["create_property"]["agent"].value;
    //     if (agent == "-1") {
    //         alert("Please select Agent!");
    //         return false;
    //     }
    // } 
    
    function validate_agent() {
       
      var agent = $( "#agent options_agent:selected" ).text();
      if (agent == '-1') {
          return false;
      } 
      alert(agent);
    }
    
    function validate_location() {
       var location = $( "#select_city option:selected" ).text(); 
      if (location == '-1') {
          return false;
      } 
    }
    
    
    $('#submit_create_property').click(function () {
        validate_agent();
        validate_location();
        
    });
</script>