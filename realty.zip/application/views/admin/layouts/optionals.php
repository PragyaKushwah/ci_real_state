<?php
	if(isset($datatable)){
		if($datatable){
?>  
    		<script>
        // 		$(document).ready( function () {
        	        $('.data-table').DataTable();
        // 		} );
    		</script>
<?php
		}
	}
?>