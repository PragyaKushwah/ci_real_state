<!--<li class="pcoded-submenu">
    <a href="javascript:void(0)" class="waves-effect waves-dark">
    <span class="pcoded-micon"><i class="feather icon-sidebar"></i></span>
    <span class="pcoded-mtext">Main Menu</span>
    </a>
</li>-->
<li class="pcoded-submenu">
    <a href="<?=base_url();?>admin/manage_properties" class="waves-effect waves-dark">
    <span class="pcoded-micon"><i class="feather icon-sidebar"></i></span>
    <span class="pcoded-mtext">Manage Property</span>
    </a>
</li> 
<li class="pcoded-submenu">
    <a href="<?=base_url();?>admin/manage_blog" class="waves-effect waves-dark">
    <span class="pcoded-micon"><i class="feather icon-sidebar"></i></span>
    <span class="pcoded-mtext">Manage Blogs</span>
    </a>
</li>
<li class="pcoded-submenu">
    <a href="<?=base_url();?>admin/manage_contact" class="waves-effect waves-dark">
    <span class="pcoded-micon"><i class="feather icon-sidebar"></i></span>
    <span class="pcoded-mtext">Manage Contact</span>
    </a>
</li> 
   <!-- <ul class="pcoded-submenu">
        
        
        <li class="">
            <a href="<?=base_url();?>admin/manage_properties" class="waves-effect waves-dark">
            <span class="pcoded-mtext">Manage Property</span>
            </a>
        </li>
        <li class="">
            <a href="<?=base_url();?>admin/manage_blog" class="waves-effect waves-dark">
            <span class="pcoded-mtext">Manage Blogs</span>
            </a>
        </li>
        <li class="">
            <a href="<?=base_url();?>admin/manage_contact" class="waves-effect waves-dark">
            <span class="pcoded-mtext">Manage Contact</span>
            </a>
        </li>
    </ul>-->

<!--<li class="pcoded-hasmenu">
    <a href="javascript:void(0)" class="waves-effect waves-dark">
    <span class="pcoded-micon"><i class="feather icon-sidebar"></i></span>
    <span class="pcoded-mtext">Properties</span>
    </a>
    <ul class="pcoded-submenu">
        <li class="">
            <a href="<?=base_url();?>admin/properties" class="waves-effect waves-dark">
            <span class="pcoded-mtext">Manage Properties</span>
            </a>
        </li>
        <li class="">
            <a href="<?=base_url();?>admin/manage_property_location" class="waves-effect waves-dark">
            <span class="pcoded-mtext">Manage Locations</span>
            </a>
        </li>
        <li class="">
            <a href="<?=base_url();?>admin/manage_agents" class="waves-effect waves-dark">
            <span class="pcoded-mtext">Manage Agents</span>
            </a>
        </li>
       
    </ul>
</li>
<li class="pcoded-hasmenu">
    <a href="javascript:void(0)" class="waves-effect waves-dark">
    <span class="pcoded-micon"><i class="feather icon-sidebar"></i></span>
    <span class="pcoded-mtext">Manage Property Specifics</span>
    </a>
    <ul class="pcoded-submenu">
        <li class="">
            <a href="<?=base_url();?>admin/manage_property_type" class="waves-effect waves-dark">
            <span class="pcoded-mtext">Manage Property Type</span>
            </a>
        </li>
        <li class="">
            <a href="<?=base_url();?>admin/manage_furnish_status" class="waves-effect waves-dark">
            <span class="pcoded-mtext">Manage Furnish Status</span>
            </a>
        </li>
        <li class="">
            <a href="<?=base_url();?>admin/manage_property_status" class="waves-effect waves-dark">
            <span class="pcoded-mtext">Manage Property Status</span>
            </a>
        </li>
        <li class="">
            <a href="<?=base_url();?>admin/manage_amenities" class="waves-effect waves-dark">
            <span class="pcoded-mtext">Manage Aminities</span>
            </a>
        </li>
        <li class="">
            <a href="<?=base_url();?>admin/manage_size_parameters" class="waves-effect waves-dark">
            <span class="pcoded-mtext">Manage Size Parameters</span>
            </a>
        </li>
    </ul>
</li>-->