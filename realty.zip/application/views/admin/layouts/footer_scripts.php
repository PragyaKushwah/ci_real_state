<?php
 if(isset($page) && ($page=='dashboard')){
?>

  <script data-cfasync="false" src="<?=base_url();?>assets/admin/js/email-decode.min.js"></script>
  <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?=base_url();?>assets/admin/js/jquery.min.js"></script>
  <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?=base_url();?>assets/admin/js/jquery-ui.min.js"></script>
  <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?=base_url();?>assets/admin/js/popper.min.js"></script>
  <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?=base_url();?>assets/admin/js/bootstrap.min.js"></script>
  
  <script src="<?=base_url();?>assets/admin/js/waves.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
  
  <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?=base_url();?>assets/admin/js/jquery.slimscroll.js"></script>
  
  <script src="<?=base_url();?>assets/admin/js/jquery.flot.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
  <script src="<?=base_url();?>assets/admin/js/jquery.flot.categories.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
  <script src="<?=base_url();?>assets/admin/js/curvedlines.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
  <script src="<?=base_url();?>assets/admin/js/jquery.flot.tooltip.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
  
  <script src="<?=base_url();?>assets/admin/js/chartist.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
  <script src="<?=base_url();?>assets/admin/js/amcharts.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
  <script src="<?=base_url();?>assets/admin/js/serial.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
  <script src="<?=base_url();?>assets/admin/js/light.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
  
  <script src="<?=base_url();?>assets/admin/js/pcoded.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
  <script src="<?=base_url();?>assets/admin/js/vertical-layout.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
  <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?=base_url();?>assets/admin/js/custom-dashboard.min.js"></script>
  <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="<?=base_url();?>assets/admin/js/script.min.js"></script>
  <script src="<?=base_url();?>assets/admin/plugins/select2/select2.min.js"></script>
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
   <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.js"></script>
  <script type="d2d1d6e2f87cbebdf4013b26-text/javascript">
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
  
    gtag('config', 'UA-23581568-13');
  </script>
  <script src="<?=base_url();?>assets/admin/js/rocket-loader.min.js" data-cf-settings="d2d1d6e2f87cbebdf4013b26-|49" defer=""></script></body>
    
<?php
    
 }
?>


<?php
   if(isset($page) && ($page=='page')){
?>

  <script type="d8424a08d31b5b8b406fded2-text/javascript" src="<?=base_url();?>assets/admin/js/jquery.min.js"></script>
  <script type="d8424a08d31b5b8b406fded2-text/javascript" src="<?=base_url();?>assets/admin/js/jquery-ui.min.js"></script>
  <script type="d8424a08d31b5b8b406fded2-text/javascript" src="<?=base_url();?>assets/admin/js/popper.min.js"></script>
  <script type="d8424a08d31b5b8b406fded2-text/javascript" src="<?=base_url();?>assets/admin/js/bootstrap.min.js"></script>
  
  <script src="<?=base_url();?>assets/admin/js/waves.min.js" type="d8424a08d31b5b8b406fded2-text/javascript"></script>
  
  <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
  <script type="d8424a08d31b5b8b406fded2-text/javascript" src="<?=base_url();?>assets/admin/js/jquery.slimscroll.js"></script>
  <script src="<?=base_url();?>assets/admin/js/pcoded.min.js" type="d8424a08d31b5b8b406fded2-text/javascript"></script>
  <script src="<?=base_url();?>assets/admin/js/vertical-layout.min.js" type="d8424a08d31b5b8b406fded2-text/javascript"></script>
  
  <script type="d8424a08d31b5b8b406fded2-text/javascript" src="<?=base_url();?>assets/admin/js/script.min.js"></script>
<script src="<?=base_url();?>assets/admin/plugins/select2/select2.min.js"></script>
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13" type="d8424a08d31b5b8b406fded2-text/javascript"></script>
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.js"></script>
  <script type="d8424a08d31b5b8b406fded2-text/javascript">
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
  
    gtag('config', 'UA-23581568-13');
  </script>
  <script src="<?=base_url();?>assets/admin/js/rocket-loader.min.js" data-cf-settings="d8424a08d31b5b8b406fded2-|49" defer=""></script>
 
<?php
    
  }
?>