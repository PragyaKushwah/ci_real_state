<!-- [ breadcrumb ] start -->
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="feather icon-home bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Property Specifics</h5>
                    <span>Manage Your Property Status Here!</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url();?>admin"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Manage Property Status</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>
                                           
<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card latest-update-card">
                            <div class="card-header">
                                <h5>Create Property Status!</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-block">
                            <?php
                                if($this->session->flashdata('errors')){
                                    echo '<div class="alert alert-danger border-danger">
                                                <button type="button" class="close"
                                                    data-dismiss="alert" aria-label="Close">
                                                    <i class="icofont icofont-close-line-circled"></i>
                                                </button>'.
                                              $this->session->flashdata("errors")  
                                            .'</div>';
                                }else if($this->session->flashdata('success')){
                                    echo '<div class="alert alert-success border-success">
                                                <button type="button" class="close"
                                                    data-dismiss="alert" aria-label="Close">
                                                    <i class="icofont icofont-close-line-circled"></i>
                                                </button>'.
                                              $this->session->flashdata("success")  
                                            .'</div>';
                                }
                            ?>
                            <?php $attributes = array('id'=>'create_prop_stat', 'class'=>'form_horizontal'); ?>
                            <?= form_open('admin/insert_property_status', $attributes); ?>
                            <div class="form-row">
                                <div class="form-group col-md-12">
                                    <!-- Username -->
                                    <?= form_label('Define Property Status'); ?>
                                    <?php
                                        $data = array(
                                            'class' => 'form-control',
                                            'placeholder' => 'Enter Property Status',
                                            'name' => 'name',
                                            'type' => 'text'
                                        );
            
                                        echo form_input($data); 
                                    ?>
                                </div>
                            </div>
            
                            <?php
                                $data = array(
                                    'value' => 'Submit',
                                    'name' => 'submit_create_pstatus',
                                    'type' => 'submit',
                                    'class' => 'btn waves-effect waves-light btn-grd-primary'
                                );
            
                                echo form_input($data); 
                            ?>
                            <?= form_close(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card latest-update-card">
                            <div class="card-header">
                                <h5>Property Status List!</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-block">
                            <?php 
                                if(isset($_SESSION['upd_errors'])):
                                        echo "<div class='alert alert-danger border-danger'>".$_SESSION['upd_errors']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                endif;
                                if(isset($_SESSION['rmv_errors'])):
                                        echo "<div class='alert alert-danger border-danger'>".$_SESSION['rmv_errors']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                endif;
                                if(isset($_SESSION['prop_stat_updated'])):
                                        echo "<div class='alert alert-success border-success'>".$_SESSION['prop_stat_updated']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                endif;
                                if(isset($_SESSION['prop_stat_removed'])):
                                        echo "<div class='alert alert-success border-success'>".$_SESSION['prop_stat_removed']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                endif;
                            ?>
                                <div class="table-responsive dt-responsive">
                                    <table class="table table-striped table-bordered nowrap" id="table">
                                        <thead>
                                            <tr>
                                                <th>#id</th>
                                                <th>Name</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                    <?php
                                        $i = 1;
                                        foreach($property_status as $property_stat):
                                    ?>
                                    <tr>
                                        <th><?=$i;?></th>
                                        <th><?=$property_stat->name;?></th>
                                        <td>
                                            <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#edit<?=$property_stat->id;?>" data-whatever="@getbootstrap"><i class="fa fa-lg fa-edit"></i></button>
                                            <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#remove<?=$property_stat->id;?>" data-whatever="@getbootstrap"><i class="fa fa-lg fa-trash"></i></button>
                                        </td>
                                    </tr>
                                    <?php
                                        $i++;
                                        endforeach;
                                    ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
    foreach($property_status as $property_stat):
?>
	<!--Modal For Remove Property status-->
    <div class="modal fade" id="remove<?=$property_stat->id;?>" tabindex="-1" role="dialog" aria-labelledby="remove<?=$property_stat->id;?>" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
			    <div class="modal-header bg-dark text-white">
			        <h4>Delete!</h4>
			    </div>
				<div class="modal-body">
				    <?php
				        echo validation_errors("<p class='bg-warning'>");
				        $attributes = array('class' => '', 'id' => 'rmvpropsat');
                        echo form_open('admin/remove_property_status', $attributes);
                        echo form_hidden('psid',$property_stat->id);
				    ?>
				    <p>
				        Are You Sure You Want to Remove <strong><?=$property_stat->name;?></strong> ?
				    </p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
					<button type="submit" name="btn_removeProperty_status" class="btn btn-sm btn-danger">Remove</button>
				</div>
				<?php
				    echo form_close();
				?>
			</div>
		</div>
	</div>
<?php 
    endforeach; 
?>

<?php
    foreach($property_status as $property_stat):
?>
    <!--Modal For Update furnish status-->
    <div class="modal fade" id="edit<?=$property_stat->id;?>" tabindex="-1" role="dialog" aria-labelledby="edit<?=$property_stat->id;?>" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header bg-dark text-white">
					<h5 class="modal-title" id="exampleModalLabel">Editing <?=$property_stat->name;?></h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body">
				    <?php
				        echo validation_errors("<p class='bg-warning'>");
				        $attributes= array('class' => '', 'id' => 'udtpropsat');
                        echo form_open('admin/update_property_status', $attributes);
                        echo form_hidden('psid',$property_stat->id);
				    ?>
						<div class="form-group">
						    <?php
						        echo form_label('Enter Property Status Name!');
						        echo '<br>';
						        $attr1 = array(
                                        'name'          => 'name',
                                        'class'         => 'form-control',
                                        'id'            => 'name',
                                        'value'         => $property_stat->name
                                );
                                
                                echo form_input($attr1);
						    ?>
						</div>
			    </div>
				<div class="modal-footer">
					<button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
					<button type="submit" name="btn_updateProperty_status" class="btn btn-sm btn-warning">Update</button>
				</div>
				<?php
				    echo form_close();
				?>
			</div>
		</div>
	</div>
<?php 
    endforeach; 
?>

