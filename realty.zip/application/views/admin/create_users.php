<!-- [ breadcrumb ] start -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-12">
                <div class="page-header-title">
                    <h5 class="m-b-10">Users</h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?=base_url()?>admin/"><i class="feather icon-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="#!">Create Users</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- [ breadcrumb ] end -->
<!-- [ Main Content ] start -->
<div class="row">
    <!-- [ sample-page ] start -->
    <div class="col-sm-12">
        <div class="card">

            <div class="card-header">
                <h5>Create A New User!</h5>
                <div class="card-header-right">
                    <div class="btn-group card-option">
                        <button type="button" class="btn dropdown-toggle btn-icon" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="feather icon-more-horizontal"></i>
                        </button>
                        <ul class="list-unstyled card-option dropdown-menu dropdown-menu-right">
                            <li class="dropdown-item full-card"><a href="#!"><span><i class="feather icon-maximize"></i> maximize</span><span style="display:none"><i class="feather icon-minimize"></i> Restore</span></a></li>
                            <li class="dropdown-item minimize-card"><a href="#!"><span><i class="feather icon-minus"></i> collapse</span><span style="display:none"><i class="feather icon-plus"></i> expand</span></a></li>
                            <li class="dropdown-item reload-card"><a href="#!"><i class="feather icon-refresh-cw"></i> reload</a></li>
                            <li class="dropdown-item close-card"><a href="#!"><i class="feather icon-trash"></i> remove</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php 
                    if(isset($_SESSION['errors'])):
                        echo "<div class='alert alert-danger'>".$_SESSION['errors']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                    endif;
                    if(isset($_SESSION['user_created'])):
                        echo "<div class='alert alert-success'>".$_SESSION['user_created']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                    endif;
                ?>

                <?php $attributes = array('id'=>'create_users', 'class'=>'form_horizontal'); ?>
                
                <?= form_open('admin/insert_roles', $attributes); ?>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <!-- Username -->
                        <?= form_label('Name'); ?>
                        <?php
                            $data = array(
                                'class' => 'form-control',
                                'placeholder' => 'Enter User\'s Name',
                                'name' => 'name',
                                'type' => 'text'
                            );

                            echo form_input($data); 
                        ?>
                    </div>
                    <div class="form-group col-md-6">
                        <!-- Email -->
                        <?= form_label('Email'); ?>
                        <?php
                            $data = array(
                                'class' => 'form-control',
                                'placeholder' => 'Enter Email ID',
                                'name' => 'mail',
                                'type' => 'text'
                            );
                            echo form_input($data); 
                        ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <!-- Username -->
                        <?= form_label('10 Digit Mobile Number'); ?>
                        <?php
                            $data = array(
                                'class' => 'form-control',
                                'placeholder' => 'Enter 10 Digit Contact!',
                                'name' => 'contact',
                                'type' => 'number',
                                'max' => '9999999999',
                                'min' => '0000000000'
                            );

                            echo form_input($data); 
                        ?>
                    </div>
                    <div class="form-group col-md-4">
                        <!-- Username -->
                        <?= form_label('10 Digit Mobile Number For Enquiry'); ?>
                        <?php
                            $data = array(
                                'class' => 'form-control',
                                'placeholder' => 'Enter 10 Digit Contact For Enquiry!',
                                'name' => 'viewable_contact',
                                'type' => 'number',
                                'max' => '9999999999',
                                'min' => '0000000000'
                            );

                            echo form_input($data); 
                        ?>
                    </div>
                    <div class="form-group col-md-4">
                        <!-- Username -->
                        <?= form_label('Select Role'); ?>
                        <?php
                            $options = array(
                                    '-1'=> 'Select Role',
                                    '0' => 'ADMIN',
                                    '1' => 'AGENT',
                                    '2' => 'MANAGER'
                            );
                            $js = array(
                                    'class' => 'form-control'
                            );

                            echo form_dropdown('role', $options, '-1',$js);
                        ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <!-- Email -->
                        <?= form_label('Password'); ?>
                        <?php
                            $data = array(
                                'class' => 'form-control',
                                'placeholder' => 'Enter password',
                                'name' => 'password',
                                'type' => 'password'
                            );
                            echo form_input($data); 
                        ?>
                    </div>
                    <div class="form-group col-md-6">
                        <!-- Email -->
                        <?= form_label('Confirm Password!'); ?>
                        <?php
                            $data = array(
                                'class' => 'form-control',
                                'placeholder' => 'Re-enter your password',
                                'name' => 'confirm_password',
                                'type' => 'password'
                            );
                            echo form_input($data); 
                        ?>
                    </div>
                </div>

                <?php
                    $data = array(
                        'value' => 'Submit',
                        'name' => 'submit_create_users',
                        'type' => 'submit',
                        'class' => 'btn btn-primary'
                    );

                    echo form_input($data); 
                ?>
                <?= form_close(); ?>

            </div>
        </div>
    </div>
</div>

