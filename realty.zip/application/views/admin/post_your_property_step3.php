<?php if($this->session->has_userdata('session_property_id')){ 
     $sessionid = $this->session->userdata('session_property_id');
?>

<!-- [ breadcrumb ] start -->
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="feather icon-home bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Create Properties</h5>
                    <span>Create Your Properties Here!</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url();?>admin"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Create Properties</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>
                                           
<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card latest-update-card">
                            <div class="card-header">
                                <h5>Create Properties!</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="card-block">
                                    <?php
                                        if(isset($_SESSION['errors'])){
                                                echo "<div class='alert alert-danger'>".$_SESSION['errors']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                        }
                                    ?>
                                    
                                     <?php
                                    //   ------------------if jumping page call----------------
                                        if(isset($selected_property)){
                                            foreach($selected_property as $sproperty){?>
                                                    
                                                    <?php $attributes = array('id'=>'create_property', 'class'=>'form_horizontal'); ?>
                    
                                                    <?= form_open('create_update_property_admin/create_property_step3', $attributes); ?>
                                                    
                                                    <div class="container">
                                                        <div class="col-md-12">
                                                            <div class="row">
                                                                <a href="<?=base_url();?>create_update_property_admin/create_property/<?= $sessionid; ?>">
                                                                    <div class="num-block">
                                                                        <div class="num green"><h6>1</h6></div>
                                                                        <div class="num-block-content"><p><b  class="greenfont">Add Property</b></p></div>
                                                                    </div>
                                                                </a>
                                                                <a href="<?=base_url();?>create_update_property_admin/create_property_step1"> 
                                                                <?php
                                                                    $prop_info = array(
                                                                                    'area' => $sproperty->area,
                                                                                    'name' => $sproperty->name,
                                                                                    'address' => $sproperty->address,
                                                                                    'builder' => $sproperty->builder
                                                                                    );
                                                                ?>
                                                                        
                                                                        <?php
                                                                        if(!empty($prop_info['name'] && $prop_info['name'] && $prop_info['address'] && $prop_info['builder'])){?>
                                                                        	<div class="num-block">
                                                                                <div class="num green"><h6>2</h6></div>
                                                                                <div class="num-block-content"><p><b  class="greenfont">Add Locality</b></p></div>
                                                                            </div>
                                                                        <?php 
                                                                            }
                                                                            elseif(empty($prop_info['name'] && $prop_info['name'] && $prop_info['address'] && $prop_info['builder'])){
                                                                        ?>  
                                                                                <div class="num-block">
                                                                                    <div class="num red">
                                                                                        <h6>1</h6>
                                                                                    </div>
                                                                                    <div class="num-block-content">
                                                                                        <p><b class="redfont">Add Property</b></p>
                                                                                    </div>
                                                                                </div>
                                                                        <?php
                                                                            }
                                                                            else{
                                                                        ?>
                                                                        	<div class="num-block">
                                                                                <div class="num orange">
                                                                                    <h6>1</h6>
                                                                                </div>
                                                                                <div class="num-block-content">
                                                                                    <p><b class="redfont">Add Property</b></p>
                                                                                </div>
                                                                            </div>
                                                                        <?php         
                                                                            }
                                                                        ?>
                                                                </a>
                                                                <div class="num-block active">
                                                                    <div class="num"><h6>3</h6></div>
                                                                    <div class="num-block-content"><p><b>Property Details</b></p></div>
                                                                </div>
                                                                <a href="<?=base_url();?>create_update_property_admin/create_property_step3">
                                                                    <div class="num-block">
                                                                        <div class="num"><h6>4</h6></div>
                                                                        <div class="num-block-content"><p><b>Add  Picture</b></p></div>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            
                                                            <div class="row full-width">
                                                    			<div class="col-sm-12">
                                            					    <div class="row">
                                            					        <div class="col-md-12">
                                            					            
                                                                            <?php
                                                                                if(($this->session->userdata('session_property_type') == 6) || ($this->session->userdata('session_property_type') == 1)){ 
                                                                            ?>
                                                                            
                                                                            <?php 
                                                                                }
                                                                                else{
                                                                            ?>
                                                                                        <!-- Location Coordinates -->
                                                                                        <?= form_label('Possesion Status'); ?>
                                                                                        <?php
                                                                                            $optionsPropertyStatus['-1'] = 'Select Possession Status';
                                                                                            foreach($property_status as $status){
                                                                                                            $optionsPropertyStatus[$status->id] = $status->name;
                                                                                            }
                                                                
                                                                                            $js = array(
                                                                                                    'class' => 'form-control select-js'
                                                                                            );
                                                                
                                                                                            echo form_dropdown('property_status', $optionsPropertyStatus, $sproperty->property_status,$js);
                                                                                        ?>
                                                                                        <?php
                                                                                            if(empty($sproperty->property_status)):
                                                                                                echo "<div class='alert alert-warning'>Please select the property status!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                            endif;
                                                                                        ?>
                                                                                        
                                                                            <?php 
                                                                                } 
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                                            
                                                            <div class="row full-width">
                                                    			<div class="col-sm-12">
                                            					    <div class="row">
                                            					        <div class="col-md-12">
                                                                            <h5><?= form_label('Price Range'); ?></h5>
                                                                            <div class="form-group mt-2 mb-2 block">
                                                                                <div class="form-row">
                                                                                    <div class="col-md-6">
                                                                                    <?= form_label('Minimum Sell Price *'); ?>    
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'min_price',
                                                                                            'value' => $sproperty->min_price,
                                                                                            'type' => 'number'
                                                                                        );
                                                        
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    <?php 
                                                                                        if(empty($sproperty->min_price)):
                                                                                            echo "<div class='alert alert-warning'>Please fill the property minium price!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif;
                                                                                    ?>
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                    <?= form_label('Maximum Sell Price'); ?>
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'max_price',
                                                                                            'value' => $sproperty->max_price,
                                                                                            'type' => 'number'
                                                                                        );
                                                        
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    <?php 
                                                                                         if(empty($sproperty->max_price)):
                                                                                            echo "<div class='alert alert-warning'>Please fill the property maximum price!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif;
                                                                                    ?>
                                                                                    </div>
                                                                                </div>
                                                                                <br>
                                                                                <div class="form-row">
                                                                                    <div class="form-group col-md-6">
                                                                                    <?= form_label('Payment Type'); ?>    
                                                                                    <?php
                                                                                        $options = array(
                                                                                                'monthly_price'         => 'Monthly. Price',
                                                                                                'quaterly_price'           => 'Quaterly. Price',
                                                                                                'half_yearly_price'         => 'Half Yearly. Price',
                                                                                                'yearly_price'                   => 'Yearly. Price',
                                                                                                'one_time_price'                   => 'One Time. Price'
                                                                                        );
                                                                                        $js = array(
                                                                                                'class' => 'form-control select-js'
                                                                                        );
                                                            
                                                                                        echo form_dropdown('payment_type', $options, $sproperty->payment_type,$js);
                                                                                
                                                                                    ?>
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                    <?= form_label('Maintainance. Charges'); ?>
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'maintainance_charges',
                                                                                            'value' => $sproperty->maintainance_charges,
                                                                                            'type' => 'number'
                                                                                        );
                                                        
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    <?php
                                                                                        if(empty($sproperty->maintainance_charges)):
                                                                                            echo "<div class='alert alert-warning'>Please  fill the property maintainance charges!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif; 
                                                                                    ?>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                            					        </div>
                                            					    </div>
                                                    			</div>
                                                    		</div>
                                                        
                                                            <div class="row full-width">
                                                    			<div class="col-sm-12">
                                            					    <div class="row">
                                            					        <div class="col-md-12">
                                    					            <?php
                                                                        if(($this->session->userdata('session_property_type') == 6) || ($this->session->userdata('session_property_type') == 1)){ 
                                                                    ?>
                                                                            <div class="form-group">
                                                                                <?= form_label('Plot Description *'); ?>
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'description',
                                                                                        'value' => $sproperty->description,
                                                                                        'rows' => '2'
                                                                                    );
                                                        
                                                                                    echo form_textarea($data); 
                                                                                ?>
                                                                                <?php 
                                                                                    if(empty($sproperty->description)):
                                                                                        echo "<div class='alert alert-warning'>Please fill the description!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                    endif;
                                                                                ?>
                                                                            </div>
                                                                    <?php 
                                                                        }
                                                                        else{
                                                                    ?>
                                                                            <div class="form-group">
                                                                                <?= form_label('Property Description *'); ?>
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'description',
                                                                                        'value' => $sproperty->description,
                                                                                        'rows' => '2'
                                                                                    );
                                                        
                                                                                    echo form_textarea($data); 
                                                                                ?>
                                                                                <?php 
                                                                                    if(empty($sproperty->description)):
                                                                                        echo "<div class='alert alert-warning'>Please fill the description!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                    endif;
                                                                                ?>
                                                                            </div>
                                                                    <?php 
                                                                        }
                                                                    ?>
                                            					        </div>
                                            					    </div>
                                                    			</div>
                                                    		</div>
                                                            
                                                            <div class="row full-width">
                                                    			<div class="col-sm-12">
                                            					    <div class="row">
                                            					        <div class="col-md-12">
                                    					            <?php
                                                                        if(($this->session->userdata('session_property_type') == 6) || ($this->session->userdata('session_property_type') == 1)){ 
                                                                    ?>
                                                                    <?php 
                                                                        }
                                                                        else{
                                                                    ?>
                                                                            <div class="form-group">
                                                                                <!-- Location Coordinates -->
                                                                                <?= form_label('Furnish Status'); ?>
                                                                                <?php
                                                                                    $optionsFurnish['-1'] = 'Select Furnish Status';
                                                                                    foreach($furnish_status as $furnish){
                                                                                                    $optionsFurnish[$furnish->id] = $furnish->name;
                                                                                    }
                                                        
                                                                                    $js = array(
                                                                                            'class' => 'form-control select-js'
                                                                                    );
                                                        
                                                                                    echo form_dropdown('furnish_status', $optionsFurnish, $sproperty->furnish_status,$js);
                                                                                ?>
                                                                                <?php
                                                                                    if(empty($sproperty->furnish_status)):
                                                                                        echo "<div class='alert alert-warning'>Please select the property furnish status!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                    endif; 
                                                                                ?>
                                                                            </div>
                                                                            <?php } ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="row full-width">
                                                    			<div class="col-sm-12">
                                            					    <div class="row">
                                            					        <div class="col-md-12">
                                                                        <?php
                                                                            if(($this->session->userdata('session_property_type') == 6) || ($this->session->userdata('session_property_type') == 1)){ 
                                                                        ?>
                                                                            <h5><?= form_label('Property Area'); ?></h5>
                                                                            <div class="form-group row mt-2 mb-2 block">
                                                                               <!--<div class="row">-->
                                                                                    <div class="col-md-6">
                                                                                        <?= form_label('Area *'); ?>
                                                                                        <span class="">
                                                                                        <?php
                                                                                            $data = array(
                                                                                                'class' => 'form-control',
                                                                                                'name' => 'size',
                                                                                                'value' => $sproperty->size,
                                                                                                'type' => 'number'
                                                                                                // 'placeholder' => 'Super built up area'
                                                                                            );
                                                                
                                                                                            echo form_input($data); 
                                                                                        ?>
                                                                                        </span>
                                                                                        <?php
                                                                                            if(empty($sproperty->size)):
                                                                                                echo "<div class='alert alert-warning'>Please fill the property super builtup size!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                            endif;
                                                                                        ?>
                                                                                    </div>
                                                                                    <div class="col-md-6 ">
                                                                                            <span class="">
                                                                                            <?= form_label('Size In *'); ?><br>
                                                                                            
                                                                                           
                                                                                            <?php
                                                                                                foreach($size_param as $size){
                                                                                                    
                                                                                                        
                                                                                            ?>
                                                                                                <label class="oc-chkbx-contain"><?= $size->type;?>
                                                                                                  <input type="radio" name="size_param" id="<?= $size->type;?>" value="<?= $size->id;?>" >
                                                                                                  <span class="checkmark"></span>
                                                                                                </label>
                                                                                            <?php
                                                                                                }
                                                                                            ?>
                                                                                       
                                                                                            
                                                                                            
                                                                                            
                                                                                            <?php
                                                                                                // $optionsSize['-1'] = 'Select Size';
                                                                                                // foreach($size_param as $size){
                                                                                                //                 $optionsSize[$size->id] = $size->type;
                                                                                                // }
                                                                    
                                                                                                // $js = array(
                                                                                                //         'class' => 'form-control'
                                                                                                // );
                                                                    
                                                                                                // echo form_dropdown('size_param', $optionsSize, $sproperty->size_param,$js);
                                                                                            ?>
                                                                                            </span>
                                                                                            <?php 
                                                                                                if(empty($sproperty->size_param)):
                                                                                                    echo "<div class='alert alert-warning'>Please select the property size parameters!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                                endif;
                                                                                            ?>
                                                                                    </div>
                                                                                    
                                                                                <!--</div>-->
                                                                                
                                                                                <!--<div class="row">-->
                                                                                    <div class="form-group col-md-6">
                                                                                    <?= form_label('Facing direction *'); ?>    
                                                                                    <?php
                                                                                        $optionfacing = array(
                                                                                                'east'         => 'East',
                                                                                                'west'        => 'West',
                                                                                            'north'     => 'North',
                                                                                            'south'          => 'South',
                                                                                            'north_east'        => 'North-East',
                                                                                            'south_east'     => 'South-East',
                                                                                            'north_west'          => 'North-West',
                                                                                            'south_west'        => 'South-West'
                                                                                    );
                                                                                    $js = array(
                                                                                            'class' => 'form-control select-js'
                                                                                    );
                                                        
                                                                                    echo form_dropdown('facing_direction', $optionfacing, $sproperty->facing_direction,$js);
                                                                            
                                                                                ?>
                                                                                <?php 
                                                                                    if(empty($sproperty->facing_direction)):
                                                                                        echo "<div class='alert alert-warning'>Please fill the property facing direction!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                    endif;
                                                                                ?>
                                                                                </div>
                                                                                <div class="form-group col-md-6">
                                                                                <?= form_label('Boundary Wall'); ?>    
                                                                                <?php
                                                                                    $optionboundary = array(
                                                                                            'brick_wall'         => 'Brick Wall',
                                                                                            'fence_wall'        => 'Fence Wall',
                                                                                            'precast_component_wall'     => 'Precast Component Wall',
                                                                                            'no_boundary_wall'          => 'No Boundary Wall'
                                                                                    );
                                                                                    $js = array(
                                                                                            'class' => 'form-control select-js'
                                                                                    );
                                                        
                                                                                    echo form_dropdown('boundary_wall', $optionboundary, $sproperty->boundary_wall, $js);
                                                                            
                                                                                ?>
                                                                                <?php 
                                                                                    if(empty($sproperty->boundary_wall)):
                                                                                        echo "<div class='alert alert-warning'>Please select the property boundary wall type!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                    endif;
                                                                                ?>
                                                                                </div>
                                                                            <!--</div>-->
                                                                            <!--<div class="row">-->
                                                                                <div class="form-group col-md-6">
                                                                                    <?= form_label('Loan offered by'); ?>
                                                                                    <span class="">
                                                                                        <!--<?= form_label('Loan offered by'); ?>-->
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'loan_offered_by',
                                                                                            'value' => $sproperty->loan_offered_by,
                                                                                            'type' => 'text'
                                                                                            // 'placeholder' => 'Loan offered by'
                                                                                        );
                                                            
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    </span>
                                                                                    <?php 
                                                                                        if(empty($sproperty->loan_offered_by)):
                                                                                            echo "<div class='alert alert-warning'>Please fill the property loan offered by!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif; 
                                                                                    ?>
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    <?= form_label('Facing side Road width (in feets)'); ?>
                                                                                    <span class="">
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'facingside_roadwidth',
                                                                                            'value' => $sproperty->facingside_roadwidth,
                                                                                            'type' => 'number'
                                                                                            // 'placeholder' => 'Super built up area'
                                                                                        );
                                                            
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    </span>
                                                                                    <?php 
                                                                                        if(empty($sproperty->facingside_roadwidth)):
                                                                                            echo "<div class='alert alert-warning'>Please fill the property facing side road width!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif; 
                                                                                    ?>
                                                                                </div> 
                                                                            <!--</div>  -->
                                                                            <!--<div class="row">-->
                                                                                <div class="form-group col-md-6">
                                                                                    <?= form_label('Open Side No.'); ?>
                                                                                    <span class="">
                                                                                        <!--<?= form_label(''); ?>-->
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'open_side_no',
                                                                                            'value' => $sproperty->open_side_no,
                                                                                            'type' => 'number'
                                                                                            // 'placeholder' => 'Loan offered by'
                                                                                        );
                                                            
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    </span>
                                                                                    <?php 
                                                                                        if(empty($sproperty->open_side_no)):
                                                                                            echo "<div class='alert alert-warning'>Please fill the property open numbers of side!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif; 
                                                                                    ?>
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    <?= form_label('Floors Allowed to be constructed'); ?>
                                                                                    <span class="">
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'floor_allowed',
                                                                                            'value' => $sproperty->floor_allowed,
                                                                                            'type' => 'number'
                                                                                            // 'placeholder' => 'Super built up area'
                                                                                        );
                                                            
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    </span>
                                                                                    <?php
                                                                                        if(empty($sproperty->floor_allowed)):
                                                                                            echo "<div class='alert alert-warning'>Please fill the property floors allowed to be constructed!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif; 
                                                                                    ?>
                                                                                </div> 
                                                                            <!--</div>  -->
                                                                            
                                                                        </div>
                                                                            
                                                                            
                                                                    <?php 
                                                                        }
                                                                        else{
                                                                    ?>
                                                                        <h5><?= form_label('Property Area'); ?></h5>
                                                                        <div class="form-group mt-2 mb-2 block">
                                                                           <div class="row">
                                                                                <div class="col-md-12 ">
                                                                                        <span class="">
                                                                                        <?= form_label('Size In *'); ?><br>
                                                                                        <?php
                                                                                            foreach($size_param as $size){
                                                                                                
                                                                                                    
                                                                                        ?>
                                                                                            <label class="oc-chkbx-contain"><?= $size->type;?>
                                                                                              <input type="radio" name="size_param" id="<?= $size->type;?>" value="<?= $size->id;?>" >
                                                                                              <span class="checkmark"></span>
                                                                                            </label>
                                                                                        <?php
                                                                                            }
                                                                                        ?>
                                                                                        <?php
                                                                                            // $optionsSize['-1'] = 'Select Size';
                                                                                            // foreach($size_param as $size){
                                                                                            //                 $optionsSize[$size->id] = $size->type;
                                                                                            // }
                                                                
                                                                                            // $js = array(
                                                                                            //         'class' => 'form-control'
                                                                                            // );
                                                                
                                                                                            // echo form_dropdown('size_param', $optionsSize, $sproperty->size_param,$js);
                                                                                        ?>
                                                                                        </span>
                                                                                        <?php 
                                                                                            if(empty($sproperty->size_param)):
                                                                                                echo "<div class='alert alert-warning'>Please select the property size parameters!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                            endif;
                                                                                        ?>
                                                                                </div>
                                                                            </div>
                                                                            <?php if($this->session->userdata('session_property_category')){ 
                                                                                    if($this->session->userdata('session_property_category')==1){ 
                                                                            ?>
                                                                            <div class="row">
                                                                                <div class="col-md-4">
                                                                                    <?= form_label('Super built up area *'); ?>
                                                                                    <span class="">
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'size',
                                                                                            'value' => $sproperty->size,
                                                                                            'type' => 'number'
                                                                                            // 'placeholder' => 'Super built up area'
                                                                                        );
                                                            
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    </span>
                                                                                </div>
                                                                                <div class="col-md-4">
                                                                                    <?= form_label('Built up area'); ?>
                                                                                    <span class=""> 
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'builtup_size',
                                                                                            'value' => $sproperty->builtup_size,
                                                                                            'type' => 'number'
                                                                                            // 'placeholder' => 'Built up area'
                                                                                        );
                                                            
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    </span>
                                                                                    <?php 
                                                                                        if(empty($sproperty->builtup_size)):
                                                                                            echo "<div class='alert alert-warning'>Please fill the property builtup size!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif;
                                                                                    ?>
                                                                                </div>
                                                                                 <div class="col-md-4">
                                                                                     <?= form_label('Carpet area'); ?>
                                                                                    <span class="">
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'carpet_size',
                                                                                            'value' => $sproperty->carpet_size,
                                                                                            'type' => 'number'
                                                                                            // 'placeholder' => 'Carpet area'
                                                                                        );
                                                            
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    </span>
                                                                                    <?php 
                                                                                        if(empty($sproperty->carpet_size)):
                                                                                            echo "<div class='alert alert-warning'>Please fill the property carpet size!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif; 
                                                                                    ?>
                                                                                </div>
                                                                            </div> 
                                                                            <?php } } ?>
                                                                             <?php if($this->session->userdata('session_property_category')){ 
                                                                                    if($this->session->userdata('session_property_category')==2){ 
                                                                            ?>
                                                                            <div class="row">
                                                                                
                                                                               <div class="col-md-4">
                                                                                    <?= form_label('Super built up area *'); ?>
                                                                                    <span class="">
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'size',
                                                                                            'value' => $sproperty->size,
                                                                                            'type' => 'number'
                                                                                            // 'placeholder' => 'Super built up area'
                                                                                        );
                                                            
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    </span>
                                                                                    <?php
                                                                                        if(empty($sproperty->size)):
                                                                                            echo "<div class='alert alert-warning'>Please fill the property super builtup size!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif;
                                                                                    ?>
                                                                                </div>
                                                                                <div class="col-md-4">
                                                                                    <?= form_label('Built up area'); ?>
                                                                                    <span class=""> 
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'builtup_size',
                                                                                            'value' => $sproperty->builtup_size,
                                                                                            'type' => 'number'
                                                                                            // 'placeholder' => 'Built up area'
                                                                                        );
                                                            
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    </span>
                                                                                    <?php 
                                                                                        if(empty($sproperty->builtup_size)):
                                                                                            echo "<div class='alert alert-warning'>Please fill the property builtup size!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif;
                                                                                    ?>
                                                                                </div>
                                                                                 <div class="col-md-4">
                                                                                     <?= form_label('Carpet area'); ?>
                                                                                    <span class="">
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'carpet_size',
                                                                                            'value' => $sproperty->carpet_size,
                                                                                            'type' => 'number'
                                                                                            // 'placeholder' => 'Carpet area'
                                                                                        );
                                                            
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    </span>
                                                                                    <?php 
                                                                                        if(empty($sproperty->carpet_size)):
                                                                                            echo "<div class='alert alert-warning'>Please fill the property carpet size!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif; 
                                                                                    ?>
                                                                                </div>
                                                                                 
                                                                            </div> 
                                                                            <?php } } ?>
                                                                            
                                                                            <div class="row">
                                                                                <div class="form-group col-md-6">
                                                                                <?= form_label('Facing direction'); ?>    
                                                                                <?php
                                                                                    $optionfacing = array(
                                                                                            'east'         => 'East',
                                                                                            'west'        => 'West',
                                                                                            'north'     => 'North',
                                                                                            'south'          => 'South',
                                                                                            'north_east'        => 'North-East',
                                                                                            'south_east'     => 'South-East',
                                                                                            'north_west'          => 'North-West',
                                                                                            'south_west'        => 'South-West'
                                                                                    );
                                                                                    $js = array(
                                                                                            'class' => 'form-control select-js'
                                                                                    );
                                                        
                                                                                    echo form_dropdown('facing_direction', $optionfacing, $sproperty->facing_direction,$js);
                                                                            
                                                                                ?>
                                                                                <?php 
                                                                                    if(empty($sproperty->facing_direction)):
                                                                                        echo "<div class='alert alert-warning'>Please fill the property facing direction!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                    endif;
                                                                                ?>
                                                                                </div>
                                                                                <div class="form-group col-md-6">
                                                                                    <?= form_label('Loan offered by'); ?>
                                                                                    <span class="">
                                                                                        <?//= form_label('Loan offered by'); ?>
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'loan_offered_by',
                                                                                            'value' => $sproperty->loan_offered_by,
                                                                                            'type' => 'text'
                                                                                            // 'placeholder' => 'Loan offered by'
                                                                                        );
                                                            
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                                    </span>
                                                                                    <?php 
                                                                                        if(empty($sproperty->loan_offered_by)):
                                                                                            echo "<div class='alert alert-warning'>Please fill the property loan offered by!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif; 
                                                                                    ?>
                                                                                </div>
                                                                                 
                                                                            </div>  
                                                                        
                                                                            
                                                                        </div>
                                                                <?php } ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="row full-width">
                                                    			<div class="col-sm-12">
                                            					    <div class="row">
                                            					        <div class="col-md-12">
                                        					        <?php
                                                                        if(($this->session->userdata('session_property_type') == 6) || ($this->session->userdata('session_property_type') == 1)){ 
                                                                    ?>
                                                            
                                                                            <?php 
                                                                                }
                                                                                else{
                                                                            ?>
                                                                                    <?php if($this->session->userdata('session_property_category')){ 
                                                                                            if($this->session->userdata('session_property_category')==1){ 
                                                                                    ?>
                                                                                    <h5><?= form_label('Property Details'); ?></h5>
                                                                                    <div class="form-row">
                                                                                        <div class="form-group col-md-4">
                                                                                            <?= form_label('Bedrooms'); ?>
                                                                                            <?php
                                                                                                $data = array(
                                                                                                    'class' => 'form-control',
                                                                                                    'name' => 'bedrooms',
                                                                                                    'value' => $sproperty->bedrooms,
                                                                                                    'type' => 'number'
                                                                                                );
                                                                    
                                                                                                echo form_input($data); 
                                                                                            ?>
                                                                                            <?php
                                                                                                if(empty($sproperty->bedrooms)):
                                                                                                    echo "<div class='alert alert-warning'>Please fill the property numbers of bedrooms!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                                endif;
                                                                                            ?>
                                                                                        </div>
                                                                                        <div class="form-group col-md-4">
                                                                                            <?= form_label('Hall'); ?>
                                                                                            <?php
                                                                                                $data = array(
                                                                                                    'class' => 'form-control',
                                                                                                    'name' => 'hall',
                                                                                                    'value' => $sproperty->hall,
                                                                                                    'type' => 'number'
                                                                                                );
                                                                    
                                                                                                echo form_input($data); 
                                                                                            ?>
                                                                                            <?php
                                                                                                if(empty($sproperty->hall)):
                                                                                                    echo "<div class='alert alert-warning'>Please fill the property numbers of hall!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                                endif;
                                                                                            ?>
                                                                                        </div>
                                                                                        <div class="form-group col-md-4">
                                                                                            <?= form_label('Kitchen'); ?>
                                                                                            <?php
                                                                                                $data = array(
                                                                                                    'class' => 'form-control',
                                                                                                    'name' => 'kitchen',
                                                                                                    'value' => $sproperty->kitchen,
                                                                                                    'type' => 'number'
                                                                                                );
                                                                    
                                                                                                echo form_input($data); 
                                                                                            ?>
                                                                                            <?php
                                                                                                if(empty($sproperty->kitchen)):
                                                                                                    echo "<div class='alert alert-warning'>Please fill the property numbers of kitchen!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                                endif;
                                                                                            ?>
                                                                                        </div>
                                                                                        <div class="form-group col-md-4">
                                                                                            <?= form_label('floors'); ?>
                                                                                            <?php
                                                                                                $data = array(
                                                                                                    'class' => 'form-control',
                                                                                                    'name' => 'floors',
                                                                                                    'value' => $sproperty->floors,
                                                                                                    'type' => 'number'
                                                                                                );
                                                                    
                                                                                                echo form_input($data); 
                                                                                            ?>
                                                                                            <?php
                                                                                                 if(empty($sproperty->floors)):
                                                                                                    echo "<div class='alert alert-warning'>Please fill the property numbers of floors!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                                endif;
                                                                                            ?>
                                                                                        </div>
                                                                                        <div class="form-group col-md-4">
                                                                                            <?= form_label('bathrooms'); ?>
                                                                                            <?php
                                                                                                $data = array(
                                                                                                    'class' => 'form-control',
                                                                                                    'name' => 'bathrooms',
                                                                                                    'value' => $sproperty->bathrooms,
                                                                                                    'type' => 'number'
                                                                                                );
                                                                    
                                                                                                echo form_input($data); 
                                                                                            ?>
                                                                                            <?php
                                                                                                if(empty($sproperty->bathrooms)):
                                                                                                    echo "<div class='alert alert-warning'>Please fill the property numbers of bathrooms!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                                endif; 
                                                                                            ?>
                                                                                        </div>
                                                                                        <div class="form-group col-md-4">
                                                                                            <?= form_label('balcony'); ?>
                                                                                            <?php
                                                                                                $data = array(
                                                                                                    'class' => 'form-control',
                                                                                                    'name' => 'balcony',
                                                                                                    'value' => $sproperty->balcony,
                                                                                                    'type' => 'number'
                                                                                                );
                                                                    
                                                                                                echo form_input($data); 
                                                                                            ?>
                                                                                            <?php
                                                                                                if(empty($sproperty->bathrbalconyooms)):
                                                                                                    echo "<div class='alert alert-warning'>Please fill the property numbers of balcony!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                                endif; 
                                                                                            ?>
                                                                                        </div>
                                                                                    </div>
                                                                                    <?php } } ?>
                                                                                    <?php if($this->session->userdata('session_property_category')){ 
                                                                                            if($this->session->userdata('session_property_category')==2){ 
                                                                                    ?>
                                                                                    <h5><?= form_label('Property Details'); ?></h5>
                                                                                    <div class="form-row">
                                                                                        <div class="form-group col-md-12">
                                                                                            <?= form_label('floors'); ?>
                                                                                            <?php
                                                                                                $data = array(
                                                                                                    'class' => 'form-control',
                                                                                                    'name' => 'floors',
                                                                                                    'value' => $sproperty->floors,
                                                                                                    'type' => 'number'
                                                                                                );
                                                                    
                                                                                                echo form_input($data); 
                                                                                            ?>
                                                                                            <?php
                                                                                                 if(empty($sproperty->floors)):
                                                                                                    echo "<div class='alert alert-warning'>Please fill the property numbers of floors!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                                endif;
                                                                                            ?>
                                                                                        </div>
                                                                                    </div>
                                                                                    <?php } } ?>
                                                                            <?php } ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="row full-width">
                                                    			<div class="col-sm-12">
                                            					    <div class="row">
                                            					        <div class="col-md-12">
                                                                            <?php
                                                                                if(($this->session->userdata('session_property_type') == 6) || ($this->session->userdata('session_property_type') == 1)){ 
                                                                            ?>
                                                                            
                                                                            <?php 
                                                                                }
                                                                                else{
                                                                            ?>
                                                                                    <div class="form-row ">
                                                                                        <?php if($this->session->userdata('session_property_category')){ 
                                                                                                if($this->session->userdata('session_property_category')==1){ 
                                                                                        ?>
                                                                                        <div class="form-group col-md-12 mt-2">
                                                                                            <?= form_label('Amenities'); ?>
                                                                                            <br>
                                                                                            <div class="row">
                                                                                            <?php
                                                                                            
                                                                                            foreach($amenities as $amenity):
                                                                                                echo '<div class="col-md-3">';
                                                                                              
                                                                                                if($sproperty->amenities == $amenity->name){
                                                                                                    $data = [
                                                                                                            'name'    => 'amenities[]',
                                                                                                            'value'   => $amenity->name,
                                                                                                            'checked'       => TRUE,
                                                                                                            'style'   => 'margin:10px'
                                                                                                    ];
                                                                                                    
                                                                                                    echo form_checkbox($data);
                                                                                                    echo form_label($amenity->name);
                                                                                                }else{
                                                                                                    $data = [
                                                                                                            'name'    => 'amenities[]',
                                                                                                            'value'   => $amenity->name,
                                                                                                            'style'   => 'margin:10px'
                                                                                                    ];
                                                                                                    
                                                                                                    echo form_checkbox($data);
                                                                                                    echo form_label($amenity->name);
                                                                                                }
                                                                                                
                                                                                                echo '</div>';
                                                                                            endforeach;
                                                                                            ?>
                                                                                        </div>
                                                                                        <?php }} ?>
                                                                                        
                                                                                        <?php if($this->session->userdata('session_property_category')){ 
                                                                                                if($this->session->userdata('session_property_category')==2){ 
                                                                                        ?>
                                                                                        <div class="form-group col-md-12 mt-2">
                                                                                            <?= form_label('Amenities'); ?>
                                                                                            <br>
                                                                                            <div class="row">
                                                                                            <?php
                                                                                            
                                                                                            foreach($amenitiestwo as $amenity):
                                                                                                echo '<div class="col-md-3">';
                                                                                              
                                                                                                if($sproperty->amenities == $amenity->name){
                                                                                                    $data = [
                                                                                                            'name'    => 'amenities[]',
                                                                                                            'value'   => $amenity->name,
                                                                                                            'checked'       => TRUE,
                                                                                                            'style'   => 'margin:10px'
                                                                                                    ];
                                                                                                    
                                                                                                    echo form_checkbox($data);
                                                                                                    echo form_label($amenity->name);
                                                                                                }else{
                                                                                                    $data = [
                                                                                                            'name'    => 'amenities[]',
                                                                                                            'value'   => $amenity->name,
                                                                                                            'style'   => 'margin:10px'
                                                                                                    ];
                                                                                                    
                                                                                                    echo form_checkbox($data);
                                                                                                    echo form_label($amenity->name);
                                                                                                }
                                                                                                
                                                                                                echo '</div>';
                                                                                            endforeach;
                                                                                            ?>
                                                                                        </div>
                                                                                        <?php }} ?>
                                                                                    </div>
                                                                            <?php } ?>
                                                                                <input type="text" value="<?=$property_id;?>" name="property_id" hidden>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                            <a class="btn btn-primary" href="<?=base_url();?>create_update_property_admin/create_property_step1">Back</a>
                                                            <?php
                                                                $data = array(
                                                                    'value' => 'Next',
                                                                    'name' => 'submit_property',
                                                                    'type' => 'submit',
                                                                    'class' => 'btn btn-primary nextbtn'
                                                                );
                                            
                                                                echo form_input($data); 
                                                            ?>
                                                            
                                                            </div>
                                                    
                                                </div>
                                                
                                                    <?= form_close(); ?>
                                                    
                                            <?php        
                                            }
                                        }
                                        else{?>
                                             <!--//   ------------------if come step by step in page---------------- -->
                                             <?php $attributes = array('id'=>'create_property', 'class'=>'form_horizontal'); ?>
                    
                                                <?= form_open('create_update_property_admin/create_property_step3', $attributes); ?>
                                                
                                                <div class="container">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="row">
                                                                <div class="num-block">
                                                                    <div class="num green"><h6>1</h6></div>
                                                                    <div class="num-block-content"><p><b  class="greenfont">Add Property</b></p></div>
                                                                </div>
                                                                <a href="<?=base_url();?>create_update_property_admin/create_property_step1">
                                                                    <!------------field count------------->
                                                                    <?php 
                                                                        // if(!empty($area)){
                                                                        //     $count = 0;
                                                                        //     $totalcount = 0;
                                                                        //     $count = ++$count;
                                                                        //     $totalcount = ++$totalcount;
                                                                        // }else{
                                                                        //     $totalcount = ++$totalcount;
                                                                        // }
                                                                        
                                                                        // if(!empty($name)){
                                                                        //     $count = ++$count;
                                                                        //     $totalcount = ++$totalcount;
                                                                        // }else{
                                                                        //     $totalcount = ++$totalcount;
                                                                        // }
                                                                        
                                                                        // if(!empty($address)){
                                                                        //     $count = ++$count;
                                                                        //     $totalcount = ++$totalcount;
                                                                        // }else{
                                                                        //     $totalcount = ++$totalcount;
                                                                        // }
                                                                        
                                                                        // if(!empty($builder)){
                                                                        //     $count = ++$count;
                                                                        //     $totalcount = ++$totalcount;
                                                                        // }else{
                                                                        //     $totalcount = ++$totalcount;
                                                                        // }
                                                                    ?>
                                                                    <!--------------------------------------->
                                                                            
                                                                    <?php
                                                                        if(!empty($area && $name && $address && $builder)){?>
                                                                        	<div class="num-block">
                                                                                <div class="num green"><h6>2</h6></div>
                                                                                <div class="num-block-content"><p><b  class="greenfont">Add Locality</b></p></div>
                                                                            </div>
                                                                        <?php }else{?>
                                                                        	<div class="num-block">
                                                                                <div class="num red"><h6>2</h6></div>
                                                                                <div class="num-block-content"><p><b class="redfont">Add Locality</b></p></div>
                                                                            </div>
                                                                        <?php }
                                                                    ?>
                                                                </a>
                                                                <div class="num-block active">
                                                                    <div class="num"><h6>3</h6></div>
                                                                    <div class="num-block-content"><p><b>Property Details</b></p></div>
                                                                </div>
                                                                
                                                                <div class="num-block">
                                                                    <div class="num"><h6>4</h6></div>
                                                                    <div class="num-block-content"><p><b>Add  Picture</b></p></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <input type="text" value="<?=$area;?>" name="name" hidden>
                                                        <input type="text" value="<?=$name;?>" name="name" hidden>
                                                        <input type="text" value="<?=$address;?>" name="address" hidden>
                                                        <input type="text" value="<?=$builder;?>" name="builder" hidden>
                                                    </div>
                                                    <div class="row">
                                                    <div class="col-md-12">
                                                        
                                                        <div class="row full-width">
                                                			<div class="col-sm-12">
                                        					    <div class="row">
                                        					        <div class="col-md-12">
                                                                        <?= form_label('Possesion Status'); ?>
                                                                        <?php
                                                                            $optionsPropertyStatus['-1'] = 'Select Possession Status';
                                                                            foreach($property_status as $status){
                                                                                            $optionsPropertyStatus[$status->id] = $status->name;
                                                                            }
                                                
                                                                            $js = array(
                                                                                    'class' => 'form-control select-js'
                                                                            );
                                                
                                                                            echo form_dropdown('property_status', $optionsPropertyStatus, '-1',$js);
                                                                        ?>
                                        					        </div>
                                        					    </div>
                                                			</div>
                                                		</div>
                                                		
                                                		<div class="row full-width">
                                                			<div class="col-sm-12">
                                        					    <div class="row">
                                        					        <div class="col-md-12">
                                                                    <h5><?= form_label('Price Range'); ?></h5>
                                                                        <div class="form-row">
                                                                            <div class="col-md-6">
                                                                                <?php if(($this->session->flashdata('min_price') != '')){
                                                                                    $flashdata_create_property_step2 = $this->session->flashdata('flashdata_create_property_step2'); ?>
                                                                                            <?= form_label('Minimu Sell Price *'); ?>
                                                                                            <?php
                                                                                                $data = array(
                                                                                                    'class' => 'form-control',
                                                                                                    'name' => 'min_price',
                                                                                                    'value' => $flashdata_create_property_step2['min_price'],
                                                                                                    'type' => 'number'
                                                                                                );
                                                                
                                                                                                echo form_input($data); 
                                                                                            ?>
                                                                                <?php }else{ ?>                                                        
                                                                                            <?= form_label('Minimum Sell Price *'); ?>
                                                                                            <?php
                                                                                                $data = array(
                                                                                                    'class' => 'form-control',
                                                                                                    'name' => 'min_price',
                                                                                                    'type' => 'number'
                                                                                                );
                                                                
                                                                                                echo form_input($data); 
                                                                                            ?>
                                                                                <?php } ?>
                                                                                
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                            <?= form_label('Maximum Sell Price'); ?>
                                                                            <?php
                                                                                $data = array(
                                                                                    'class' => 'form-control',
                                                                                    'name' => 'max_price',
                                                                                    'type' => 'number'
                                                                                );
                                                
                                                                                echo form_input($data); 
                                                                            ?>
                                                                            </div>
                                                                        </div>
                                                                        <br>
                                                                        <div class="form-row">
                                                                            <div class="form-group col-md-6">
                                                                            <?= form_label('Payment Type'); ?>    
                                                                            <?php
                                                                                $options = array(
                                                                                        'monthly_price'         => 'Monthly. Price',
                                                                                        'quaterly_price'           => 'Quaterly. Price',
                                                                                        'half_yearly_price'         => 'Half Yearly. Price',
                                                                                        'yearly_price'                   => 'Yearly. Price',
                                                                                        'one_time_price'                   => 'One Time. Price'
                                                                                );
                                                                                $js = array(
                                                                                        'class' => 'form-control select-js'
                                                                                );
                                                    
                                                                                echo form_dropdown('payment_type', $options, '',$js);
                                                                        
                                                                            ?>
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                            <?= form_label('Maintainance. Charges'); ?>
                                                                            <?php
                                                                                $data = array(
                                                                                    'class' => 'form-control',
                                                                                    'name' => 'maintainance_charges',
                                                                                    'type' => 'number'
                                                                                );
                                                
                                                                                echo form_input($data); 
                                                                            ?>
                                                                            </div>
                                                                        </div>
                                        					        </div>
                                        					    </div>
                                                			</div>
                                                		</div>
                                                    		
                                                		<div class="row full-width">
                                                			<div class="col-sm-12">
                                        					    <div class="row">
                                        					        <div class="col-md-12">
                                                                        <?php if(($this->session->flashdata('description') != '')){
                                                                                    $flashdata_create_property_step2 = $this->session->flashdata('flashdata_create_property_step2'); ?>
                                                                                    <?= form_label('Property Description *'); ?>
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'description',
                                                                                            'value' => $flashdata_create_property_step2['description'],
                                                                                            'rows' => '2'
                                                                                        );
                                                            
                                                                                        echo form_textarea($data); 
                                                                                    ?>
                                                                        <?php }else{ ?>                                                        
                                                                                    <?= form_label('Property Description *'); ?>
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'name' => 'description',
                                                                                            'rows' => '2'
                                                                                        );
                                                            
                                                                                        echo form_textarea($data); 
                                                                                    ?>
                                                                        <?php } ?>
                                        					        </div>
                                        					    </div>
                                                			</div>
                                                		</div>
                                                		
                                                		<div class="row full-width">
                                                			<div class="col-sm-12">
                                        					    <div class="row">
                                        					        <div class="col-md-12">
                                                                        <!-- Location Coordinates -->
                                                                        <?= form_label('Furnish Status'); ?>
                                                                        <?php
                                                                            $optionsFurnish['-1'] = 'Select Furnish Status';
                                                                            foreach($furnish_status as $furnish){
                                                                                            $optionsFurnish[$furnish->id] = $furnish->name;
                                                                            }
                                                
                                                                            $js = array(
                                                                                    'class' => 'form-control select-js'
                                                                            );
                                                
                                                                            echo form_dropdown('furnish_status', $optionsFurnish, '-1',$js);
                                                                        ?>
                                                                        <?php
                                                                            if(empty($sproperty->furnish_status)):
                                                                                echo "<div class='alert alert-warning'>Please select the property furnish status!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                            endif; 
                                                                        ?>
                                        					        </div>
                                        					    </div>
                                                			</div>
                                                		</div>
                                                		
                                                		<div class="row full-width">
                                                			<div class="col-sm-12">
                                        					    <div class="row">
                                        					        <div class="col-md-12">
                                                                        <h5><?= form_label('Property Area'); ?></h5>
                                                                        <div class="row">
                                                                            <div class="col-md-12 ">
                                                                                <span class="">
                                                                                        <?php if(($this->session->flashdata('size_param') != '')){
                                                                                            $flashdata_create_property_step2 = $this->session->flashdata('flashdata_create_property_step2'); ?>
                                                                                                    
                                                                                                    <?= form_label('Size In *'); ?><br>
                                                                                                    <?php
                                                                                                        foreach($size_param as $size){
                                                                                                    ?>
                                                                                                        <label class="oc-chkbx-contain"><?= $size->type;?>
                                                                                                          <input type="radio" name="size_param" id="<?= $size->type;?>" value="<?= $size->id;?>">
                                                                                                          <span class="checkmark"></span>
                                                                                                        </label>
                                                                                                    <?php
                                                                                                        }
                                                                                                    ?>
                                                                                                    <?php
                                                                                                        // $optionsSize['-1'] = 'Select Size';
                                                                                                        // foreach($size_param as $size){
                                                                                                        //                 $optionsSize[$size->id] = $size->type;
                                                                                                        // }
                                                                            
                                                                                                        // $js = array(
                                                                                                        //         'class' => 'form-control'
                                                                                                        // );
                                                                            
                                                                                                        // echo form_dropdown('size_param', $optionsSize, $flashdata_create_property_step2['size_param'],$js);
                                                                                                    ?>
                                                                                        <?php }else{ ?>                                                        
                                                                                                    <?= form_label('Size In *'); ?><br>
                                                                                                    <?php
                                                                                                        foreach($size_param as $size){
                                                                                                            
                                                                                                                
                                                                                                    ?>
                                                                                                        <label class="oc-chkbx-contain"><?= $size->type;?>
                                                                                                          <input type="radio" name="size_param" id="<?= $size->type;?>" value="<?= $size->id;?>" >
                                                                                                          <span class="checkmark"></span>
                                                                                                        </label>
                                                                                                    <?php
                                                                                                        }
                                                                                                    ?>
                                                                                                    
                                                                                        <?php } ?>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        <?php if($this->session->userdata('session_property_category')){ 
                                                                                if($this->session->userdata('session_property_category')==1){ 
                                                                        ?>
                                                                        <div class="row">
                                                                            <div class="col-md-4">
                                                                                <?= form_label('Super built up area *'); ?>
                                                                                <span class="">
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'size',
                                                                                        'type' => 'number'
                                                                                        // 'placeholder' => 'Super built up area'
                                                                                    );
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                                </span>
                                                                            </div>
                                                                            <div class="col-md-4">
                                                                                <?= form_label('Built up area'); ?>
                                                                                <span class=""> 
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'builtup_size',
                                                                                        'type' => 'number'
                                                                                        // 'placeholder' => 'Built up area'
                                                                                    );
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                                </span>
                                                                            </div>
                                                                             <div class="col-md-4">
                                                                                 <?= form_label('Carpet area'); ?>
                                                                                <span class="">
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'carpet_size',
                                                                                        'type' => 'number'
                                                                                        // 'placeholder' => 'Carpet area'
                                                                                    );
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        <br>
                                                                        <?php }} ?>
                                                                        <?php if($this->session->userdata('session_property_category')){
                                                                                if($this->session->userdata('session_property_category')==2){?>
                                                                        <div class="row">
                                                                            <div class="col-md-4">
                                                                                <?= form_label('Super built up area *'); ?>
                                                                                <span class="">
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'size',
                                                                                        'type' => 'number'
                                                                                        // 'placeholder' => 'Super built up area'
                                                                                    );
                                                        
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                                </span>
                                                                            </div>
                                                                            <div class="col-md-4">
                                                                                <?= form_label('Built up area'); ?>
                                                                                <span class=""> 
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'builtup_size',
                                                                                        'type' => 'number'
                                                                                        // 'placeholder' => 'Built up area'
                                                                                    );
                                                        
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                                </span>
                                                                            </div>
                                                                             <div class="col-md-4">
                                                                                 <?= form_label('Carpet area'); ?>
                                                                                <span class="">
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'carpet_size',
                                                                                        'type' => 'number'
                                                                                        // 'placeholder' => 'Carpet area'
                                                                                    );
                                                        
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                        <?php }} ?>
                                                                        <div class="row">
                                                                            <div class="form-group col-md-6">
                                                                            <?php if(($this->session->flashdata('facing_direction') != '')){
                                                                                $flashdata_create_property_step2 = $this->session->flashdata('flashdata_create_property_step2'); ?>
                                                                                        <?= form_label('Facing direction *'); ?>    
                                                                                        <?php
                                                                                            $optionfacing = array(
                                                                                                    'east'         => 'East',
                                                                                                    'west'        => 'West',
                                                                                                    'north'     => 'North',
                                                                                                    'south'          => 'South',
                                                                                                    'north_east'        => 'North-East',
                                                                                                    'south_east'     => 'South-East',
                                                                                                    'north_west'          => 'North-West',
                                                                                                    'south_west'        => 'South-West'
                                                                                            );
                                                                                            $js = array(
                                                                                                    'class' => 'form-control select-js'
                                                                                            );
                                                                
                                                                                            echo form_dropdown('facing_direction', $optionfacing, $flashdata_create_property_step2['facing_direction'],$js);
                                                                                    
                                                                                        ?>
                                                                            <?php }else{ ?>                                                        
                                                                                        <?= form_label('Facing direction'); ?>    
                                                                                        <?php
                                                                                            $optionfacing = array(
                                                                                                    'east'         => 'East',
                                                                                                    'west'        => 'West',
                                                                                                    'north'     => 'North',
                                                                                                    'south'          => 'South',
                                                                                                    'north_east'        => 'North-East',
                                                                                                    'south_east'     => 'South-East',
                                                                                                    'north_west'          => 'North-West',
                                                                                                    'south_west'        => 'South-West'
                                                                                            );
                                                                                            $js = array(
                                                                                                    'class' => 'form-control select-js'
                                                                                            );
                                                                
                                                                                            echo form_dropdown('facing_direction', $optionfacing, '',$js);
                                                                                    
                                                                                        ?>
                                                                            <?php } ?>
                                                                            </div>
                                                                            <div class="form-group col-md-6">
                                                                                <?= form_label('Loan offered by'); ?>
                                                                                <span class="">
                                                                                    <!--<?= form_label('Loan offered by'); ?>-->
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'loan_offered_by',
                                                                                        'type' => 'text'
                                                                                        // 'placeholder' => 'Loan offered by'
                                                                                    );
                                                        
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                        					        </div>
                                        					    </div>
                                                			</div>
                                                		</div>
                                                		
                                                		<div class="row full-width">
                                                			<div class="col-sm-12">
                                        					    <div class="row">
                                        					        <div class="col-md-12">
                                                                        <h5><?= form_label('Property Details'); ?></h5>
                                        					            <?php if($this->session->userdata('session_property_category')){ 
                                                                            if($this->session->userdata('session_property_category')==1){ 
                                                                        ?>
                                                                        <div class="form-row">
                                                                            <div class="form-group col-md-4">
                                                                                <?= form_label('Bedrooms'); ?>
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'bedrooms',
                                                                                        'type' => 'number'
                                                                                    );
                                                        
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                                <?php
                                                                                    if(empty($sproperty->bedrooms)):
                                                                                        echo "<div class='alert alert-warning'>Please fill the property numbers of bedrooms!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                    endif;
                                                                                ?>
                                                                            </div>
                                                                            <div class="form-group col-md-4">
                                                                                <?= form_label('Hall'); ?>
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'hall',
                                                                                        'type' => 'number'
                                                                                    );
                                                        
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                            </div>
                                                                            <div class="form-group col-md-4">
                                                                                <?= form_label('Kitchen'); ?>
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'kitchen',
                                                                                        'type' => 'number'
                                                                                    );
                                                        
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                            </div>
                                                                            <div class="form-group col-md-4">
                                                                                <?= form_label('floors'); ?>
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'floors',
                                                                                        'type' => 'number'
                                                                                    );
                                                        
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                            </div>
                                                                            <div class="form-group col-md-4">
                                                                                <?= form_label('bathrooms'); ?>
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'bathrooms',
                                                                                        'type' => 'number'
                                                                                    );
                                                        
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                            </div>
                                                                            <div class="form-group col-md-4">
                                                                                <?= form_label('balcony'); ?>
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'balcony',
                                                                                        'type' => 'number'
                                                                                    );
                                                        
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                            </div>
                                                                        </div>
                                                                        <?php } } ?>
                                                                        <?php if($this->session->userdata('session_property_category')){ 
                                                                                if($this->session->userdata('session_property_category')==2){ 
                                                                        ?>
                                                                        <div class="form-row">
                                                                            <div class="form-group col-md-12">
                                                                                <?= form_label('floors'); ?>
                                                                                <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'floors',
                                                                                        // 'value' => $sproperty->floors,
                                                                                        'type' => 'number'
                                                                                    );
                                                        
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                            </div>
                                                                        </div>
                                                                        <?php } } ?>
                                        					        </div>
                                        					    </div>
                                                			</div>
                                                		</div>
                                                		
                                                		<div class="row full-width">
                                                			<div class="col-sm-12">
                                        					    <div class="row">
                                        					        <div class="col-md-12">
                                        					            <div class="form-row ">
                                                                <?php if($this->session->userdata('session_property_category')){ 
                                                                        if($this->session->userdata('session_property_category')==1){ 
                                                                ?>    
                                                                            <div class="form-group col-md-12 mt-2">
                                                                                <?= form_label('Amenities'); ?>
                                                                                <br>
                                                                                <div class="row">
                                                                                    <?php
                                                                                    
                                                                                    foreach($amenities as $amenity):
                                                                                        echo '<div class="col-md-3">';
                                                                                        $data = [
                                                                                                'name'    => 'amenities[]',
                                                                                                'value'   => $amenity->name,
                                                                                                'style'   => 'margin:10px'
                                                                                        ];
                                                                                        
                                                                                        echo form_checkbox($data);
                                                                                        echo form_label($amenity->name);
                                                                                        echo '</div>';
                                                                                    endforeach;
                                                                                    ?>
                                                                                </div>
                                                                <?php } } ?>   
                                                                <?php if($this->session->userdata('session_property_category')){ 
                                                                        if($this->session->userdata('session_property_category')==2){ 
                                                                ?>    
                                                                            <div class="form-group col-md-12 mt-2">
                                                                                <?= form_label('Amenities'); ?>
                                                                                <br>
                                                                                <div class="row">
                                                                                    <?php
                                                                                    
                                                                                    foreach($amenitiestwo as $amenity):
                                                                                        echo '<div class="col-md-3">';
                                                                                        $data = [
                                                                                                'name'    => 'amenities[]',
                                                                                                'value'   => $amenity->name,
                                                                                                'style'   => 'margin:10px'
                                                                                        ];
                                                                                        
                                                                                        echo form_checkbox($data);
                                                                                        echo form_label($amenity->name);
                                                                                        echo '</div>';
                                                                                    endforeach;
                                                                                    ?>
                                                                                </div>
                                                                <?php } } ?>   
                                                                            </div>
                                                                            <input type="text" value="<?=$property_id;?>" name="property_id" hidden>
                                                                            </div>
                                                                        </div>
                                        					        </div>
                                        					    </div>
                                                			</div>
                                                		</div>
                                                		
                                                		<a class="btn btn-primary" href="<?=base_url();?>create_update_property_admin/create_property_step1">Back</a>
                                                            <?php
                                                                $data = array(
                                                                    'value' => 'Next',
                                                                    'name' => 'submit_property',
                                                                    'type' => 'submit',
                                                                    'class' => 'btn btn-primary nextbtn'
                                                                );
                                            
                                                                echo form_input($data); 
                                                            ?>
                                                		
                                                        
                                                        </div>
                                                    </div>
                                            
                                                <?= form_close(); ?>
                                        <?php } ?>
                                    
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  
<?php 
}
else{
    redirect('admin/properties');
}
 ?>
  