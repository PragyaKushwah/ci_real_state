<?php if($this->session->has_userdata('session_property_id')){ 
        $sessionid = $this->session->userdata('session_property_id');
?>
<!-- [ breadcrumb ] start -->
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="feather icon-home bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Create Properties</h5>
                    <span>Create Your Properties Here!</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url();?>admin"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Create Properties</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>
                                           
<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card latest-update-card">
                            <div class="card-header">
                                <h5>Create Property!</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-block">
                                    <?php
                                        if(isset($_SESSION['errors'])){
                                                echo "<div class='alert alert-danger'>".$_SESSION['errors']."<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                        }
                                    ?>
                                    <?php
                                    //   ------------------if jumping page call----------------
                                        if(isset($selected_property)){
                                            foreach($selected_property as $sproperty){?>
                                                <?php $attributes = array('id'=>'create_property', 'class'=>'form_horizontal'); ?>
                    
                                                    <?= form_open('create_update_property_admin/create_property_step2', $attributes); ?>
                                                    
                                                    <div class="container">
                                                        <div class="col-md-12">
                                                            
                                                            <div class="row ">
                                                                <?php
                                                                    $prop_info = array(
                                                                        'user_type' => $sproperty->user_type,
                                                                        'property_category' => $sproperty->property_category,
                                                                        'property_purpose' => $sproperty->property_purpose,
                                                                        'location' => $sproperty->location
                                                                        );
                                                                ?>
                                                                <a href="<?=base_url();?>create_update_property_admin/create_property/<?= $sessionid; ?>">
                                                                    <?php if(!empty($prop_info['user_type'] && $prop_info['property_category'] && $prop_info['property_purpose'] && $prop_info['location'])){?>
                                                                        	<div class="num-block">
                                                                                <div class="num green"><h6>1</h6></div>
                                                                                <div class="num-block-content"><p><b  class="greenfont">Add Property</b></p></div>
                                                                            </div>
                                                                        <?php 
                                                                            }
                                                                            elseif(empty($prop_info['user_type'] && $prop_info['property_category'] && $prop_info['property_purpose'] && $prop_info['location'])){
                                                                        ?>
                                                                                <div class="num-block">
                                                                                    <div class="num red">
                                                                                        <h6>1</h6>
                                                                                    </div>
                                                                                    <div class="num-block-content">
                                                                                        <p><b class="redfont">Add Property</b></p>
                                                                                    </div>
                                                                                </div>
                                                                        <?php
                                                                            }
                                                                            else{
                                                                        ?>        
                                                                                <div class="num-block">
                                                                                    <div class="num orange">
                                                                                        <h6>1</h6>
                                                                                    </div>
                                                                                    <div class="num-block-content">
                                                                                        <p><b class="redfont">Add Property</b></p>
                                                                                    </div>
                                                                                </div>
                                                                        <?php }
                                                                    ?>
                                                                </a>
                                                               
                                                                <div class="num-block active">
                                                                    <div class="num"><h6>2</h6></div>
                                                                    <div class="num-block-content"><p><b>Add Locality</b></p></div>
                                                                </div>
                                                                <a href="<?=base_url();?>create_update_property_admin/create_property_step2">
                                                                <?php
                                                                    $property_status = $sproperty->property_status;
                                                                    $min_price = $sproperty->min_price;
                                                                    $description = $sproperty->description;
                                                                    $furnish_status = $sproperty->furnish_status;
                                                                    $size = $sproperty->size;
                                                                    $hall = $sproperty->hall;
                                                                    $bedrooms = $sproperty->bedrooms;
                                                                    $facing_direction = $sproperty->facing_direction;
                                                                    if(!empty($property_status && $min_price && $description && $furnish_status && $size && $hall && $bedrooms && $facing_direction)){?>
                                                                        	<div class="num-block">
                                                                                <div class="num green"><h6>3</h6></div>
                                                                                <div class="num-block-content"><p><b  class="greenfont">Property Details</b></p></div>
                                                                            </div>
                                                                        <?php }else{?>
                                                                        	<div class="num-block">
                                                                                <div class="num red"><h6>3</h6></div>
                                                                                <div class="num-block-content"><p><b class="redfont">Property Details</b></p></div>
                                                                            </div>
                                                                        <?php }
                                                                    ?>
                                                                </a> 
                                                                <a href="<?=base_url();?>create_update_property_admin/create_property_step3">
                                                                    <div class="num-block">
                                                                        <div class="num"><h6>4</h6></div>
                                                                        <div class="num-block-content"><p><b>Add  Picture</b></p></div>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                            
                                                        </div>
                                    
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="row full-width">
                                                        			<div class="col-sm-12">
                                                					    <div class="row">
                                                					        <div class="col-md-6">
                                                					            <?php if(!empty($areas)){ ?>
                                                    					            <?= form_label('Select Areas'); ?>
                                                                                    <?php
                                                                                        // Default Option
                                                                                        
                                                                                        foreach($areas as $area){
                                                                                            $options[$area->id] = $area->name;
                                                                                        }
                                                                                        
                                                                                        $attributes_dropdown = array(
                                                                                                                    'class'=>'col-md-12 form-control'                                           
                                                                                                                );
                                                                                        echo form_dropdown('area', $options,'$sproperty->area',$attributes_dropdown); 
                                                                                    ?>
                                                                                <?php }else{?>
                                                                                        <p>No area available </p>
                                                                                <?php }?>
                                                                            
                                                                            
                                                                                <?php
                                                                                    if(empty($sproperty->area)):
                                                                                        echo "<div class='alert alert-warning'>Please select the area or if not available please contact to admin to add your property area!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                    endif;
                                                                                ?>
                                                                                
                                                    
                                                					        </div>
                                                					        <div class="col-md-6">
                                                					            <?= form_label('Property Name *'); ?>
                                                					            <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'placeholder' => 'Enter Property Name',
                                                                                        'name' => 'name',
                                                                                        'value' => $sproperty->name,
                                                                                        'type' => 'text'
                                                                                    );
                                                        
                                                                                    echo form_input($data); 
                                                                                ?>
                                                                                
                                                                                <?php 
                                                                                    if(empty($sproperty->name)):
                                                                                        echo "<div class='alert alert-warning'>Please fill the property name!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                    endif; 
                                                                                ?>
                                                                                
                                                					        </div>
                                                					    </div>
                                                        			</div>
                                                        		</div>
                                                        		
                                                        		<div class="row full-width">
                                                        			<div class="col-sm-12">
                                                					    <div class="row">
                                                					        <div class="col-md-12">
                                                					            <?= form_label('Property Address *'); ?>
                                                					            <?php
                                                                                    $data = array(
                                                                                        'class' => 'form-control',
                                                                                        'name' => 'address',
                                                                                        'rows' => '2',
                                                                                        'value' => $sproperty->address,
                                                                                        'placeholder' => 'Enter Address'
                                                                                    );
                                                        
                                                                                    echo form_textarea($data); 
                                                                                ?>
                                                                                <?php 
                                                    					            if(empty($sproperty->address)):
                                                                                        echo "<div class='alert alert-warning'>Please fill the property address!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                    endif; 
                                                    					        ?>
                                                					        </div>
                                                					    </div>
                                                        			</div>
                                                        		</div>
                                                        		
                                                        		<div class="row full-width">
                                                        			<div class="col-sm-12">
                                                					    <div class="row">
                                                					        <div class="col-md-12">
                                                					           
                                                    					            <?= form_label('Select Builder'); ?>
                                                                                    <?php
                                                                                        // Default Option
                                                                                        $optionsBuilder[-1] = 'Search Builder Here';
                                                                                        foreach($builders as $builder){
                                                                                                        if($builder->tags == ''){
                                                                                                        $options = $builder->name;
                                                                                                        }
                                                                                                        else{
                                                                                                            $options = $builder->name.' - '.$builder->tags;
                                                                                                        }
                                                                                                        $optionsBuilder[$builder->id] = $options;
                                                                                        }
                                                            
                                                                                        $js = array(
                                                                                                'class' => 'form-control select-js'
                                                                                        );
                                                            
                                                                                        echo form_dropdown('builder', $optionsBuilder, $sproperty->builder,$js);
                                                                                     
                                                                                    ?>
                                                    					            <?php 
                                                        					            if(empty($sproperty->builder)):
                                                                                            echo "<div class='alert alert-warning'>Please select the builder!<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
                                                                                        endif; 
                                                        					        ?>
                                                					        </div>
                                                					        
                                                					    </div>
                                                        			</div>
                                                        		</div>
                                                        		<input type="text" name="property_id" value="<?= $property_id;?>" hidden>
                                                        	    <input type="text" name="repository_id" value="<?= $repo_id;?>" hidden>
                                                        		<a class="btn btn-primary" href="<?=base_url();?>create_update_property_admin/create_property/<?= $sessionid; ?>">Back</a>
                                                        		<?php
                                                            		$data = array(
                                                            		        'type'          => 'submit',
                                                                            'name'          => 'submit_next',
                                                                            'value'         => 'true',
                                                                            'content'       => 'Next',
                                                                            'class'         => 'btn btn-primary nextbtn'
                                                                    );
                                                                  
                                                                    echo form_button($data, $js);
                                                                ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?= form_close(); ?>
                                                    
                                            <?php        
                                            }
                                        }
                                        else{?>
                                             <!--//   ------------------if come step by step in page---------------- -->
                                             <?php $attributes = array('id'=>'create_property', 'class'=>'form_horizontal'); ?>
                    
                                                <?= form_open('create_update_property_admin/create_property_step2', $attributes); ?>
                                                
                                                <div class="container">
                                                    <div class="col-md-12">
                                                        <div class="row">
                                                            <a href="<?=base_url();?>create_update_property_admin/create_property/<?= $sessionid; ?>">
                                                                <?php
                                                                if(!empty($user_type && $property_category && $property_purpose && $location)){?>
                                                                    	<div class="num-block">
                                                                            <div class="num green"><h6>1</h6></div>
                                                                            <div class="num-block-content"><p><b  class="greenfont">Add Property</b></p></div>
                                                                        </div>
                                                                    <?php }else{?>
                                                                    	<div class="num-block">
                                                                            <div class="num red"><h6>1</h6></div>
                                                                            <div class="num-block-content"><p><b class="redfont">Add Property</b></p></div>
                                                                        </div>
                                                                    <?php }
                                                                ?>
                                                            </a>
                                                            <div class="num-block active">
                                                                <div class="num"><h6>2</h6></div>
                                                                <div class="num-block-content"><p><b>Add Locality</b></p></div>
                                                            </div>
                                                       
                                                            <div class="num-block">
                                                                <div class="num"><h6>3</h6></div>
                                                                <div class="num-block-content"><p><b>Property Details</b></p></div>
                                                            </div>
                                                            
                                                            <div class="num-block">
                                                                <div class="num"><h6>4</h6></div>
                                                                <div class="num-block-content"><p><b>Add  Picture</b></p></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="row full-width">
                                                    			<div class="col-sm-12">
                                            					    <div class="row">
                                            					        <div class="col-md-6">
                                            					            <?php if(!empty($areas)){ ?>
                                                					            <?= form_label('Select Areas'); ?>
                                                                                <?php
                                                                                    // Default Option
                                                                                    
                                                                                    foreach($areas as $area){
                                                                                        $options[$area->id] = $area->name;
                                                                                    }
                                                                                    
                                                                                    $attributes_dropdown = array(
                                                                                                                'class'=>'col-md-12 form-control'                                           
                                                                                                            );
                                                                                    echo form_dropdown('area', $options,'',$attributes_dropdown); 
                                                                                ?>
                                                                            <?php }else{?>
                                                                                    <p>No area available </p>
                                                                            <?php }?>
                                                                            
                                            					        </div>
                                            					        <div class="col-md-6">
                                            					            <?php if(($this->session->flashdata('flashdata_create_property_step1') != '')){
                                                                                $flashdata_create_property_step1 = $this->session->flashdata('flashdata_create_property_step1'); ?>
                                                                                    <?= form_label('Property Name *'); ?>
                                                                                    <?php
                                                                                        $data = array(
                                                                                            'class' => 'form-control',
                                                                                            'placeholder' => 'Enter Property Name',
                                                                                            'name' => 'name',
                                                                                            'type' => 'text',
                                                                                            'value' => $flashdata_create_property_step1['name']
                                                                                        );
                                                            
                                                                                        echo form_input($data); 
                                                                                    ?>
                                                                            <?php }else{ ?> 
                                                                                        <?= form_label('Property Name *'); ?>
                                                                                        <?php
                                                                                            $data = array(
                                                                                                'class' => 'form-control',
                                                                                                'placeholder' => 'Enter Property Name',
                                                                                                'name' => 'name',
                                                                                                'type' => 'text'
                                                                                            );
                                                                
                                                                                            echo form_input($data); 
                                                                                        ?>
                                                                            <?php } ?>
                                            					        </div>
                                            					    </div>
                                                    			</div>
                                                    		</div>
                                                    		
                                                    		<div class="row full-width">
                                                    			<div class="col-sm-12">
                                            					    <div class="row">
                                            					        <div class="col-md-12">
                                            					             <?php if(($this->session->flashdata('flashdata_create_property_step1') != '')){
                                                                                $flashdata_create_property_step1 = $this->session->flashdata('flashdata_create_property_step1'); ?>
                                                                                        <?= form_label('Property Address *'); ?>
                                                                                        <?php
                                                                                            $data = array(
                                                                                                'class' => 'form-control',
                                                                                                'name' => 'address',
                                                                                                'rows' => '2',
                                                                                                'value' => $flashdata_create_property_step1['address'],
                                                                                                'placeholder' => 'Enter Address'
                                                                                            );
                                                                
                                                                                            echo form_textarea($data); 
                                                                                        ?>
                                                                            <?php }else{ ?> 
                                                                                        <?= form_label('Property Address *'); ?>
                                                                                        <?php
                                                                                            $data = array(
                                                                                                'class' => 'form-control',
                                                                                                'name' => 'address',
                                                                                                'rows' => '2',
                                                                                                'placeholder' => 'Enter Address'
                                                                                            );
                                                                
                                                                                            echo form_textarea($data); 
                                                                                        ?>
                                                                            <?php } ?>
                                            					            
                                            					        </div>
                                            					        
                                            					    </div>
                                                    			</div>
                                                    		</div>
                                                    		
                                                    		<div class="row full-width">
                                                    			<div class="col-sm-12">
                                            					    <div class="row">
                                            					        <div class="col-md-12">
                                            					            <?= form_label('Select Builder'); ?>
                                                                            <?php
                                                                                // Default Option
                                                                                $optionsBuilder[-1] = 'Search Builder Here';
                                                                                foreach($builders as $builder){
                                                                                                if($builder->tags == ''){
                                                                                                $options = $builder->name;
                                                                                                }
                                                                                                else{
                                                                                                    $options = $builder->name.' - '.$builder->tags;
                                                                                                }
                                                                                                $optionsBuilder[$builder->id] = $options;
                                                                                }
                                                    
                                                                                $js = array(
                                                                                        'class' => 'form-control select-js'
                                                                                );
                                                    
                                                                                echo form_dropdown('builder', $optionsBuilder, '-1',$js);
                                                                            ?>
                                            					        </div>
                                            					        
                                            					    </div>
                                                    			</div>
                                                    		</div>
                                                    		<input type="text" name="property_id" value="<?= $property_id;?>" hidden>
                                                            <input type="text" name="repository_id" value="<?= $repo_id;?>" hidden>
                                                    		<a class="btn btn-primary" href="<?=base_url();?>create_update_property_admin/create_property/<?= $sessionid; ?>">Back</a>
                                                    		<?php
                                                        		$data = array(
                                                        		        'type'          => 'submit',
                                                                        'name'          => 'submit_next',
                                                                        'value'         => 'true',
                                                                        'content'       => 'Next',
                                                                        'class'         => 'btn btn-primary nextbtn'
                                                                );
                                                                
                                                                echo form_button($data);
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?= form_close(); ?>
                                             
                                        <?php } ?>
                        
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
}
else{
    redirect('admin/properties');
}
 ?>