<!-- [ breadcrumb ] start -->
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="feather icon-home bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Properties</h5>
                    <span>Manage Your Properties Locations Here!</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url();?>admin"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Manage Properties Location</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>
                                           
<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card latest-update-card">
                            <div class="card-header">
                                <h5>Create A New Location!</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-block">
                                <?php
                                    if($this->session->flashdata('error')){
                                        echo '<div class="alert alert-danger border-danger">
                                                    <button type="button" class="close"
                                                        data-dismiss="alert" aria-label="Close">
                                                        <i class="icofont icofont-close-line-circled"></i>
                                                    </button>'.
                                                  $this->session->flashdata("error")  
                                                .'</div>';
                                    }else if($this->session->flashdata('success')){
                                        echo '<div class="alert alert-success border-success">
                                                    <button type="button" class="close"
                                                        data-dismiss="alert" aria-label="Close">
                                                        <i class="icofont icofont-close-line-circled"></i>
                                                    </button>'.
                                                  $this->session->flashdata("success")  
                                                .'</div>';
                                    }
                                ?>
                                <?php $attributes = array('id'=>'create_users', 'class'=>'form_horizontal'); ?>
                                
                                <?= form_open('admin/insert_location', $attributes); ?>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <!-- Username -->
                                        <?= form_label('State / City / Areas'); ?>
                                        <?php
                                            $data = array(
                                                'class' => 'form-control',
                                                'placeholder' => 'Enter Location Name',
                                                'name' => 'name',
                                                'type' => 'text',
                                                'required' => true
                                            );
                
                                            echo form_input($data); 
                                        ?>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <!-- PARENT LOCATION -->
                                    <?php
                                        echo form_label('Select Parent Location!'); 
                                        $options['0'] = 'Select Parent Location';
                                    ?>
                                    <?php
                                        foreach($results as $state){
                                            if($state->parent == 0){
                                                $options[$state->id] = $state->name;
                                                foreach($results as $city){
                                                    if($city->parent == $state->id){
                                                        //$options[$state->name][$city->id] = $city->name;
                                                        $options[$city->id] = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$city->name;
                                                    }
                                                }
                                            }
                                        }
                                        $js = array(
                                                'class' => 'form-control select-js'
                                        );
                                        echo form_dropdown('parent', $options, '0',$js);
                                    ?>
                                    </div>
                                </div>
                                <?php
                                    $data = array(
                                        'value' => 'Submit',
                                        'name' => 'submit_create_users',
                                        'type' => 'submit',
                                        'class' => 'btn waves-effect waves-light btn-grd-primary'
                                    );
                
                                    echo form_input($data); 
                                ?>
                                <?= form_close(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card latest-update-card">
                            <div class="card-header">
                                <h5>Locations!</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-block">
                            <?php
                                if(!empty($results)){
                                echo '<ul class="location-list">';
                                foreach($results as $state){
                                    if($state->parent == 0){
                            ?>            
                                        <li class="location cat"><?=$state->name;?><span class="btn-oc locations <?php if($state->featured == 0){echo 'no';} else{echo 'yes';} ?>" id="prod<?=$state->id;?>" onclick="pushme(<?=$state->id;?>,<?=$state->featured;?>)"><?php if($state->featured == 0){echo 'no';} else{echo 'yes';} ?></span></li>
                            <?php
                                        echo '<ul>';
                                        foreach($results as $city){
                                            if($city->parent == $state->id){
                            ?>
                                                <li class="location sub-cat"><?=$city->name;?><span class="btn-oc locations <?php if($city->featured == 0){echo 'no';} else{echo 'yes';} ?>" id="prod<?=$city->id;?>" onclick="pushme(<?=$city->id;?>,<?=$city->featured;?>)"><?php if($city->featured == 0){echo 'no';} else{echo 'yes';} ?></span></li>
                            <?php 
                                                echo '<ul>';
                                                foreach($results as $area){
                                                    if($area->parent == $city->id){
                            ?>
                                                        <li class="location sub-cat inner"><?=$area->name;?><span class="btn-oc locations <?php if($area->featured == 0){echo 'no';} else{echo 'yes';} ?>" id="prod<?=$area->id;?>" onclick="pushme(<?=$area->id;?>,<?=$area->featured;?>)"><?php if($area->featured == 0){echo 'no';} else{echo 'yes';} ?></span></li>    
                            <?php
                                                    }
                                                }
                                                // ^ end area loop
                                                echo '</ul>';
                                            }
                                        }
                                        // ^ end city loop
                                        echo '</ul>';
                                    }
                                }
                                // ^ end state loop
                                echo '</ul>';
                                }else{
                                    echo '<div class="alert alert-success border-primary">
                                                <button type="button" class="close"
                                                    data-dismiss="alert" aria-label="Close">
                                                    <i class="icofont icofont-close-line-circled"></i>
                                                </button>
                                                No Location Created Yet! Go Ahead And Creat Your First Location.    
                                            </div>';
                                }
                            ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
