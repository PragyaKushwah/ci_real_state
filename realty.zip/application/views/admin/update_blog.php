

<!--Layout Starts Here-->
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="feather icon-watch bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Edit Blog</h5>
                    <span>Edit Blog</span> 
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item"> <a href="<?=base_url();?>Admin/dashboard"><i class="feather icon-home"></i></a> </li>
                    <li class="breadcrumb-item"> <a href="#">Edit Blog</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>Edit Blog Details</h5>
                                <div class="card-header-right">
                                    <ul class="list-unstyled card-option">
                                        <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                        <li><i class="feather icon-maximize full-card"></i></li>
                                        <li><i class="feather icon-minus minimize-card"></i></li>
                                        <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                        <li><i class="feather icon-trash close-card"></i></li>
                                        <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-block">
                                <form method="POST" action="<?php echo base_url("/Admin/update_blog");?>" enctype="multipart/form-data"  >
                                <div class="form-group">
                                    <?php foreach($blog_details as $blog_detail){ ?>
                                    <input type="hidden"  name="id" value="<?php echo $blog_detail->blog_id ;?>">
                                   
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label"  for="meta_title"><b>Blog_Title</b></label>
                                        <div class="col-sm-10">
                                             <input type="text" name="blog_title" class="form-control" value="<?php echo $blog_detail->blog_title ;?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label"  for="meta_title"><b>Blog_Intro</b></label>
                                        <div class="col-sm-10">
                                             <input type="text" name="blog_intro" class="form-control" value="<?php echo $blog_detail->blog_intro ;?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label"  for="blog_desc"><b>Blog_Description</b></label>
                                        <div class="col-sm-10">
                                            <textarea name="blog_description" class="form-control"   ><?php echo $blog_detail->blog_description ;?></textarea>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row">
                                            <label class="col-sm-2 col-form-label" for="blog_image"><b>Blog_Image</b></label>
                                    <div class="col-sm-10">
                                    <input type="file"  class="form-control" name="document" value="<?php echo $blog_detail->blog_image ;?>" >
                                    <p><img src='<?=base_url('/assets/uploads/blogs/').$blog_detail->blog_image ?>' style="height:100px;width:100px"/></p>
                                    </div>
                                	</div>
	
                                    
                                    
                                    
                                    
                                    <input type="submit" name="update" class="signupbtn btn btn-primary m-b-0 " value="Update">
                                    <?php } ;?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Layout Ends Here-->

