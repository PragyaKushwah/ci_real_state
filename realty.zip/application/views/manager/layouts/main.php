<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title><?php if(isset($title)){ echo $title; } ?></title>

<!--[if lt IE 10]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="" />
<meta name="keywords" content="">
<meta name="author" content="OnlineChalo" />

    <!------------------------------------------------------------------->
    <!------------------------LOADS HEADER SCRIPTS----------------------->
    <!------------------------------------------------------------------->
    <?php $this->load->view('manager/layouts/header_scripts'); ?>
    
</head>
<body>
    
<?php
    if(isset($disable_loader)){

    }
    else{
?>    
        <div class="loader-bg">
        <div class="loader-bar"></div>
        </div>
<?php
    }
?>

<div id="pcoded" class="pcoded">
<div class="pcoded-overlay-box"></div>
<div class="pcoded-container navbar-wrapper">

<nav class="navbar header-navbar pcoded-header">
	<div class="navbar-wrapper">
	<div class="navbar-logo">
	<a href="index.html">
	<img class="img-fluid" src="<?=base_url();?>assets/admin/png/logo.png" alt="Theme-Logo" />
	</a>
	<a class="mobile-menu" id="mobile-collapse" href="#!">
	<i class="feather icon-menu icon-toggle-right"></i>
	</a>
	<a class="mobile-options waves-effect waves-light">
	<i class="feather icon-more-horizontal"></i>
	</a>
	</div>
	<div class="navbar-container container-fluid">
	<ul class="nav-left">
	<li class="header-search">
	<div class="main-search morphsearch-search">
	<div class="input-group">
	<span class="input-group-prepend search-close">
	<i class="feather icon-x input-group-text"></i>
	</span>
	<input type="text" class="form-control" placeholder="Enter Keyword">
	<span class="input-group-append search-btn">
	<i class="feather icon-search input-group-text"></i>
	</span>
	</div>
	</div>
	</li>
    <li>
    <a href="#!" onclick="if (!window.__cfRLUnblockHandlers) return false; javascript:toggleFullScreen()" class="waves-effect waves-light" data-cf-modified-d8424a08d31b5b8b406fded2-="">
    <i class="full-screen feather icon-maximize"></i>
    </a>
    </li>
    </ul>
    <ul class="nav-right">
    <li class="header-notification">
    <div class="dropdown-primary dropdown">
    <div class="dropdown-toggle" data-toggle="dropdown">
    <i class="feather icon-bell"></i>
    <span class="badge bg-c-red">5</span>
    </div>
    <ul class="show-notification notification-view dropdown-menu" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
    <li>
    <h6>Notifications</h6>
    <label class="label label-danger">New</label>
    </li>
    <li>
    <div class="media">
    <img class="img-radius" src="<?=base_url();?>assets/admin/jpg/avatar-4.jpg" alt="Generic placeholder image">
    <div class="media-body">
    <h5 class="notification-user">John Doe</h5>
    <p class="notification-msg">Lorem ipsum dolor sit amet, consectetuer elit.</p>
    <span class="notification-time">30 minutes ago</span>
    </div>
    </div>
    </li>
    <li>
    <div class="media">
    <img class="img-radius" src="<?=base_url();?>assets/admin/jpg/avatar-3.jpg" alt="Generic placeholder image">
    <div class="media-body">
    <h5 class="notification-user">Joseph William</h5>
    <p class="notification-msg">Lorem ipsum dolor sit amet, consectetuer elit.</p>
    <span class="notification-time">30 minutes ago</span>
    </div>
    </div>
    </li>
    <li>
    <div class="media">
    <img class="img-radius" src="<?=base_url();?>assets/admin/jpg/avatar-4.jpg" alt="Generic placeholder image">
    <div class="media-body">
    <h5 class="notification-user">Sara Soudein</h5>
    <p class="notification-msg">Lorem ipsum dolor sit amet, consectetuer elit.</p>
    <span class="notification-time">30 minutes ago</span>
    </div>
    </div>
    </li>
    </ul>
    </div>
    </li>
    <li class="header-notification">
    <div class="dropdown-primary dropdown">
    <div class="displayChatbox dropdown-toggle" data-toggle="dropdown">
    <i class="feather icon-message-square"></i>
    <span class="badge bg-c-green">3</span>
    </div>
    </div>
    </li>
    <li class="user-profile header-notification">
    <div class="dropdown-primary dropdown">
    <div class="dropdown-toggle" data-toggle="dropdown">
    <img src="<?=base_url();?>assets/admin/jpg/avatar-4.jpg" class="img-radius" alt="User-Profile-Image">
    <span>John Doe</span>
    <i class="feather icon-chevron-down"></i>
    </div>
    <ul class="show-notification profile-notification dropdown-menu" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
    <li>
    <a href="#!">
    <i class="feather icon-settings"></i> Settings
    </a>
    </li>
    <li>
    <a href="#">
    <i class="feather icon-user"></i> Profile
    </a>
    </li>
    <li>
    <a href="email-inbox.html">
    <i class="feather icon-mail"></i> My Messages
    </a>
    </li>
    <li>
    <a href="auth-lock-screen.html">
    <i class="feather icon-lock"></i> Lock Screen
    </a>
    </li>
    <li>
    <a href="auth-sign-in-social.html">
    <i class="feather icon-log-out"></i> Logout
    </a>
    </li>
    </ul>
    </div>
    </li>
    </ul>
    </div>
    </div>
</nav>

<div class="pcoded-main-container">
<div class="pcoded-wrapper">

<nav class="pcoded-navbar">
    <div class="nav-list">
        <div class="pcoded-inner-navbar main-menu">
            <div class="pcoded-navigation-label">Navigation</div>
                <ul class="pcoded-item pcoded-left-item">
                    
                    <!------------------------------------------------------------------->
                    <!------------------------LOADS MENU CONTENT------------------------->
                    <!------------------------------------------------------------------->
                    <?php $this->load->view('manager/layouts/menu'); ?>
                    
                </ul>
            </div>
    </div>
</nav>

<div class="pcoded-content">
    
    
    <!------------------------------------------------------------------->
    <!------------------------LOADS PAGE CONTENT------------------------->
    <!------------------------------------------------------------------->
    <?php $this->load->view($view); ?>
    
    
</div>

<div id="styleSelector">
</div>

</div>
</div>
</div>
</div>


<!--[if lt IE 10]>
    <div class="ie-warning">
        <h1>Warning!!</h1>
        <p>You are using an outdated version of Internet Explorer, please upgrade
            <br/>to any of the following web browsers to access this website.
        </p>
        <div class="iew-container">
            <ul class="iew-download">
                <li>
                    <a href="http://www.google.com/chrome/">
                        <img src="../files/assets/images/browser/chrome.png" alt="Chrome">
                        <div>Chrome</div>
                    </a>
                </li>
                <li>
                    <a href="https://www.mozilla.org/en-US/firefox/new/">
                        <img src="../files/assets/images/browser/firefox.png" alt="Firefox">
                        <div>Firefox</div>
                    </a>
                </li>
                <li>
                    <a href="http://www.opera.com">
                        <img src="../files/assets/images/browser/opera.png" alt="Opera">
                        <div>Opera</div>
                    </a>
                </li>
                <li>
                    <a href="https://www.apple.com/safari/">
                        <img src="../files/assets/images/browser/safari.png" alt="Safari">
                        <div>Safari</div>
                    </a>
                </li>
                <li>
                    <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie">
                        <img src="../files/assets/images/browser/ie.png" alt="">
                        <div>IE (9 & above)</div>
                    </a>
                </li>
            </ul>
        </div>
        <p>Sorry for the inconvenience!</p>
    </div>
    <![endif]-->
    
    
    <!------------------------------------------------------------------->
    <!----------------------LOADS FOOTER SCRIPTS------------------------->
    <!------------------------------------------------------------------->
    <?php $this->load->view('manager/layouts/footer_scripts'); ?>


</body>

</html>
