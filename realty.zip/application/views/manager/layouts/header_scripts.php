<?php
 if(isset($page) && ($page=='dashboard')){
?>  
    
        
    
    <link rel="icon" href="https://colorlib.com/polygon/admindek/files/assets/images/favicon.ico" type="image/x-icon">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet"><link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
    
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/admin/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="<?=base_url();?>assets/admin/css/waves.min.css" type="text/css" media="all">
    
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/admin/css/feather.css">
    
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/admin/css/style.css">
<?php
 }
?>


<?php
  if(isset($page) && ($page=='page')){
?>
    
    
    <link rel="icon" href="https://colorlib.com/polygon/admindek/files/assets/images/favicon.ico" type="image/x-icon">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet"><link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
    
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/admin/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="<?=base_url();?>assets/admin/css/waves.min.css" type="text/css" media="all">
    
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/admin/css/feather.css">
    
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/admin/css/style.css">

<?php
  }
?>