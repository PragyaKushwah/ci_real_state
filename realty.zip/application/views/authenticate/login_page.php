<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
        <title>
            <?php if(isset($page_details['page_title'])){echo $page_details['page_title'];} ?>
        </title>
        <!--[if lt IE 10]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="description" content="Admindek Bootstrap admin template made using Bootstrap 4 and it has huge amount of ready made feature, UI components, pages which completely fulfills any dashboard needs." />
        <meta name="keywords" content="bootstrap, bootstrap admin template, admin theme, admin dashboard, dashboard template, admin template, responsive" />
        <meta name="author" content="colorlib" />
        <link rel="icon" href="https://colorlib.com/polygon/admindek/files/assets/images/favicon.ico" type="image/x-icon">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/admin/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?=base_url();?>assets/admin/css/waves.min.css" type="text/css" media="all">
        <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/admin/css/feather.css">
        <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/admin/css/themify-icons.css">
        <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/admin/css/icofont.css">
        <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/admin/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/admin/css/style.css">
        <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/admin/css/pages.css">
    </head>
    <body themebg-pattern="theme1">
        <div class="theme-loader">
            <div class="loader-track">
                <div class="preloader-wrapper">
                    <div class="spinner-layer spinner-blue">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div>
                        <div class="gap-patch">
                            <div class="circle"></div>
                        </div>
                        <div class="circle-clipper right">
                            <div class="circle"></div>
                        </div>
                    </div>
                    <div class="spinner-layer spinner-red">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div>
                        <div class="gap-patch">
                            <div class="circle"></div>
                        </div>
                        <div class="circle-clipper right">
                            <div class="circle"></div>
                        </div>
                    </div>
                    <div class="spinner-layer spinner-yellow">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div>
                        <div class="gap-patch">
                            <div class="circle"></div>
                        </div>
                        <div class="circle-clipper right">
                            <div class="circle"></div>
                        </div>
                    </div>
                    <div class="spinner-layer spinner-green">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div>
                        <div class="gap-patch">
                            <div class="circle"></div>
                        </div>
                        <div class="circle-clipper right">
                            <div class="circle"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <section class="login-block">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        <?php 
                            $attributes = array( 'id'=>'loginform', 'method' =>'post', 'class' => 'md-float-material form-material'); 
                            echo form_open('Authenticate/auth', $attributes); 
                        ?>
                        <!--<form class="md-float-material form-material" action="Authenticate/login" method="post">-->
                        <!--<div class="text-center">-->
                        <!--<img src="png/logo.png" alt="logo.png">-->
                        <!--</div>-->
                        <div class="auth-box card">
                            <div class="card-block">
                                <div class="row m-b-20">
                                    <div class="col-md-12">
                                        <h3 class="text-center txt-primary">Sign In</h3>
                                    </div>
                                </div>
                                <p class="text-muted text-center p-b-5">Sign in to activate your account</p>
                                <?php
                                    if($this->session->flashdata('error')){
                                        echo '<div class="alert alert-danger border-danger">
                                                    <button type="button" class="close"
                                                        data-dismiss="alert" aria-label="Close">
                                                        <i class="icofont icofont-close-line-circled"></i>
                                                    </button>'.
                                                  $this->session->flashdata("error")  
                                                .'</div>';
                                    }else if($this->session->flashdata('success')){
                                        echo '<div class="alert alert-success border-success">
                                                    <button type="button" class="close"
                                                        data-dismiss="alert" aria-label="Close">
                                                        <i class="icofont icofont-close-line-circled"></i>
                                                    </button>'.
                                                  $this->session->flashdata("success")  
                                                .'</div>';
                                    }
                                ?>
                                <div class="form-group form-primary">
                                    <input type="email" name="email" class="form-control" required> <span class="form-bar"></span>
                                    <label class="float-label">Email</label>
                                </div>
                                <div class="form-group form-primary">
                                    <input type="password" name="password" class="form-control" required> <span class="form-bar"></span>
                                    <label class="float-label">Password</label>
                                </div>
                                <div class="row m-t-25 text-left">
                                    <div class="col-12">
                                        <!--<div class="checkbox-fade fade-in-primary">-->
                                        <!--    <label>-->
                                        <!--    <input type="checkbox" value="">-->
                                        <!--    <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>-->
                                        <!--    <span class="text-inverse">Remember me</span>-->
                                        <!--    </label>-->
                                        <!--</div>-->
                                        <!--<div class="forgot-phone text-right float-right">-->
                                        <!--<a href="auth-reset-password.html" class="text-right f-w-600"> Forgot Password?</a>-->
                                        <!--</div>-->
                                    </div>
                                </div>
                                <div class="row m-t-30">
                                    <div class="col-md-12">
                                        <input type="submit" name="login_btn" value="Submit" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">
                                    </div>
                                </div>
                                <!--<p class="text-inverse txt-left">Don't have an account?<a href="auth-sign-up-social.html"> <b>Register here </b></a>for free!</p>-->
                            </div>
                        </div>
                        <!--</form>-->
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
            </div>
        </section>
        <script src="<?=base_url();?>/assets/admin/js/jquery.min.js"></script>
        <script src="<?=base_url();?>/assets/admin/js/jquery-ui.min.js"></script>
        <script  src="<?=base_url();?>/assets/admin/js/popper.min.js"></script>
        <script src="<?=base_url();?>/assets/admin/js/bootstrap.min.js"></script>
        <script src="<?=base_url();?>/assets/admin/js/waves.min.js"></script>
        <script src="<?=base_url();?>/assets/admin/js/jquery.slimscroll.js"></script>
        <script src="<?=base_url();?>/assets/admin/js/modernizr.js"></script>
        <script src="<?=base_url();?>/assets/admin/js/css-scrollbars.js"></script>
        <script src="<?=base_url();?>/assets/admin/js/common-pages.js"></script>
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
            
              gtag('config', 'UA-23581568-13');
        </script>
        <script src="<?=base_url();?>/assets/admin/js/rocket-loader.min.js" data-cf-settings="4878d7dfa7bc22a8dfa99416-|49" defer=""></script>
    </body>
</html>

