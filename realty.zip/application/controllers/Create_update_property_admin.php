<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Create_update_property_admin extends CI_Controller {

	public function index()
	{	
	    if(isset($_SESSION['pk_logged_in'])){
	        if($_SESSION['pk_logged_in']){
	            $url = base_url().'create_update_property_admin/create_property';
                redirect($url);
	        }
	    }else{
	        redirect('authenticate');
	    }
	}

	
	/***************************************************************************/
	/***************************************************************************/
	/************************ Create Update Properties **************************/
	/***************************************************************************/
	/***************************************************************************/

	public function create_property(){
	    
	    if($this->session->userdata('pk_logged_in')){
    	    
	    }
	    else{
	        redirect('authenticate');
	    }
	    
	    $session = $this->uri->segment(3);
	    $this->load->model('location_model');
	    $this->load->model('User_model');
		$this->load->model('Property_specifics_model');
		$this->load->model('Property_model');
		$data['property_purposes'] = $this->Property_specifics_model->get_property_purpose();
        $data['property_cats'] = $this->Property_specifics_model->get_property_cat();
		$data['property_types'] = $this->Property_specifics_model->get_property_type();
		$data['property_status'] = $this->Property_specifics_model->get_property_status();
		$data['locations'] = $this->location_model->get_locations();
		$data['agents'] = $this->User_model->get_agents();
		
        if(empty($session)){
    	   
    		$data['view'] = 'admin/create_property';
    		$data['page'] = 'dashboard';
        	$data['title'] = 'Pakiza Properties | Create Property';
    		$this->load->view('admin/layouts/main', $data);
	   }else{
    		
            $data['admin'] = $this->session->userdata('admin_id');
            if(isset($session)){
                
                $pid = $session;
                $data['selected_property'] = $this->Property_model->select_property($pid);
                // $city_id = $this->Property_model->getCity_property($pid);
                // $data['cityname'] = $this->location_model->getCity_name(3);

                $data['property_id'] = $pid;
        		$data['view'] = 'admin/create_property';
        		$data['page'] = 'dashboard';
        	    $data['title'] = 'Pakiza Properties | Create Property';
        		$this->load->view('admin/layouts/main', $data);
            }   
        }
	}
	
	public function create_property_step1(){
	        $this->load->model('location_model');
    		$this->load->model('user_model');
    		$this->load->model('Property_specifics_model');
    		$this->load->model('Builder_model');
    		$this->load->model('Property_model');
    		$this->load->model('media_model');
    	    
    	    
    	    if($this->session->userdata('pk_logged_in')){
    	    
    	    }
    	    else{
    	        redirect('authenticate');
    	    }
    	   
            if(isset($_POST["submit_create_property"])) {  
        	             $this->form_validation->set_rules('user_type', 'user_type', 'required');
        	             $this->form_validation->set_rules('property_type', 'property_type', 'required');
        	             $this->form_validation->set_rules('property_category', 'property_category', 'required');
        	             $this->form_validation->set_rules('property_purpose', 'property_purpose', 'required');
        	             $this->form_validation->set_rules('location', 'location', 'required');
        	              $this->form_validation->set_rules('agent', 'agent', 'required');
        	             if($this->input->post('user_type')=="admin"){
        	                 $this->form_validation->set_rules('rera_id', 'rera_id', 'required');
        	             }
        	             
        	            $data['agent'] = $this->input->post('agent');
                        $data['user_type']= $this->input->post('user_type');
                        $data['property_category'] = $this->input->post('property_category');
                        $data['property_purpose'] = $this->input->post('property_purpose');
                        $data['property_type'] = $this->input->post('property_type');
                        $data['location'] = $this->input->post('location');
                        $data['rera_id'] = $this->input->post('rera_id');
                        $data['status'] = '2';                                      // Status 2 implies property has not been approved by the admin
        			    $data['featured'] = '0';
        			    
        	            if ($this->form_validation->run() == FALSE)
                        {
                          //    ----------------------------------------------------
            			     //   set flash data for resend data in previous page
            			     
            			    $array_data = array('user_type'=> $data['user_type'] ,'rera_id'=> $data['rera_id'],'property_category'=> $data['property_category'] ,'property_purpose'=> $data['property_purpose'], 'property_type'=> $data['property_type'] ,'location'=> $data['location']);
            			    $this->session->set_flashdata('flashdata_create_property', $array_data);
            			  
            			 //-------------------------------------------------------
            			   
                    		$url = base_url().'create_update_property_admin/create_property';
                    		redirect($url);
                        }
                        else
                        {
                            
                            $insert_create_property = $this->Property_model->insert_create_property($data);
                    		if($insert_create_property > 0){
                    		    
                    		    //  session 'session_property_id' created.
                    		    $this->session->set_userdata('session_property_id', $insert_create_property);
                    		    $this->session->set_userdata('session_property_category', $data['property_category']);
                    		    $this->session->set_userdata('session_property_type', $data['property_type']);
                    		    $data['property_id'] = $insert_create_property;
                    		    $repository_data = array(
                                    'type'=> "PROPERTY",
                                    'type_id'=> $insert_create_property,
                        		);
                        		        
                        		$data['repo_id'] = $this->media_model->get_reposotory_id($repository_data);
                        		$this->session->set_userdata('repository_id', $data['repo_id']);
                    	        $city_id = $data['location'];
                                $data['areas'] = $this->location_model->areas_by_city($city_id);
                                $data['builders'] = $this->Builder_model->get_builders();
                        		$data['view'] = 'admin/post_your_property_step2';
                        		$data['page'] = 'dashboard';
        	                    $data['title'] = 'Pakiza Properties | Create Property';
                        		$this->load->view('admin/layouts/main', $data);
                			}
                			else{
                        		$url = base_url().'create_update_property_admin/create_property';
                        		redirect($url);
                			}
                        }
	        }
	        else{
	                $data['admin'] = $this->session->userdata('admin_id');
                    if($this->uri->segment(4)){
            	         $property_id = $this->uri->segment(3);
            	         $admin_id = $this->uri->segment(4);
            	         $property_category = $this->uri->segment(5);
            	         $property_type = $this->uri->segment(6);
            	         if($property_id){
            	             $pid = $property_id;
                             $data['selected_property'] = $this->Property_model->select_property($pid);
                             $this->session->set_userdata('session_property_id', $property_id);
                             $this->session->set_userdata('session_property_category', $property_category);
                             $this->session->set_userdata('session_property_type', $property_type);
                             $repository_data = array(
                                'type'=> "PROPERTY",
                                'type_id'=> $pid,
                    		);    
                    		$data['repo_id'] = $this->media_model->get_reposotory_id($repository_data);
                    		$this->session->set_userdata('repository_id', $data['repo_id']);
                            $city_id = $this->Property_model->getCity_property($pid);
                            $data['property_id'] = $pid;
                            $data['areas'] = $this->location_model->areas_by_city($city_id);
                            $data['builders'] = $this->Builder_model->get_builders();
                    // 		$data['property_page_1'] = TRUE;
                    		$data['view'] = 'admin/post_your_property_step2';
                    		$data['page'] = 'dashboard';
        	                $data['title'] = 'Pakiza Properties | Create Property';
                    		$this->load->view('admin/layouts/main', $data);
            	         }
            	    }else{
            	             
            	            if($this->session->has_userdata('session_property_id')){
            	                if($this->session->has_userdata('session_property_category') && $this->session->has_userdata('session_property_type')){
                                    $pid = $this->session->userdata('session_property_id');
                                    $data['selected_property'] = $this->Property_model->select_property($pid); 
            	                }
            	            }
            	         
                            $repository_data = array(
                                'type'=> "PROPERTY",
                                'type_id'=> $pid,
                    		);    
                    		$data['repo_id'] = $this->media_model->get_reposotory_id($repository_data);
                    		$this->session->set_userdata('repository_id', $data['repo_id']);
                            $city_id = $this->Property_model->getCity_property($pid);
                            $data['property_id'] = $pid;
                            $data['areas'] = $this->location_model->areas_by_city($city_id);
                            $data['builders'] = $this->Builder_model->get_builders();
                    // 		$data['property_page_1'] = TRUE;
                    		$data['view'] = 'admin/post_your_property_step2';
                    		$data['page'] = 'dashboard';
        	                $data['title'] = 'Pakiza Properties | Create Property';
                    		$this->load->view('admin/layouts/main', $data);
                        
            	    }
	         }
	}
	
	public function create_property_step2(){
		    
	    if($this->session->userdata('pk_logged_in')){
	    
	    }
	    else{
	        redirect('authenticate');
	    }
	    $this->load->model('location_model');
		$this->load->model('user_model');
		$this->load->model('Property_specifics_model');
		$this->load->model('Builder_model');
		$this->load->model('Property_model');
          
    	if(isset($_POST["submit_next"])) {  
    	    
    	    $this->form_validation->set_rules('name', 'name', 'required');
    	    $this->form_validation->set_rules('address', 'address', 'required');
    	    
    	    $project_id= $this->input->post('property_id');
            $data['area']= $this->input->post('area');
            $data['name'] = $this->input->post('name');
            $data['address'] = $this->input->post('address');
            $data['builder'] = $this->input->post('builder');
            $data['repository_id'] = $this->input->post('repository_id');
            
            if ($this->form_validation->run() == FALSE)
            {
              //    ----------------------------------------------------
			     //   set flash data for resend data in previous page
			     
			    $array_data = array('name'=> $data['name'], 'address'=> $data['address']);
			    $this->session->set_flashdata('flashdata_create_property_step1', $array_data);
			  
			 //-------------------------------------------------------
			   
        		$url = base_url().'create_update_property_admin/create_property_step1';
        		redirect($url);
            }
            else
            {          
                $update_property_steps = $this->Property_model->update_property_steps($data);
            		if($update_property_steps > 0){
            		    if($this->session->has_userdata('session_property_id')){
            		        //  old page data("post data")
                		    $data['area']= $data['area'];
                            $data['name'] = $data['name'];
                            $data['address'] = $data['address'];
                            $data['builder'] = $data['builder'];
                            
                            // modals or data  use in new view page 
                    		$data['property_status'] = $this->Property_specifics_model->get_property_status();
                            $data['furnish_status'] = $this->Property_specifics_model->get_furnish_status();
                            $data['size_param'] = $this->Property_specifics_model->get_size_param();
                            $data['property_status'] = $this->Property_specifics_model->get_property_status();
                            $data['amenities'] = $this->Property_specifics_model->get_amenities();
                            $data['amenitiestwo'] = $this->Property_specifics_model->get_amenitiestwo();
                            // ------------
                            // if($this->session->has_userdata('session_property_id')){
                            //     $pid = $this->session->userdata('session_property_id');
                            //     $data['selected_property'] = $this->Property_model->select_property($pid);
                            // }
                            // ----------
                		  // 	$data['property_page_1'] = TRUE;
                		    $data['property_id'] = $project_id;
                    		$data['view'] = 'admin/post_your_property_step3';
                    		$data['page'] = 'dashboard';
        	                $data['title'] = 'Pakiza Properties | Create Property';
                    		$this->load->view('admin/layouts/main', $data); 
            		    }
            		}else{
                		$url = base_url().'create_update_property_admin/create_property_step1';
                		redirect($url);
        			}
            }
    	}
	    else{
	        $data['admin'] = $this->session->userdata('admin_id');
            if($this->session->has_userdata('session_property_id')){
                $data['property_status'] = $this->Property_specifics_model->get_property_status();
                $data['furnish_status'] = $this->Property_specifics_model->get_furnish_status();
                $data['size_param'] = $this->Property_specifics_model->get_size_param();
                $data['property_status'] = $this->Property_specifics_model->get_property_status();
                $data['amenities'] = $this->Property_specifics_model->get_amenities();
                $data['amenitiestwo'] = $this->Property_specifics_model->get_amenitiestwo();
             
                $pid = $this->session->userdata('session_property_id');
                $data['selected_property'] = $this->Property_model->select_property($pid);
                // $area['city_id'] = $this->Property_model->getCity_property($pid);
                $data['property_id'] = $pid;
        // 		$data['property_page_1'] = TRUE;
        		$data['view'] = 'admin/post_your_property_step3';
        		$data['page'] = 'dashboard';
        	    $data['title'] = 'Pakiza Properties | Create Property';
        		$this->load->view('admin/layouts/main', $data);
            }
	    }
	}
	
	
	public function create_property_step3(){
	    if($this->session->userdata('pk_logged_in')){
	    
	    }
	    else{
	        redirect('authenticate');
	    }
	    $this->load->model('location_model');
		$this->load->model('user_model');
		$this->load->model('Property_specifics_model');
		$this->load->model('Builder_model');
		$this->load->model('Property_model');
		$this->load->model('media_model');
	    if(isset($_POST["submit_property"])) {  
	        
	        $this->form_validation->set_rules('min_price', 'min_price', 'required');
	        $this->form_validation->set_rules('description', 'description', 'required');
    	    $this->form_validation->set_rules('size_param', 'size_param', 'required');
    	    $this->form_validation->set_rules('facing_direction', 'facing_direction', 'required');
    	    
	        $project_id= $this->input->post('property_id');
	        $statusdata['name'] = $this->input->post('name');
	        $statusdata['area'] = $this->input->post('area');
			$statusdata['address'] = $this->input->post('address');
			$statusdata['builder'] = $this->input->post('builder');
			 
			$data['property_status'] = $this->input->post('property_status');
			$data['min_price'] = $this->input->post('min_price');
			$data['max_price'] = $this->input->post('max_price');
			$data['description'] = $this->input->post('description');
			$data['furnish_status'] = $this->input->post('furnish_status');
			$data['size'] = $this->input->post('size');
			$data['carpet_size'] = $this->input->post('carpet_size');
			$data['builtup_size'] = $this->input->post('builtup_size');
			$data['size_param'] = $this->input->post('size_param');
			$data['bedrooms'] = $this->input->post('bedrooms');
			$data['hall'] = $this->input->post('hall');
			$data['kitchen'] = $this->input->post('kitchen');
			$data['floors'] = $this->input->post('floors');
			$data['bathrooms'] = $this->input->post('bathrooms');
			$data['balcony'] = $this->input->post('balcony');
			$data['maintainance_charges'] = $this->input->post('maintainance_charges');
			$data['loan_offered_by'] = $this->input->post('loan_offered_by');
			$data['boundary_wall'] = $this->input->post('boundary_wall');
			$data['facingside_roadwidth'] = $this->input->post('facingside_roadwidth');
			$data['open_side_no'] = $this->input->post('open_side_no');
			$data['floor_allowed'] = $this->input->post('floor_allowed');
			$data['facing_direction'] = $this->input->post('facing_direction');
// 			$data['status'] = '2';                                      // Status 2 implies property has not been approved by the admin
// 			$data['featured'] = '0';
			
			if(is_array($this->input->post('amenities'))){
			    $amenities = $this->input->post('amenities');
			    if(!empty($amenities)){
	               $data['amenities'] = implode(',', $amenities);
                }
                else{
	               $data['amenities'] = '';
                }
	       }
     		if ($this->form_validation->run() == FALSE)
            {
              //    ----------------------------------------------------
    		     //   set flash data for resend data in previous page
    		     
    		    $array_data = array('min_price'=> $data['min_price'], 'size_param'=> $data['size_param'], 'facing_direction'=> $data['facing_direction'], 'description'=> $data['description'], 'property_status'=> $data['property_status'], 'max_price'=> $data['max_price'], 'furnish_status'=> $data['furnish_status'], 'size'=> $data['size'], 'carpet_size'=> $data['carpet_size'], 'builtup_size'=> $data['builtup_size'], 'bedrooms'=> $data['bedrooms'], 'hall'=> $data['hall'], 'kitchen'=> $data['kitchen'], 'floors'=> $data['floors'], 'balcony'=> $data['balcony'], 'bathrooms'=> $data['bathrooms'], 'maintainance_charges'=> $data['maintainance_charges'], 'loan_offered_by'=> $data['loan_offered_by'], 'boundary_wall'=> $data['boundary_wall'], 'facingside_roadwidth'=> $data['facingside_roadwidth'], 'open_side_no'=> $data['open_side_no'], 'floor_allowed'=> $data['floor_allowed'], 'facing_direction'=> $data['facing_direction']);
    		    $this->session->set_flashdata('flashdata_create_property_step2', $array_data);
    		  
    		 //-------------------------------------------------------
    		   
        		$url = base_url().'create_update_property_admin/create_property_step2';
        		redirect($url);
            }
            else
            {  
                
                $update_property_steps = $this->Property_model->update_property_steps($data);
        		if($update_property_steps > 0){
        		    if($this->session->has_userdata('session_property_id')){
        		      //  post data is to be sent in next  page
        		        $data['area'] = $statusdata['area'];
        		        $data['name'] = $statusdata['name'];
            			$data['address'] = $statusdata['address'];
            			$data['builder'] = $statusdata['builder'];
            			
        		        $data['property_status'] = $data['property_status'];
            			$data['min_price'] = $data['min_price'];
            			$data['max_price'] = $data['max_price'];
            			$data['description'] = $data['description'];
            			$data['furnish_status'] = $data['furnish_status'];
            			$data['size'] = $data['size'];
            			$data['carpet_size'] = $data['carpet_size'];
            			$data['builtup_size'] = $data['builtup_size'];
            			$data['size_param'] = $data['size_param'];
            			$data['bedrooms'] = $data['bedrooms'];
            			$data['hall'] = 	$data['hall'];
            			$data['kitchen'] = $data['kitchen'];
            			$data['floors'] = $data['floors'];
            			$data['bathrooms'] = $data['bathrooms'];
            			$data['balcony'] = $data['balcony'];
            			$data['maintainance_charges'] = $data['maintainance_charges'];
            			$data['loan_offered_by'] = $data['loan_offered_by'];
            			$data['boundary_wall'] = $data['boundary_wall'];
            			$data['facingside_roadwidth'] = $data['facingside_roadwidth'];
            			$data['open_side_no'] = $data['open_side_no'];
            			$data['floor_allowed'] = $data['floor_allowed'];
            			$data['facing_direction'] = $data['facing_direction'];
            			
        		        if($this->session->has_userdata('session_property_id')){
                            $pid = $this->session->userdata('session_property_id');
                            $data['selected_property'] = $this->Property_model->select_property($pid);
                        }
                        $repo_id = $this->session->userdata('repository_id');
                        $data['select_property_media'] = $this->media_model->select_property_media($repo_id);
            		  // 	$data['property_page_1'] = TRUE;
            		    $data['property_id'] = $project_id;
                		$data['view'] = 'admin/post_your_property_step4';
                		$data['page'] = 'dashboard';
        	            $data['title'] = 'Pakiza Properties | Create Property';
                		$this->load->view('admin/layouts/main', $data); 
        		    }
        		}
            }
	    }
	    else{
	        $data['admin'] = $this->session->userdata('admin_id');
            if($this->session->has_userdata('session_property_id')){
                
                $pid = $this->session->userdata('session_property_id');
                $data['selected_property'] = $this->Property_model->select_property($pid);
                // $area['city_id'] = $this->Property_model->getCity_property($pid);
                $data['property_id'] = $pid;
                $repo_id = $this->session->userdata('repository_id');
                $data['select_property_media'] = $this->media_model->select_property_media($repo_id);
        // 		$data['property_page_1'] = TRUE;
        		$data['view'] = 'admin/post_your_property_step4';
        		$data['page'] = 'dashboard';
        	    $data['title'] = 'Pakiza Properties | Create Property';
        		$this->load->view('admin/layouts/main', $data);
            }
	    }
	}
	
	public function do_upload()
    {   
        $this->load->model('Property_model');
        $this->load->model('media_model');
        $this->load->library('upload');
        
        if(isset($_POST["do_upload"])) {
            
            $dataInfo = array();
            $files = $_FILES;
            $cpt = count($_FILES['userfile']['name']);
            for($i=0; $i<$cpt; $i++)
            {           
                $_FILES['userfile']['name']= $files['userfile']['name'][$i];
                $_FILES['userfile']['type']= $files['userfile']['type'][$i];
                $_FILES['userfile']['tmp_name']= $files['userfile']['tmp_name'][$i];
                $_FILES['userfile']['error']= $files['userfile']['error'][$i];
                $_FILES['userfile']['size']= $files['userfile']['size'][$i];    
        
                $this->upload->initialize($this->set_upload_options());
                $this->upload->do_upload();
                $dataInfo[] = $this->upload->data();
            }
          
            // var_dump($dataInfo[0]);
            // for getting repository id 
            $property_id = $_POST['property_id'];
        	    
    	    $repository_data = array(
                'type'=> "PROPERTY",
                'type_id'=> $property_id,
    		);
    		        
    		$repo_id = $this->media_model->get_reposotory_id($repository_data);
        		
            if(!empty($dataInfo)){
	        $count  =   1;
	            for ($r = 0; $r < $cpt; $r++) {
                    $data   =   array(
                        'repository_id' => $repo_id,
                        'name'=>$dataInfo[$r]['file_name'],
                        'ordering'=>$count++,
                    );
                    $result = $this->media_model->insert_media($data);
                }
                $data['admin'] = $this->session->userdata('admin_id');
                if($this->session->has_userdata('session_property_id')){
                    
                    $pid = $this->session->userdata('session_property_id');
                    $data['selected_property'] = $this->Property_model->select_property($pid);
                    $data['select_property_media'] = $this->media_model->select_property_media($repo_id);
                    // var_dump($data['select_property_media']);
                    $data['property_id'] = $pid;
            		$data['view'] = 'admin/post_your_property_step4';
            		$data['page'] = 'dashboard';
        	        $data['title'] = 'Pakiza Properties | Create Property';
            		$this->load->view('admin/layouts/main', $data);
                }
    	       
            }
        }else{
	        $data['admin'] = $this->session->userdata('admin_id');
            if($this->session->has_userdata('session_property_id')){
                $pid = $this->session->userdata('session_property_id');
                
        	    $repository_data = array(
                    'type'=> "PROPERTY",
                    'type_id'=> $pid,
        		);
        		        
        		$repo_id = $this->media_model->get_reposotory_id($repository_data);
    		
               
                $data['selected_property'] = $this->Property_model->select_property($pid);
                $data['select_property_media'] = $this->media_model->select_property_media($repo_id);
                // var_dump($data['select_property_media']);
                $data['property_id'] = $pid;
        		$data['view'] = 'admin/post_your_property_step4';
        		$data['page'] = 'dashboard';
        	    $data['title'] = 'Pakiza Properties | Create Property';
        		$this->load->view('admin/layouts/main', $data);
            }
	    }    
    }
    
    private function set_upload_options()
    {   
        //upload an image options
        $config = array();
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size']      = '0';
        $config['overwrite']     = FALSE;
    
        return $config;
    }
    
    public function add_image_caption(){
        if($this->session->userdata('pk_logged_in')){
    	    
	    }
	    else{
	        redirect('authenticate');
	    }
	    
	    $this->load->model('media_model');
	    if(isset($_POST['do_upload'])){
	        
	        $this->form_validation->set_rules('medianame', 'medianame', 'required');
        	             
            if ($this->form_validation->run() == FALSE)
            {
              
        		$url = base_url().'create_update_property_admin/create_property_step3';
        		redirect($url);
            }else{
           
        	    foreach($_POST as $key=>$value){
        	        $new_key = preg_replace("/[^0-9]/", '', $key);
        	        $media[$new_key] = $value;
        	    }
        	    $response = $this->media_model->add_image_caption($media);
                if($response){
                    redirect('admin/properties');
                    
                }
                else{
                    redirect('create_update_property_admin/do_upload');
                }
            }
	    }
    }                
}
