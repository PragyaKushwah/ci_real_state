<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index(){
	    
	    $data['view']='user/index';
	    $data['page'] = 'page';
	    $data['title'] = 'Pakiza Realty | Home';
	    $data['pakiza_properties'] =$this->User_model->get_property_details();
	     $data['blog_details'] = $this->User_model->get_blog_details();
	    // Loads View
		$this->load->view('user/layouts/main',$data);
	}
	
	public function about(){
	    $data['view']='user/about';
	    $data['page'] = 'page';
	    $data['title'] = 'Pakiza Realty  | About Us';
	    $data['pakiza_properties'] =$this->User_model->get_property_details();
	    // Loads View
		$this->load->view('user/layouts/main',$data);
	}
	public function properties(){
	    $data['view']='user/properties';
	    $data['page'] = 'page';
	    $data['title'] = 'Pakiza Realty | Properties';
	     $data['pakiza_properties'] =$this->User_model->get_property_details();
	    // Loads View
		$this->load->view('user/layouts/main',$data);
	}
	 public function properties_single(){
	     $id= $_GET['id'];
	     $data['view']='user/properties-single';
	    $data['page'] = 'page';
	    $data['title'] = 'Pakiza Realty | Properties';
	    $data['pakiza_galleries'] = $this->User_model->get_gallery_images($id);
	     $data['pakiza_properties'] = $this->User_model->get_property($id);
	    // Loads View
		$this->load->view('user/layouts/main',$data);
	}
	public function agents(){
	    $data['view']='user/agents';
	    $data['page'] = 'page';
	    $data['title'] = 'Pakiza Realty | Agents';
	    
	    // Loads View
		$this->load->view('user/layouts/main',$data);
	}
	
	public function blog(){
	    $data['view']='user/blog';
	    $data['page'] = 'page';
	    $data['title'] = 'Pakiza Realty | Blogs';
	    $data['blog_details'] = $this->User_model->get_blog_details();
	    $data['pakiza_properties'] =$this->User_model->get_property_details();
	    // Loads View
		$this->load->view('user/layouts/main',$data);
	}
	
	public function blog_single(){
	    $id = $_GET['id'];
	    $data['view']='user/blog-single';
	    $data['page'] = 'page';
	    $data['title'] = 'Pakiza Realty | Blog';
	    $data['blog_details'] = $this->User_model->get_blog($id);
	    $data['blog_list'] = $this->User_model->get_blog_list($id);
	    // Loads View
		$this->load->view('user/layouts/main',$data);
	}
	
	public function contact(){
	    $data['view']='user/contact';
	    $data['page'] = 'page';
	    $data['title'] = 'Pakiza Realty | Contact';
	    $data['pakiza_properties'] =$this->User_model->get_property_details();
	    // Loads View
		$this->load->view('user/layouts/main',$data);
	}
    
    public function enquiry_form() { 
          $from_email = $this->input->post('email');
          $to_email = "pragyachouhan76666@gmail.com";
          $name = $this->input->post('name'); 
          $message = $this->input->post('message'); 
          $subject = "Pakiza Realty Enquiry";
         
         
        $this->load->library('email');
        $config = array(
            'protocol'  => 'mail',
            'smtp_host' => 'mail.visionsquaredu.com',
            'smtp_port' => 465,
            'smtp_user' => 'autoresponder@visionsquareedu.com',
            'smtp_pass' => 'Auto^2021@vision',
            'mailtype'  => 'html',
            'charset'   => 'utf-8',
            'wordwrap'  => TRUE
        );
        $this->email->initialize($config);
        $this->email->set_mailtype("html");
        $this->email->set_newline("\r\n");
        $htmlContent =  '<html>
                        <head>
                        <title>Pakiza Realty!</title>
                        </head>
                        <body>
                        <h2>Enquiry From '.$name.',</h2>
                        <br>
                        <p>Name:'. $name.'</p>
                        <p>Email: '. $from_email.'</p>
                        <p>Message: '. $message.'</p>
                        
                        </body>
                        </html>
                        ';
        $this->email->from($from_email, $name); 
        $this->email->to($to_email);
        $this->email->subject($subject); 
        $this->email->message($htmlContent); 
    
   
         //Send mail 
         if($this->email->send()) 
         $this->session->set_flashdata("success","Email sent successfully."); 
         else 
         $this->session->set_flashdata("error","Error in sending Email."); 
         
    	redirect('User/index');
      } 
	
	
}
