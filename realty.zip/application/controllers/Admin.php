<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    
    /**********************************************************************/
    /**********************************************************************/
    /***************************** LOGOUT *********************************/
    /**********************************************************************/
    /**********************************************************************/
    
	public function admin_logout(){
	    $this->session->unset_userdata('pk_user_name');
	    $this->session->unset_userdata('pk_user_id');
	    $this->session->unset_userdata('pk_logged_in');
	    $this->session->unset_userdata('pk_user_role');
	    $user_id = array(
           'name'   => 'pk_user_id',
           'value'  => $this->input->cookie('pk_user_id'),
           'expire' => '-36000',
        );
        $user_name = array(
           'name'   => 'pk_user_name',
           'value'  => $this->input->cookie('pk_user_name'),
           'expire' => '-36000',
        );
        $password = array(
           'name'   => 'pk_pass_key',
           'value'  => $this->input->cookie('pk_pass_key'),
           'expire' => '-36000',
        );
        $role = array(
           'name'   => 'pk_user_role',
           'value'  => $this->input->cookie('pk_user_role'),
           'expire' => '-36000',
        );
        $this->input->set_cookie($user_id);
        $this->input->set_cookie($user_name);
        $this->input->set_cookie($password);
        $this->input->set_cookie($role);
        
	    $this->session->set_flashdata('success', 'Admin Logged Out Successfuly!');
        redirect('authenticate');
	}
	
    /**********************************************************************/
    /**********************************************************************/
    /**************************** DASHBOARD *******************************/
    /**********************************************************************/
    /**********************************************************************/
    
	public function index(){
	    if(isset($_SESSION['pk_logged_in'])){
	        if($_SESSION['pk_logged_in']){
        	    
        	    // Page Specific Information
        	    $data['view']='admin/manage_properties';
        	    $data['page'] = 'page';
        	    $data['title'] = 'Pakiza Realty | Dashboard';
        	    $data['properties'] = $this->Admin_model->get_property_details();
        	    $data['datatable'] = TRUE;
        	   // Loads View
        		$this->load->view('admin/layouts/main',$data);
	        }else{
	            $this->session->set_flashdata('error','Please Login To Continue');
	            redirect('authenticate');
	        }
	    }else{
            $this->session->set_flashdata('error','Please Login To Continue');
            redirect('authenticate');
        }
	}

    /**********************************************************************/
    /**********************************************************************/
    /************************** MANAGE LOCATIONS **************************/
    /**********************************************************************/
    /**********************************************************************/

	public function manage_property_location()
	{	
	    if(isset($_SESSION['pk_logged_in'])){
	        if($_SESSION['pk_logged_in']){
        		$this->load->model('location_model');
                
        	    $data['page'] = 'dashboard';
        	    $data['title'] = 'Pakiza Properties | Locations';
        		$data['results'] = $this->location_model->get_locations();
        		$data['select2'] = TRUE;
        		$data['featured'] = TRUE;
        		$data['featured_attribute'] = 'locations';
        		$data['view'] = 'admin/property_location';
        
        		$this->load->view('admin/layouts/main', $data);
	        }else{
    	        redirect('authenticate');
    	    }
	    }else{
	        redirect('authenticate');
	    }
	}

	
	/***************************************************************************/
    /************************* Manage Gallery  *********************************/
    
    public function manage_gallery(){
        $property_id =$_GET['id'];
        $data['id']=$property_id;
        $this->session->set_userdata('property_id',$property_id);
        $data['view']    = 'admin/manage_gallery';
        $data['page']    = 'page';
        $data['title']   = 'Pakiza Realty |Manage Gallery';
        $data['gallery'] = $this->Admin_model->get_gallery_details2($property_id);
        $this->load->view('admin/layouts/main',$data);
    }
    
    public function sessionp(){
       if(isset($_SESSION)){
          print_r($_SESSION);
       }
   }
   public function cookiep(){
       if(isset($_COOKIE)){
          print_r($_COOKIE);
       }
    }
    
    /***************************************************************************/
    /************************* Add Gallery  *********************************/
    public function add_gallery(){
       
              if($this->input->post('submit')){
                
                $title=$this->input->post('title');
                $property_id=$this->input->post('property_id');
                $config['upload_path']          = './assets/uploads/gallery/';
                $config['allowed_types']        = 'gif|jpeg|jpg|png|tiff';
                           
                $this->load->library('upload', $config);
                           
                $this->upload->initialize($config);
                               
                      
                        $file = $_FILES['document']['tmp_name'];
                
                        if (file_exists($file))
                               {
                           
                            if (!$this->upload->do_upload('document'))
                            {
                                    $error = array('error' => $this->upload->display_errors());
                                    
                            }
                            else
                            {
                                    $data = array('upload_data' => $this->upload->data());
                                    
                                    $has_attachment=1;
                                  
                                
                            }
                          foreach($data as $dat){
                            
                            $icon=$dat['file_name'];
                            $extension_url=  base_url('/assets/uploads/gallery/').$file_name;
                      
                           }
                
                               }
                
                
                 
                $data1=array('title'=>$title,'gallery_image'=>$icon,'property_id'=>$property_id);
               
                $insert=$this->Admin_model->save_gallery_record($data1);
                if($insert)
                {
                   /*echo "Service Record added Successfully";*/
                       $url=base_url("/Admin/manage_gallery?id= $property_id");
            
                     return redirect($url);
                }
                else
                {
                    /*echo "Unable to add record! Please try again";*/
                       $url=base_url("/Admin/manage_gallery?id= $property_id");
            
                      return redirect($url);
                }
             
            }
    }
    
    
    
    /***************************************************************************/
    /************************* Update Gallery  *********************************/
    
    public function update_gallery(){
    $data['view']    = 'admin/update_gallery';
    $data['page']    = 'page';
    $data['title']   = 'Edit Gallery';
    echo $id=$_GET['id'];
    $data['gallery_details'] = $this->Admin_model->get_gallery_details1($id);
        

    $this->load->view('admin/layouts/main',$data) ;

    if($this->input->post('update')){
    $sid=$this->input->post('id');
    
     $title=$this->input->post('title');
     $property_id=$this->input->post('property_id');
   $this->session->set_userdata('property_id',$property_id);
    $config['upload_path']          = './assets/uploads/gallery/';
    $config['allowed_types']        = 'gif|jpeg|jpg|png|tiff';
    $this->load->library('upload', $config);
    $this->upload->initialize($config);
                   
          
            $file = $_FILES['document']['tmp_name'];
    
            if (file_exists($file))
                   {
               
                if (!$this->upload->do_upload('document'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        
                        $has_attachment=1;
                      
                    
                }
              foreach($data as $dat){
                
                $icon=$dat['file_name'];
                $extension_url=  base_url('/assets/uploads/gallery/').$file_name;
          
            }
    
                   }
    
       if(empty($_FILES['document']['tmp_name'])){
           $data1=array('title'=>$title,'property_id'=>$property_id);
       }else{
        $data1=array('title'=>$title,'gallery_image'=>$icon,'property_id'=>$property_id);   
       }
     
     $update=$this->Admin_model->update_gallery_record($data1,$sid);
       if($update){
       /* echo "User Record Updated Successfully";*/
           $url=base_url("/Admin/manage_gallery?id=$property_id");

          return redirect($url);

       }else{
      /* echo "unable to update!Please try again";*/
         $url=base_url("/Admin/manage_gallery?id=$property_id");
        return redirect($url);
       }
    }
    }
    
    /***************************************************************************/
    /************************* Delete Gallery *********************************/
   public function delete_gallery(){
        $id=$_GET['id'];
        $delete=$this->Admin_model->delete_gallery_record($id);
        $property_id =  $this->session->userdata('property_id');
        if($delete){
          $url=base_url("/Admin/manage_gallery?id=$property_id");
    
            return  redirect($url);
        }
        else
        {
          $url=base_url("/Admin/manage_gallery?id=$property_id");
    
            return  redirect($url);
        }
}
     /***************************************************************************/
    /************************* Manage Properties  *********************************/
    
    public function manage_properties(){
        
        $data['view']    = 'admin/manage_properties';
        $data['page']    = 'page';
        $data['title']   = 'Pakiza Realty|Manage Properties';
         $data['datatable'] = TRUE;
        $data['properties'] = $this->Admin_model->get_property_details();
        $this->load->view('admin/layouts/main',$data);
    }
    
    /***************************************************************************/
    /************************* Add Property  *********************************/
    public function add_properties(){
       
              if($this->input->post('submit')){
                
                $name        = $this->input->post('name');
                $location    = $this->input->post('location');
                $address     = $this->input->post('address');
                $description = $this->input->post('description');
                $video_url   = $this->input->post('url');
                $config['upload_path']          = './assets/uploads/gallery/';
                $config['allowed_types']        = 'gif|jpeg|jpg|png|tiff';
                           
                $this->load->library('upload', $config);
                           
                $this->upload->initialize($config);
                               
                      
                        $file = $_FILES['document']['tmp_name'];
                
                        if (file_exists($file))
                               {
                           
                            if (!$this->upload->do_upload('document'))
                            {
                                    $error = array('error' => $this->upload->display_errors());
                                    
                            }
                            else
                            {
                                    $data = array('upload_data' => $this->upload->data());
                                    
                                    $has_attachment=1;
                                  
                                
                            }
                          foreach($data as $dat){
                            
                            $icon=$dat['file_name'];
                            $extension_url=  base_url('/assets/uploads/gallery/').$file_name;
                      
                           }
                
                               }
                
                
                 
                $data1=array('name'=>$name,'location'=>$location,'address'=>$address,'description'=>$description,'photo'=>$icon,'youtube_embed_url'=>$video_url);
               
                $insert=$this->Admin_model->save_property_record($data1);
                if($insert)
                {
                   /*echo "Service Record added Successfully";*/
                       $url=base_url('/Admin/manage_properties');
            
                     return redirect($url);
                }
                else
                {
                    /*echo "Unable to add record! Please try again";*/
                       $url=base_url('/Admin/manage_properties');
            
                      return redirect($url);
                }
             
            }
    }  
 
  /***************************************************************************/
    /************************* Update Property  *********************************/
 
  public function update_properties(){
    $data['view']    = 'admin/update_properties';
    $data['page']    = 'page';
    $data['title']   = 'Edit properties';
    echo $id=$_GET['id'];
    $data['property_details'] = $this->Admin_model->get_properties_details1($id);
        

    $this->load->view('admin/layouts/main',$data) ;

    if($this->input->post('update')){
    $sid=$this->input->post('id');
    
    $name        = $this->input->post('name');
    $location    = $this->input->post('location');
    $address     = $this->input->post('address');
    $description = $this->input->post('description');
     $video_url   = $this->input->post('url');
    $config['upload_path']          = './assets/uploads/gallery/';
    $config['allowed_types']        = 'gif|jpeg|jpg|png|tiff';
    $this->load->library('upload', $config);
    $this->upload->initialize($config);
                   
          
            $file = $_FILES['document']['tmp_name'];
    
            if (file_exists($file))
                   {
               
                if (!$this->upload->do_upload('document'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        
                        $has_attachment=1;
                      
                    
                }
              foreach($data as $dat){
                
                $icon=$dat['file_name'];
                $extension_url=  base_url('/assets/uploads/gallery/').$file_name;
          
            }
    
                   }
    if(empty($_FILES['document']['tmp_name'])){
        $data1=array('name'=>$name,'location'=>$location,'address'=>$address,'description'=>$description,'youtube_embed_url'=>$video_url);
    }else{
       $data1=array('name'=>$name,'location'=>$location,'address'=>$address,'description'=>$description,'photo'=>$icon,'youtube_embed_url'=>$video_url); 
    }
     
     $update=$this->Admin_model->update_properties_record($data1,$sid);
       if($update){
       /* echo "User Record Updated Successfully";*/
           $url=base_url('/Admin/manage_properties');

          return redirect($url);

       }else{
      /* echo "unable to update!Please try again";*/
         $url=base_url('/Admin/manage_properties');
        return redirect($url);
       }
     }
    }
 
 
  /***************************************************************************/
    /************************* Delete Property *********************************/
   public function delete_properties(){
        $id=$_GET['id'];
        $delete=$this->Admin_model->delete_properties_record($id);
        if($delete){
          $url=base_url('/Admin/manage_properties');
    
            return  redirect($url);
        }
        else
        {
          $url=base_url('/Admin/manage_properties');
    
            return  redirect($url);
        }
}

/*blog functionality starts here*/
public function manage_blog(){
         
        $data['blog_details']=$this->Admin_model->get_blog_details();

        $data['view']='admin/manage_blog';
	    $data['page'] = 'page';
	    $data['title'] = 'Pakiza Realty|Manage Blog';
	    $data['datatable'] = TRUE;
	    
	   // Loads View
		$this->load->view('admin/layouts/main',$data);
        // $this->load->view('admin/manage_users',$data);
    }
    
     public function update_blog(){
    $data['view']='admin/update_blog';
    $data['page'] = 'page';
    $data['title'] = 'Edit Blog';
    
	$id = $_GET['id'];
	$data['blog_details'] = $this->Admin_model->updateblog_details($id);
    $this->load->view('admin/layouts/main',$data);

    if($this->input->post('update')){
        $uid   = $this->input->post('id');
        $intro = $this->input->post('blog_intro');
        $title = $this->input->post('blog_title');
      	$desc = $this->input->post('blog_description');
      	
      	
      	
      	
      	
      	
      	/*add here for image */
      	$config['upload_path']          = './assets/uploads/blogs/';
                $config['allowed_types']        = 'gif|jpeg|jpg|png|tiff';
               
              $this->load->library('upload', $config);
               
                  $this->upload->initialize($config);
                   
          
            $file = $_FILES['document']['tmp_name'];
    
            if (file_exists($file))
                   {
               
                if (!$this->upload->do_upload('document'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        
                        $has_attachment=1;
                      
                    
                }
              foreach($data as $dat){
                
                $icon=$dat['file_name'];
                $extension_url=  base_url('/assets/uploads/blogs/').$file_name;
          
            }
                   }
      	     /*till here*/
      	     if(empty($_FILES['document']['tmp_name'])){
      	         $data = array(
  	            'blog_title'=>$title,
  	            'blog_intro'=>$intro,
  	            'blog_description'=>$desc,
  	            
  	            
              );
      	     }else{
      	         $data = array(
  	            'blog_title'=>$title,
  	            'blog_intro'=>$intro,
  	            'blog_description'=>$desc,
  	            'blog_image'=>$icon,
  	            
              );
      	     }
  	    
  
              
             $update = $this->Admin_model->update_blog_record($data,$uid);
                if($update) {
                    echo '<script>alert("Blog Updated Successfully");window.location.href="'.base_url('/Admin/manage_blog').'"</script>';
                }else{
                    echo '<script>alert("Please Try Again!");window.location.href="'.base_url('/Admin/manage_blog').'"</script>';
                }
        
        
        
        
     
    }
}  
    
    public function add_blog(){
      if($this->input->post('submit')){
          
  	    $title = $this->input->post('blog_title');
  	    $intro = $this->input->post('blog_intro');
      	$desc = $this->input->post('blog_description');
      
      	/*add here for image */
      	$config['upload_path']          =     './assets/uploads/blogs/';
                $config['allowed_types']        = 'gif|jpeg|jpg|png|tiff';
               
              $this->load->library('upload', $config);
               
                  $this->upload->initialize($config);
                   
          
            $file = $_FILES['document']['tmp_name'];
    
            if (file_exists($file))
                   {
               
                if (!$this->upload->do_upload('document'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        
                        $has_attachment=1;
                      
                    
                }
              foreach($data as $dat){
                
                $icon=$dat['file_name'];
                $extension_url=  base_url('/assets/uploads/blogs/').$file_name;
          
            }
    
      	     /*till here*/
  	    $data = array(
  	            'blog_title'=>$title,
  	            'blog_intro'=>$intro,
  	            'blog_description'=>$desc,
  	            'blog_image'=>$icon,
  	           
              );
  
    $addblog=$this->Admin_model->save_blog_record($data);
    if($addblog){
    	 $url=base_url('/Admin/manage_blog');

         return redirect($url);
    }
    
    else
    {
        $url=base_url('/Admin/manage_blog');

         return redirect($url);
    }
    
  }  
        
    }
} 
  
  
   public function delete_blog(){
      $id=$_GET['id'];
      $delete=$this->Admin_model->delete_blog_record($id);
        if($delete){
          $url=base_url('/Admin/manage_blog');
    
            return  redirect($url);
        }
        else
        {
          $url=base_url('/Admin/manage_blog');
    
            return  redirect($url);
        }
    }
    /*Blog functionalities end here*/    
    /*Contact functionality starts here*/
public function manage_contact(){
         
        $data['contact_details']=$this->Admin_model->get_contact_details();

        $data['view']='admin/manage_contact';
	    $data['page'] = 'page';
	    $data['title'] = 'Pakiza Realty|Manage Contact';
	    $data['datatable'] = TRUE;
	    
	   // Loads View
		$this->load->view('admin/layouts/main',$data);
        // $this->load->view('admin/manage_users',$data);
    }
    
     public function update_contact(){
    $data['view']='admin/update_contact';
    $data['page'] = 'page';
    $data['title'] = 'Edit Contact';
    
	$id = $_GET['id'];
	$data['contact_details'] = $this->Admin_model->updatecontact_details($id);
    $this->load->view('admin/layouts/main',$data);

    if($this->input->post('update')){
        $uid   = $this->input->post('id');
        $type = $this->input->post('type');
        $detail = $this->input->post('detail');
      
      	 $data = array(
  	            'type'=>$type,
  	            'detail'=>$detail,
  	           
  	            
              );
      	
  
              
             $update = $this->Admin_model->update_contact_record($data,$uid);
                if($update) {
                    echo '<script>alert("Contact Updated Successfully");window.location.href="'.base_url('/Admin/manage_contact').'"</script>';
                }else{
                    echo '<script>alert("Please Try Again!");window.location.href="'.base_url('/Admin/manage_contact').'"</script>';
                }
        
        
        
        
      }
    }
  
    
    public function add_contact(){
      if($this->input->post('submit')){
          
  	    $type = $this->input->post('type');
  	    $detail = $this->input->post('detail');
      	
      
      	
    
      	     /*till here*/
  	     $data = array(
  	            'type'=>$type,
  	            'detail'=>$detail,
  	           
  	            
              );
  
    $addblog=$this->Admin_model->save_contact_record($data);
    if($addblog){
    	 $url=base_url('/Admin/manage_contact');

         return redirect($url);
    }
    
    else
    {
        $url=base_url('/Admin/manage_contact');

         return redirect($url);
    }
    
  }  
        
    }
 
  
  
   public function delete_contact(){
      $id=$_GET['id'];
      $delete=$this->Admin_model->delete_contact_record($id);
        if($delete){
          $url=base_url('/Admin/manage_contact');
    
            return  redirect($url);
        }
        else
        {
          $url=base_url('/Admin/manage_contact');
    
            return  redirect($url);
        }
    }
    /*Contact functionalities end here*/  
    
    
}
